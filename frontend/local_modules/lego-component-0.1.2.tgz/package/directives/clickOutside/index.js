import clickOutside from "./clickOutside.js";
export default {
    install(Vue) {
        Vue.directive(clickOutside.name, clickOutside);
    }
};