export default {
    name : 'clickOutside',
    inserted(el,binding, vnode) {
        const handler = (e) => {
            if (!(el.contains(e.target) || el === e.target)) {
                binding.value(e)
            }
        };
        el.__vueClickOutside__ = handler;
        document.body.addEventListener('click', el.__vueClickOutside__);
    },
    unbind(el,binding,vnode) {
        document.body.removeEventListener('click', el.__vueClickOutside__);
        delete el.__vueClickOutside__;
    }
}