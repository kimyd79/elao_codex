/* [Directives] */
import clickOutside from "./clickOutside"
import legoTooltip from "./legoTooltip"

export default function install(Vue){
    Vue.use(clickOutside);
    Vue.use(legoTooltip);
};