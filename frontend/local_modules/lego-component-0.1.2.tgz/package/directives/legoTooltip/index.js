import legoTooltip from "./legoTooltip.js";
export default {
    install(Vue) {
        Vue.directive(legoTooltip.name, legoTooltip);
    }
};