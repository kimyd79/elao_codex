/*****************************
 * LEGO-TOOLTIP
 *****************************/
function throttle(func, wait, options) {
    var context, args, result;
    var timeout = null;
    var previous = 0;
    if (!options) options = {};
    var later = function() {
        previous = options.leading === false ? 0 : Date.now();
        timeout = null;
        result = func.apply(context, args);
        if (!timeout) context = args = null;
    };
    return function() {
        var now = Date.now();
        if (!previous && options.leading === false) previous = now;
        var remaining = wait - (now - previous);
        context = this;
        args = arguments;
        if (remaining <= 0 || remaining > wait) {
            if (timeout) {
                clearTimeout(timeout);
                timeout = null;
            }
            previous = now;
            result = func.apply(context, args);
            if (!timeout) context = args = null;
        } else if (!timeout && options.trailing !== false) {
            timeout = setTimeout(later, remaining);
        }
        return result;
    };
}
export default {
    name : 'lego-tooltip',
    inserted(el,binding, vnode) {
        let tooltip = document.createElement('div');
        tooltip.className = 'lego-tooltip-directive';
        tooltip.innerText = binding.value;
        el.__tooltipElement__ = tooltip;
        el.__tooltipX__ = 0;
        el.__tooltipY__ = 0;
        el.__tooltipTimer__ = {};
        el.__tooltipMMove__ = throttle(function(e) {
            el.__tooltipX__ = e.clientX;
            el.__tooltipY__ = e.clientY;
        },300);
        el.__tooltipMEnter__ = function (e) {
            el.addEventListener('mousemove',el.__tooltipMMove__);
            el.__tooltipTimer__ = setTimeout(function() {
                let screenWidth = document.body.clientWidth;
                let screenHeight = document.body.clientHeight;
                if(el.__tooltipY__ > screenHeight/2) {
                    // 툴팁이 위쪽으로 뜰것이다.
                    tooltip.style.top = '';
                    tooltip.style.bottom = (screenHeight - el.__tooltipY__ + 4) +'px';
                } else {
                    // 툴팁이 아래쪽으로 뜰것이다.
                    tooltip.style.bottom = '';
                    tooltip.style.top = (el.__tooltipY__ + 20) +'px';
                }
                if(el.__tooltipX__ > screenWidth/2) {
                    // 툴팁이 왼쪽으로 뜰 것이다.
                    tooltip.style.left = '';
                    tooltip.style.right = (screenWidth - el.__tooltipX__) + 'px'
                } else {
                    // 툴팁이 오른쪽으로 뜰 것이다.
                    tooltip.style.right = '';
                    tooltip.style.left = (el.__tooltipX__) + 'px'
                }
                document.getElementsByClassName('lego-system')[0].appendChild(tooltip);
                tooltip.setAttribute('mounted','true');
            },1000)
        };
        el.__tooltipMLeave__ = function(e) {
            clearTimeout(el.__tooltipTimer__);
            el.removeEventListener('mousemove', el.__tooltipMMove__);
            if(tooltip.getAttribute('mounted') === 'true') {
                document.getElementsByClassName('lego-system')[0].removeChild(tooltip);
                tooltip.removeAttribute('mounted');
            }
        };
        el.addEventListener('mouseenter', el.__tooltipMEnter__);
        el.addEventListener('mouseleave', el.__tooltipMLeave__);
    },
    componentUpdated(el, binding, vnode) {
        if(binding.value !== binding.oldValue) {
            el.__tooltipElement__.innerText = binding.value;
        }
    },
    unbind(el,binding,vnode) {
        el.__tooltipMLeave__();
        el.removeEventListener('mouseenter', el.__tooltipMEnter__);
        el.removeEventListener('mouseleave', el.__tooltipMLeave__);
        if(el.hasOwnProperty('__tooltipMEnter__' )) delete el.__tooltipMEnter__ ;
        if(el.hasOwnProperty('__tooltipMLeave__' )) delete el.__tooltipMLeave__ ;
        if(el.hasOwnProperty('__tooltipMMove__'  )) delete el.__tooltipMMove__  ;
        if(el.hasOwnProperty('__tooltipElement__')) delete el.__tooltipElement__;
        if(el.hasOwnProperty('__tooltipX__'      )) delete el.__tooltipX__      ;
        if(el.hasOwnProperty('__tooltipY__'      )) delete el.__tooltipY__      ;
        if(el.hasOwnProperty('__tooltipTimer__'  )) delete el.__tooltipTimer__  ;
    }
}