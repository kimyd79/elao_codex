import compo  from './components'
import direc  from './directives'
import filter from './filters'

import VueNoti from 'vue-notification';

const legoComponent = {
     install(Vue){
        Vue.use(VueNoti);
        Vue.use(compo);
        Vue.use(direc);
        Vue.use(filter);
    }
}
export default legoComponent

import validator from './mixins/legoValidator/legoValidator.js'
const legoValidator = validator
export {legoComponent, legoValidator, validator}