import legoCheckbox from "./legoCheckbox.vue";
import legoCheckboxWrapper from "./legoCheckboxWrapper.vue";
export default {
    install(Vue){
        Vue.component(legoCheckbox.name, legoCheckbox);
        Vue.component(legoCheckboxWrapper.name, legoCheckboxWrapper);
    }
};