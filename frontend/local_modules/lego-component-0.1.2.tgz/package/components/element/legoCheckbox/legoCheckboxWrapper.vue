<template>
    <div class="lego-checkbox-wrapper" :class="wrapperClass" >
        <!-- 
            $ver: v0.1.1
            체크박스 Wrapper 내부에 들어갈 컨텐츠 영역 입니다. 다수의 <em>lego-checkbox</em>가 배치되어 활용됩니다.
            #The content area to be placed inside the checkbox wrapper. A number of <em>lego-checkbox</em> s are deployed and utilized.
        -->
        <slot></slot>
        <div v-if="messageShow"
             class="lego-checkbox-wrapper__message lego-validator__message">
            {{messageShow}}
        </div>
    </div>
</template>

<script>
    import legoValidatorMixin from '../../../mixins/legoValidator/legoValidatorMixin.vue';
    export default {
        name: 'lego-checkbox-wrapper',
        mixins: [legoValidatorMixin],
        model: {
            prop: 'checked'
        },
        inject: {
            legoInput: {from:'legoInput', default: () => undefined}
        },
        props: {
            // $ver: v0.1.1
            // $v-model
            // v-model로 바인딩 되는 값입니다. <em>lego-checkbox-wrapper</em>하위에 존재하는
            // <em>lego-checkbox</em>의 v-model을 덮어씁니다.(단, group이 다른 경우 제외)
            // #The value bound to v-model. Overrides the v-model of <em>lego-checkbox</em> that exists under <em>lego-checkbox-wrapper</em> (unless group is different)
            checked: {type: [Boolean, String, Array]},
            // $ver: v0.1.1
            // 하단에 표시되는 가이드 메시지입니다. 별도의 설정이 없다면 출력되지 않습니다.
            // <em>lego-checkbox-wrapper</em>는 메시지 출력을 위한 공간을 별도로 점유하지않습니다.
            // 메시지 출력을 원할 경우 공간확보가 필요합니다.
            // #The guide message that appears at the bottom. If there is no setting, no output.
            // #<em>lego-checkbox-wrapper</em> does not occupy space for message output.
            // #If you want to output a message, you need to make space.
            guideMessage: {type:String, default: undefined},
            // $ver: v0.1.1
            // validate를 통과한 경우 출력되는 메시지입니다.
            // 별도설정이 없다면 가이드 메시지가 출력되거나 아무런 메시지도 출력되지 않습니다.
            // <em>lego-checkbox-wrapper</em>는 메시지 출력을 위한 공간을 별도로 점유하지않습니다.
            // 메시지 출력을 원할 경우 공간확보가 필요합니다.
            // #The message that is output if validate passes.
            // #If there is no setting, guide message or no message is printed.
            // #<em>lego-checkbox-wrapper</em> does not occupy space for message output.
            // #If you want to output a message, you need to make space.
            successMessage: {type:String, default: undefined},
            // $ver: v0.1.1
            // <em>lego-checkbox-wrapper</em>하위에 존재하는 <em>lego-checkbox</em>중에서
            // <em>lego-checkbox-wrapper</em>와 group이 같게 설정된 <em>lego-checkbox</em>만 영향을 받게됩니다.
            // wrapper와 checkbox모두 기본값은 'default'로 설정되어있습니다.
            // #<em>lego-checkbox</em> with <em>lego-checkbox-wrapper</em> set to the same <em>lego-checkbox-wrapper</em> among <em>lego-checkbox-wrapper</em> only affected.
            // #The wrapper and checkbox are both set to 'default' by default.
            group: {
                type: String,
                default: 'default'
            },
            // $ver: v0.1.2
            // <em>lego-checkbox-wrapper</em>하위에 존재하는 <em>lego-checkbox</em>를 disabled 상태로 설정합니다.
            // <em>lego-checkbox-wrapper</em>와 group 이 같게 설정된 <em>lego-checkbox</em>만 영향을 받게됩니다.
            // #Set the <em>lego-checkbox</em> under the <em>lego-checkbox-wrapper</em> to the disabled state.
            // #Only <em>lego-checkbox</em> with the same <em>lego-checkbox-wrapper</em> and group will be affected.
            // $default: false
            disabled: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // 하위 <em>lego-checkbox</em>의 크기를 medium으로 정의합니다.
            // #Define the size of the child <em>lego-checkbox</em> as medium.
            // $default: false
            medium: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: medium
            md: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 하위 <em>lego-checkbox</em>의 크기를 small로 정의합니다.
            // #Define the size of the child <em>lego-checkbox</em> as small.
            // $default: false
            small: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: small
            sm: {
                type:Boolean,
                default: false,
            },

            /* [FROM VALIDATOR] */
            // rules
            // disabled
            // lazy
            // noShake
            /********************/
        },
        data() {return {
            default: {
                size: 'medium'
            }
            /* [FROM VALIDATOR] */
            // hasError
            // errorMessage
            // showValid
            // shake
            /********************/
        }},
        computed: {
            $_size() {
                if(this.medium || this.md) {return 'medium'}
                if(this.small || this.sm) {return 'small'}
                if(this.legoInput) {return this.legoInput.size}
                return this.default.size;
            },
            wrapperClass() { return {
                'lego-validator--error': this.hasError === true,
                'lego-validator--valid': this.showValid && this.hasError === false,
                'lego-validator--shake': this.shake
            }},
            sharedData() {
                let rtn = {}, odf = Object.defineProperty;
                odf(rtn, "checked"     , {get:()=>this.checked});
                odf(rtn, "emit"        , {get:()=>this.emit});
                odf(rtn, "click"       , {get:()=>this.click});
                odf(rtn, 'disabled' , {get:()=>this.disabled});
                odf(rtn, 'hasError' , {get:()=>this.hasError});
                return rtn;
            },
            messageShow() {
                if(this.hasError === undefined) {
                    return this.guideMessage;
                }
                if(this.hasError === true) {
                    return this.errorMessage;
                }
                if(this.hasError === false) {
                    return this.successMessage || this.guideMessage;
                }
                return undefined;
            },
            /* [FROM VALIDATOR] */
            // isValidatable
            // el
            validateTarget() {return this.checked;}, // validation setting
            /********************/
        },
        watch: {
            validateTarget(val) {
                this.validateOnEvent(); // whenever checked value changes, execute validate() if lazy is false
            },

            successMessage: {
                immediate: true,
                handler(val) {
                    this.showValid = !!val;
                }
            }
        },
        provide() {
            let rtn = {legoCheckboxWrapper:{}}, odf=Object.defineProperty;
            rtn.legoCheckboxWrapper[this.group] = this.sharedData;
            let legoInput = {};
            odf(legoInput, 'size', {get: ()=>this.$_size});
            rtn['legoInput'] = legoInput;
            return rtn;
        },
        methods: {
            /* [FROM VALIDATOR] */
            // validate()        --+
            // isValid()         --+-- exposed methods for manual validate control
            // clearValidation() --+
            // validateOnEvent() -> should be set by each component which uses legoValidatorMixin
            /********************/

            emit(val) {
                // $ver: v0.1.1
                // $arg: updated v-model value
                // v-model에 설정된값(checked)을 업데이트합니다.
                // # update v-model value(checked props).
                this.$emit('input',val);
            },
            click(e) {
                // $ver: v0.1.1
                // $arg: click event
                // 클릭 시 호출되는 이벤트 입니다.
                // # This event is called when clicked.
                this.$emit('click',e);
            }

        }
    }

</script>