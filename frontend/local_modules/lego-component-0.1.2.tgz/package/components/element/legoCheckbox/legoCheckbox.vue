<template>
    <div class="lego-checkbox lego-input" :class="checkboxClass">
        <lego-icon class="lego-checkbox__icon"
                   :class="{'lego-checkbox__unchecked' : !clicked, 'lego-checkbox__checked': clicked}"
                   :icon="clicked? checkedIcon : unCheckedIcon" :iconType="iconType"
                   :regular="!clicked"
                   @click.stop="onClick"/>
        <span v-if="!!$slots.default" class="lego-checkbox__label" @click.stop="onClick"><!--
            $ver: v0.1.0
            체크박스 아이콘 오른쪽으로 위치하는 label 영역입니다. text를 넣어주는 경우가 일반적입니다.
            # default label area on the right side of checkbox icon.
        --><slot/><!--
    --></span>
    </div>
</template>

<script>
    export default {
        name: 'lego-checkbox',
        model: {
            prop: 'checked'
        },
        inject: {
            legoCheckboxWrapper: {from: 'legoCheckboxWrapper', default: () => undefined},
            legoInput: {from:'legoInput', default: () => undefined}
        },
        props: {
            // $ver: v0.1.0
            // $v-model
            // v-model로 바인딩되는 값으로, <em>lego-checkbox-wrapper</em>를 사용할 경우
            // # Binding to v-model. If <em>lego-checkbox-wrapper</em> component used,
            // lego-checkbox-wrapper의 v-model값을 우선시하고 lego-checkbox의 v-model은 무시됩니다.
            // # v-model of this lego-checked box is ignored and v-model of lego-checkbox-wrapper is used instead.
            // 단일 체크박스로 사용되는 경우에만 Boolean, String 타입을 사용하고 다중선택이 필요한경우 Array타입을 사용해야 합니다.
            // # Boolean and String type is only used in single checkbox use-case. Array type has to be set when using multiple select use-case.
            checked: {
                type: [Boolean, String, Array],
            },
            // $ver: v0.1.0
            // 선택되었을 때 v-model의 값으로 설정되는 목표값입니다.
            // # If component is checked, v-model is set as this value.
            // $default: true
            value: {
                type: [String, Boolean, Number, Array, Object],
                default: true
            },
            // $ver: v0.1.0
            // 선택되었을 때 표시될 아이콘입니다. 기본값으로 OPUS icon 중 'checked' 아이콘이 설정되어 있습니다.
            // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
            // #The icon to be displayed when selected. By default, the 'checked' icon is set among the OPUS icons.
            // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
            checkedIcon: {
                type: String,
                default: 'checked'
            },
            // $ver: v0.1.0
            // 미선택되었을 때 표시될 아이콘입니다. 기본값으로 OPUS icon 중 'box'아이콘이 설정되어있습니다.
            // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
            // #Icon to be displayed when not selected. By default, 'box' icon is set among OPUS icons.
            // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
            unCheckedIcon: {
                type: String,
                default: 'box'
            },
            // $ver: v0.1.0
            // 상호작용 불가능한 상태를 만듭니다.
            // #Create a non-interactive state.
            // $default: false
            disabled: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.0
            // 기본크기의 체크박스를 사용합니다.
            // #Use the check boxes of the default size.
            // $default: false
            medium: {
                type: Boolean,
                default: false
            },
            // $abbr: small
            md: {type:Boolean,},
            // $ver: v0.1.0
            // 기본크기보다 작은 사이즈의 체크박스를 사용합니다.
            // #Use checkboxes smaller than the default size.
            // $default: false
            small: {
                type: Boolean,
                default: false
            },
            // $abbr: small
            sm: {type:Boolean,},
            // $ver: v0.1.0
            // OPUS icon의 타입은 'picto'와 'line' 두가지 타입이 있습니다.
            // 체크박스 아이콘에 사용될 기본 아이콘 타입을 설정합니다.
            // #Type of OPUS icon There are two types of 'picto' and 'line'.
            // #Sets the default icon type for the checkbox icon.
            iconType: {
                type: String,
                default: 'picto'
            },
            // $ver: v0.1.1
            // <em>lego-checkbox-wrapper</em>와 함께 사용할 때 wrapper 하위에 위치하는 모든 체크박스가 아닌
            // 특정 체크박스에만 validate를 적용하고 싶을 경우 group이름을 지정하여 분리할 수 있습니다.
            // #When used with <em>lego-checkbox-wrapper</em>, you can separate it by specifying the group name
            // #if you want to apply validate only to a specific checkbox rather than to all the checkboxes under the wrapper.
            group: {
                type: String,
                default: 'default'
            }
        },

        data() {
            return {
                default: {
                    size: 'medium'
                }
            };
        },
        computed: {
            $_size() {
                if(this.medium || this.md) {return 'medium'}
                if(this.small || this.sm) {return 'small'}
                if(this.legoInput) {return this.legoInput.size}
                return this.default.size;
            },
            actualVModel() {
                if(this.legoCheckboxWrapper && this.legoCheckboxWrapper[this.group]) {
                    if(this.checked){
                        console.warn('[LEGO-CHECKBOX] if you use lego-checkbox-wrapper, v-model(=checked props) of lego-checkbox itself is being ignored.');
                    }
                    return this.legoCheckboxWrapper[this.group].checked;
                }
                return this.checked;
            },
            clicked() {
                if (typeof(this.value) == 'boolean') {
                    // Boolean
                    if(this.actualVModel==='Y') return true;
                    if(this.actualVModel==='N') return false;
                    return this.actualVModel;
                }
                else {
                    if (Array.isArray(this.actualVModel)) {
                        // Array
                        return (this.actualVModel.indexOf(this.value) >= 0);
                    }
                    else {
                        // String
                        return this.actualVModel === this.value;
                    }
                }
            },
            checkboxClass() {
                let clazz = [];
                if (this.disabled || (this.legoCheckboxWrapper
                                        && this.legoCheckboxWrapper[this.group]
                                        && this.legoCheckboxWrapper[this.group].disabled)) {
                    clazz.push('lego-checkbox--disabled');
                }
                clazz.push('lego-checkbox--'+this.$_size);
                if(this.legoCheckboxWrapper
                    && this.legoCheckboxWrapper[this.group]
                    && this.legoCheckboxWrapper[this.group].hasError) {clazz.push('lego-validator--error')}
                return clazz;
            }
        },
        methods: {
            onClick(e) {
                // $ver: v0.1.2
                // $arg: click event
                // 체크박스 클릭 시 발생하는 이벤트 입니다.
                // # This event occurs when the checkbox is clicked.
                this.$emit('click',e);
                if(this.legoCheckboxWrapper && this.legoCheckboxWrapper[this.group]) {
                    this.legoCheckboxWrapper[this.group].click(e);
                }

                if (typeof(this.value) === 'boolean') {
                    if(this.actualVModel==='Y') {this.emit('N');}
                    else if(this.actualVModel==='N'){this.emit('Y');}
                    else {
                        this.emit(!this.actualVModel);
                    }
                } else {
                    if (Array.isArray(this.actualVModel)) {
                        if (this.actualVModel.indexOf(this.value) >= 0) {
                            // if exist, remove it
                            this.emit(this.actualVModel.filter(item => item !== this.value));
                        }
                        else {
                            // if not exist, append it
                            this.emit(this.actualVModel.concat(this.value));
                        }
                    }
                    else {
                        // String type v-model
                        this.emit(this.actualVModel===this.value ? '' : this.value);
                    }
                }
            },
            emit(val) {
                if(this.legoCheckboxWrapper && this.legoCheckboxWrapper[this.group]) {
                    this.legoCheckboxWrapper[this.group].emit(val);
                } else {
                    // $ver: v0.1.0
                    // $arg: updated v-model value
                    // v-model에 설정된값(checked)을 업데이트합니다.
                    // # update v-model value(checked props).
                    this.$emit('input', val);
                }
            }
        }
    };

</script>
