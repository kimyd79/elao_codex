<template>
    <button :class="buttonClass" v-on="$listeners" ><!--
        $ver: v0.1.0
        버튼 내부에 위치할 컨텐츠 영역입니다. 아이콘을 사용하실 경우엔 비워놓고 icon 속성으로 표현 가능합니다.
        #The content area to place inside the button. If you use an icon, you can leave it blank and use the icon attribute.
     --><slot>
            <lego-icon v-if="icon" :icon="icon" sm/>
        </slot>
    </button>
</template>

<script>
export default {
    name :'lego-floating-button',
    props :{
        // $ver: v0.1.0
        // 버튼에 표현될 아이콘을 지정합니다. <em>lego-icon</em>을 참조하셔서 사용하시면 됩니다.
        // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
        // #Specifies the icon to be displayed on the button. Please refer to <em>lego-icon</em>.
        // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
        icon: {type:String , default:''},

        // $ver: v0.1.0
        // 비활성화 상태로 전환합니다.
        // #Switch to inactive state.
        disabled: {type :Boolean, default: false},

        // $ver: v0.1.0
        // Primary 색상으로 표현합니다.
        // #It is expressed in primary color.
        primary: {type :Boolean, default: false},

    },
    data() { return {
        pressed: {type :Boolean, default: false},
    };},
    computed : {
        cColor() {
            if (this.primary) { return '-prim'; }
            return '';
        },
        buttonClass() {
            return [
                'lego-floating-button',
                'lego-floating-button'+this.cColor,
                (!this.primary)?
                {
                    'lego-floating-button-disabled' : this.disabled
                }:{
                    'lego-floating-button-prim-disabled' : this.disabled
                }
            ];
        },
    }
};

</script>