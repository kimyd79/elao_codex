import legoFloatingButton from "./legoFloatingButton.vue";
export default {
    install(Vue){
        Vue.component(legoFloatingButton.name, legoFloatingButton);

    }
};