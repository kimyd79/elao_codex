<template>
    <div @mouseover="hover = true"
         @mouseleave="hover = false; pressed = false"
         @mousedown="pressed = true"
         @mouseup="pressed = false; selected = !selected"
         :class="containerClass">
        <img v-if="imgSrc" :src="imgSrc" :class="imgClass">
        <lego-icon v-if="icon" :class="iconClass" icon-type="picto" >{{icon}}</lego-icon>
        <div :class="slotClass"><!-- 
            $ver: v0.1.0
            칩 내부에 위치하는 문자열 입니다.
            #A string located inside the chip.
         --><slot ></slot>
        </div>
        <lego-icon v-if="removable" :class="closeClass" spacing icon="close" icon-type="picto" @click="onClick"></lego-icon>
    </div>
</template>

<script>
    import eventBus from './EventBus';
    export default {
        /* TODO: lego-chip전체적으로 개편이 필요합니다... */

        name: "legoChip",
        data() {
            return {
                hover: false,
                pressed: false,
                selected: false,
                default:{size: 'medium'}
            };
        },
        props: {
            // $ver: v0.1.0
            // 이미지 파일 경로입니다. 입력되지 않으면 칩의 이미지가 표시되지 않습니다.
            // #Image file path. If not input, the image of the chip will not be displayed.
            imgSrc: {
                type:String,
                default:'',
            },

            // $ver: v0.1.0
            // 크기 입니다. 'medium','small' 두 가지 중 하나를 입력해야 합니다.
            // #The size You must enter one of two types: medium or small.
            // $deprecated
            size:{
                validator: function (value) {
                    // The value must match one of these strings
                    return ['medium', 'small'].indexOf(value) !== -1
                },
            },

            // $ver: v0.1.2
            // 기본크기 사이즈로 표현합니다.
            // #Expressed in the default size.
            // $default: false
            medium: {type:Boolean, default: false},
            // $abbr: medium
            md: {type:Boolean, default: false},
            // $ver: v0.1.2
            // 작은크기 사이즈로 표현합니다.
            // #Expressed in small size.
            // $default: false
            small: {type:Boolean, default: false},
            // $abbr: small
            sm: {type:Boolean, default: false},

            // $ver: v0.1.0
            // 색상 유형 입니다. 'normal','thick','light' 세 가지 유형 중 하나를 입력해야 합니다.
            // #The color type. You must enter one of three types: 'normal', 'thick', 'light'.
            colorType:{
                validator: function (value) {
                    // The value must match one of these strings
                    return ['normal', 'thick', 'light'].indexOf(value) !== -1
                },
                default:'normal',
            },

            // $ver: v0.1.0
            // 텍스트 앞에 아이콘을 표시할 경우 사용하는 속성입니다.
            // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
            // #This property is used to display an icon before the text.
            // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
            icon:{
                type:String,
                default:''
            },

            // $ver: v0.1.0
            // 속성 선언 시 우측에 X버튼을 표시하여 클릭 시 삭제되도록 할 수 있습니다.
            // #When declaring an attribute, X button can be displayed on the right so that it can be deleted when clicked.
            // $default: false
            removable:{
                type:Boolean,
                default:false
            },

            // $ver: v0.1.0
            // 비활성화 여부입니다. 클릭할 수 없는 상태로 바뀝니다.
            // #Whether to disable It becomes unclickable.
            // $default: false
            disabled:{
                type:Boolean,
                default:false
            },

            // $ver: v0.1.0
            // 삭제 처리 및 이벤트 발생을 위한 자기자신 참조 객체 속성입니다.
            // #Self-referenced object property for handling deletes and raising events.
            item:{
                type:Object,
            },

            // $ver: v0.1.0
            // 삭제 처리 시 실행할 함수 입니다.
            // #Function to execute when deleting.
            delete: {
                type:Function,
            }
        },
        computed: {
            cSize() {
                if(this.size) {
                    console.warn("[LEGO-CHIP] props:size was deprecated from v0.1.2. use medium or small flag props.");
                    return this.size;
                }
                if(this.medium || this.md) return 'medium';
                if(this.small || this.sm) return 'small';
                return this.default.size;
            },
            containerClass() {
                return this.disabled ? [
                    'lego-chip__container',
                    'lego-chip__container-' + this.cSize,
                    !this.imgSrc && 'lego-chip__container-non-image',
                    'lego-chip__container-disabled'
                ] : [
                    'lego-chip__container',
                    'lego-chip__container-' + this.cSize,
                    !this.imgSrc && 'lego-chip__container-non-image',
                    'lego-chip__container-' + this.colorType + '-' + (this.removable ? 'input':'filter'),
                    !this.removable && this.selected &&  'lego-chip__container-' + this.colorType + '-filter-selected',
                ];
            },
            imgClass() {
                return [
                    'lego-chip__image',
                    'lego-chip__image-' + this.cSize
                ];
            },
            slotClass() {
                return [
                    'lego-chip__slot',
                    this.icon && this.cSize==='small' && 'lego-chip__slot-small',
                    'lego-chip__slot-' + this.colorType + (this.removable ? '-input': '-filter'),
                    this.disabled && 'lego-chip__slot-disabled'
                ];
            },
            iconDivClass() {
                return [
                    'lego-chip__icon-div',
                    'lego-chip__icon-div-' + this.cSize
                ];
            },
            iconClass() {
                return [
                    'lego-chip__icon' + this.cSize,
                    'lego-chip__icon-' + this.colorType
                ];
            },
            closeClass() {
                return this.disabled ? [
                    'lego-chip__icon',
                    'lego-chip__close-' + this.cSize,
                    'lego-chip__close-disabled'
                ] : [
                    'lego-chip__icon',
                    'lego-chip__close-' + this.cSize,
                    'lego-chip__close-' + this.colorType + '-input',
                    this.hover && 'lego-chip__close-' + this.colorType + '-input-hover',
                    this.pressed && 'lego-chip__close-' + this.colorType + '-input-active',
                ];
            },
            iconSize(){
                return this.cSize==='medium'? 8:6;
            }
        },
        methods: {
            onClick() {
                if(this.delete){
                    this.delete(this.item);
                }
            },
        }
    }
</script>