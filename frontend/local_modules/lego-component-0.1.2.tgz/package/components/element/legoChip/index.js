import legoChip from "./legoChip.vue";
import legoChipWraper from "./legoChipWrapper.vue";
export default {
    install(Vue){
        Vue.component(legoChip.name, legoChip);
        Vue.component(legoChipWraper.name, legoChipWraper);
    }
};