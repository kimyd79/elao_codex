<template >
    <div class="lego-chip-wrapper__container">
        <template v-for="(chip,i) in value" >
            <lego-chip class="lego-chip-wrapper__item" :key="i"
                       :size="chip.size"
                       :color-type="chip.colorType"
                       :removable="chip.removable"
                       :img-src="typeof chip.imgSrc === 'function' ? chip.imgSrc() : ''"
                       :icon="chip.icon"
                       :disabled="chip.disabled"
                       :item="chip"
                       :delete="onCloseClick">{{chip.value}}</lego-chip>
        </template>
    </div>
</template>

<script>
    import eventBus from './EventBus';
    export default {
        name: "legoChipWrapper",
        props: {
            // $ver: v0.1.0
            // $v-model
            // v-model로 바인딩 되는 값으로, <em>lego-chip</em> 에서 사용되는 속성 값을 가지는 객체의 배열 입니다.
            // 입력된 배열만큼 칩 컴포넌트가 생성됩니다.
            value: [Array, Object],

            // $ver: v0.1.0
            // 사용하지 않는 속성입니다.
            chips: [Array, Object],
        },
        mounted() {
            eventBus.$on('onCloseClick', (item) => {
                // console.log('onCloseClick' +    JSON.stringify(this.value));
            })
        },
        computed: {
        },
        methods: {
            onCloseClick (item) {
                if(item && this.value.indexOf(item) > -1) {
                    this.value.splice(this.value.indexOf(item), 1);
                }
            }
        }
    }
</script>