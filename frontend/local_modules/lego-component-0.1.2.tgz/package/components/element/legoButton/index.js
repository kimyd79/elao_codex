import legoButton from "./legoButton.vue";
export default {
    install(Vue){
        Vue.component(legoButton.name, legoButton);
    }
};