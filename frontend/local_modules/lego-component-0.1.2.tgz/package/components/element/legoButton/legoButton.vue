<template>
    <button :class="buttonClass" :style="buttonStyle" v-on="cListeners" ><!-- 
     --><lego-icon v-if="icon" :icon="icon" class="lego-button__icon" :class="iconClass"/><!-- 
        $ver: v0.1.0
        버튼 내부에 위치하는 영역입니다. 일반적으로 버튼 텍스트가 사용됩니다.
        #The area located inside the button. Typically button text is used.
     --><slot/>
    </button>
</template>

<script>
export default {
    name :'lego-button',
    inject: {
        legoInput: {from:'legoInput', default: () => undefined}
    },
    props : {
        // $ver: v0.1.0
        // Solid 버튼 유형 여부입니다. true/false 값을 할당하지 않고 해당 Prop을 선언만 하면 동작합니다.
        // #Express Button as Solid. Just declare the prop without assigning it a true / false value and it will work.
        // $default: false
        solid      : {type: Boolean, default: false},

        // $ver: v0.1.0
        // Border 버튼 유형 여부입니다.
        // #Express Button as Border
        // $default: true
        border     : {type: Boolean, default: true},

        // $ver: v0.1.0
        // Borderless 버튼 유형 여부입니다.
        // #Express Button as Borderless
        // $default: false
        borderless : {type: Boolean, default: false},

        // $ver: v0.1.0
        // Hyperlink 버튼 유형 여부입니다.
        // #Express Button as Hyperlink
        // $default: false
        hyperlink: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 버튼명 앞에 표시될 아이콘 입니다. <em>lego-icon</em> 과 같이 사용되는 아이콘 문자열을 참조해서 사용하시면 됩니다.
        // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
        // #Icon to display. Enter a value by referring to the OPUS Icon name
        // #You can refer to the icon string used with <em>lego-icon</em>.
        // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
        icon    : {type: String, default: ''},

        // $ver: v0.1.0
        // 버튼 비활성화 여부입니다.
        // #Whether to handle button deactivation
        // $default: false
        disabled: {type: Boolean, default: false},

        // $ver: v0.1.0
        // #Whether to show status while button is loading
        // $default: false
        loading : {type: Boolean, default: false},

        // $ver: v0.1.0
        // Primary 색상 여부입니다.
        // #Whether to be primary color
        // $default: false
        primary: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Point 색상 여부입니다.
        // #Whether the Point color
        // $default: false
        point  : {type: Boolean, default: false},

        // $ver: v0.1.0
        // 커스텀 색상 표현을 위한 문자열 입니다.
        // #String for custom color representation.
        color  : {type:String, default: undefined},

        // $ver: v0.1.0
        // 버튼의 크기가 컨테이너에 꽉 차도록 표현합니다.
        // #Makes the button fill the container.
        // $default: false
        full : {type: Boolean, default: false},

        // $ver: v0.1.0
        // 버튼 크기를 Large로 표현합니다.
        // #Expresses the button size as Large.
        // $default: false
        large : {type: Boolean, default: false},

        // $ver: v0.1.0
        // 버튼 크기를 Medium으로 표현합니다.
        // #Expresses the button size as Medium.
        // $default: false
        medium : {type: Boolean, default: false},

        // $ver: v0.1.0
        // 버튼 크기를 Small로 표현합니다.
        // #Represents the button size as Small.
        // $default: false
        small: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: border
        bor: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: solid
        sol: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: borderless
        bLess: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: hyperlink
        hl: {type:Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: primary
        prim: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: point
        pnt: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: color
        col: {type: String, default: undefined},

        // $ver: v0.1.0
        // $abbr: large
        lg: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: medium
        md: {type: Boolean, default: false},

        // $ver: v0.1.0
        // $abbr: small
        sm: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Solid 형태, Primary 색상 버튼을 지정하는 Prop 입니다. 주요 버튼을 표현하는 데 사용됩니다.
        // #Prop that specifies Solid, Primary color button. Used to represent the main button.
        // $default: false
        main: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Toggle 형태 버튼 여부입니다. 일반적으로 아이콘만 활용한 형태로 사용됩니다.
        // #Toggle type button. Generally, only icons are used.
        // $default: false
        toggle : {type: Boolean, default: false},

        // $ver: v0.1.0
        // 버튼 숨김처리 여부입니다. 숨김처리 되어도 기존 버튼의 영역만큼 공간을 차지합니다.
        // #Whether to hide buttons. Even if hidden, it takes up as much space as the existing button.
        // $default: false
        hidden : {type: Boolean, default: false},
    },
    data() { return {
        default: {
            size: 'medium',
            style: 'border',
            color: 'default'
        },
        isLoading: false,
        customColor: false,
    }},
    computed : {
        /* [FLAG] isSlot */
        isSlot() {return !!this.$slots.default;},
        isHyperLink() {return this.hyperlink||this.hl},
        /* [VALUE] Color value */
        isColorPrimary()  {return this.primary||this.prim||this.main},
        isColorPoint()    {return this.point||this.pnt},
        isColorCustom()   {return !!this.color||!!this.col},
        cCustomColor()    {return this.color||this.col}, // real color value
        /* [VALUE] Style flag */
        isStyleBorderless() {return this.toggle || this.borderless || this.bLess},
        isStyleSolid()      {return this.solid || this.sol || this.main},
        isStyleHyperlink()  {return this.isHyperLink},
        isHidden()          {return this.hidden},
        /* [VALUE] Size flag */
        cColor() {
            if (this.isColorPrimary) { return 'primary'; }
            if (this.isColorPoint) { return 'point'; }
            if (this.isColorCustom && this.toggle) { return 'toggle';}
            if (this.isColorCustom) { return this.cCustomColor; }
            return this.default.color;
        },
        cStyle() {
            if(this.isStyleHyperlink ) {return 'hyperlink';}
            if(this.isStyleSolid     ) {return 'solid';}
            if(this.isStyleBorderless) {return 'borderless';}
            return this.default.style;
        },
        cSize() {
            if(this.large||this.lg) {return 'large';}
            if(this.medium||this.md) {return 'medium';}
            if(this.small||this.sm) {return 'small';}
            if(this.legoInput) {return this.legoInput.size}
            return this.default.size;
        },
        cListeners() {
            if(this.loading || this.disabled) {
                return null;
            } else {
                return this.$listeners;
            }
        },
        buttonClass() {
            return [
                'lego-button',
                'lego-input',
                {
                    'lego-button--loading' : this.isLoading,
                    'lego-button--disabled': this.disabled || this.isHidden,
                    'lego-button--full'    : this.full
                },
                this.cStyle && 'lego-button--'+this.cStyle,
                this.cColor && 'lego-button--'+this.cColor,
                this.cSize  && 'lego-button--'+this.cSize,
            ];
        },
        buttonStyle() {
            let style = {};
            if (this.isColorCustom) {style.color = this.cCustomColor;}
            if (this.isLoading) {style.color = 'transparent !important';}
            if (this.isHidden)  {style.opacity = 0}
            return style;
        },
        iconClass() {
            let clazz= [];
            if(this.isSlot) {clazz.push("lego-button__icon--with-slot")}
            return clazz;
        }
    },
    watch: {
        loading(isLoading) {
            isLoading? this.isLoading = true : this.isLoading = false;
        },
    },
    created(){
        this.loading? this.isLoading=true: this.isLoading=false;
    },
    methods:{
        // @vuese
        // $ver: v0.1.0
        // $return: N/A
        // 버튼을 로딩중 상태로 전환합니다. 버튼에 로딩중 표시가 나타나고 클릭이 되지 않습니다.
        // #Switch the button to the loading state. The loading indicator appears on the button and it cannot be clicked.
        loadingStart() {
            this.isLoading = true;
        },
        // @vuese
        // $ver: v0.1.0
        // $return: N/A
        // 버튼을 로딩중 상태에서 정상 상태로 전환합니다.
        // #Switch the button from loading to normal.
        loadingEnd() {
            this.isLoading = false;
        },
    }
};
</script>
