<script>
    export default {
        name: 'lego-tree-node',
        functional: true,
        props: {
            node: {type:Object, required:true},
            position: {type:Array, required: true}
        },
        inject: ['checkbox', 'labelInfo', 'labelAction', 'inlineEdit', 'rules', // props or data
            'reRender', 'onClickNode', 'onClickExpand','onClickCheckbox',
            'emitClickDeleteButton', 'emitClickEditButton',
            'dragstart', 'dragleave', 'dragenter', 'dragend'], // methods
        render(h, {data, props, injections, listeners, children, scopedSlots}) {
            let node = props.node;
            let treeInfo = props.node.treeInfo;
            let childNodes = props.node.children;
            let onClickNode = (e) => injections.onClickNode(e, node,props.position);
            let onClickExpand = (e) => injections.onClickExpand(e, node);
            let onClickCheckbox = (e) => injections.onClickCheckbox(e, node, props.position);
            let emitClickDeleteButton = (e) => injections.emitClickDeleteButton(e, node, props.position);
            let emitClickEditButton = (e) => injections.emitClickEditButton(e, node, props.position);
            let dragstart = (e) => injections.dragstart(e, props.position);
            let dragleaveOnLabel = (e) => {
                clearTimeout(e.target._expandOnTimeout);
                return injections.dragleave(e);
            };
            let dragenterOnLabel = (e) => {
                e.target._expandOnTimeout = setTimeout(() => onClickExpand(e,true), 1000);
                injections.dragenter(e, node);
            };
            let dragleave = (e) => injections.dragleave(e);
            let dragenter = (e) => injections.dragenter(e);
            let dragendOnHeader = (e) => injections.dragend(e, props.position, 'BEFORE');
            let dragendOnLabel = (e) => injections.dragend(e, props.position, 'CHILD');
            let dragendOnFooter = (e) => injections.dragend(e, props.position, 'AFTER');

            let toggleIcon ='';
            if(!!treeInfo.hasChild) {
                toggleIcon= h('lego-icon',{
                    props: {
                        icon: treeInfo.expanded ? 'remove':'add',
                        spacing: true,
                        iconSize: 16,
                    },
                    on: {
                        click: onClickExpand
                    }
                });
            }

            let toggleButton = h('lego-icon-wrapper',{
                class: 'lego-tree-node__contents__toggle-button',
            },[
                toggleIcon
            ]);

            let checkbox = '';
            let $_checkIcon = treeInfo.checked;
            if(typeof $_checkIcon !== 'string') {
                $_checkIcon = $_checkIcon ? 'checked':'box';
            }
            if(injections.checkbox) {
                checkbox = h('div',{
                    class: {
                        'lego-tree-node__contents__checkbox': true,
                        'lego-tree-node__contents__checkbox--checked': treeInfo.checked
                    }
                },[
                    h('lego-icon',{
                        props: {
                            icon: $_checkIcon,
                            iconSize: 16,
                            iconType: 'picto'
                        },
                        on: {
                            click: onClickCheckbox
                        }
                    })
                ]);
            }

            let label;
            if(treeInfo.inlineEdit) {
                let validateAndUpdate = (e) => {
                    // label.componentInstance not exist. but will be hoisted after mount complete
                    if(label.componentInstance.validate() === true) {
                        treeInfo.inlineEdit = false;
                        injections.reRender();
                    }
                };
                label = h('lego-text-field', {
                    props: {
                        small: true,
                        value: treeInfo.name,
                        rules: injections.rules
                    },
                    on: {
                        click: (e) => {e.stopPropagation();},
                        input: (newVal) => {treeInfo.name = newVal;},
                        blur: validateAndUpdate,
                        enter: validateAndUpdate
                    }
                });
            } else {
                label = scopedSlots['treeNodeLabel'] && scopedSlots['treeNodeLabel']({node: props.node});
                if(!label) {
                    if(typeof(injections.labelInfo) === 'function') {
                        label = injections.labelInfo(props.node);
                    } else if(typeof(injections.labelInfo) === 'object' && injections.labelInfo.field) {
                        label = [];
                        for (let field of injections.labelInfo.field) {
                            let curr = props.node;
                            for(let keyword of field.split('.')) {
                                curr = curr[keyword];
                            }
                            label.push(curr);
                        }
                        label = label.join(injections.labelInfo.separator || '');
                    } else {
                        label = '';
                    }
                }
            }
            let labelActionGroup ='';
            if(injections.labelAction) {
                labelActionGroup = h('div', {
                    class: 'lego-tree-node__contents__action-group'
                },[
                    h('lego-icon-wrapper', {
                        class: 'lego-tree-node__contents__action-icon',
                    }, [
                        h('lego-icon',{
                            props: {
                                icon: 'modify',
                                iconSize: '14px',
                            },
                            on: {
                                click: injections.inlineEdit
                                    ? (e) => {
                                        e.stopPropagation();
                                        treeInfo.inlineEdit=true;
                                        injections.reRender(); }
                                    : emitClickEditButton
                            }
                        })
                    ]),
                    h('lego-icon-wrapper', {
                        class: 'lego-tree-node__contents__action-icon',
                    }, [
                        h('lego-icon', {
                            props: {
                                icon: 'delete',
                                iconSize: '14px',
                            },
                            on: {
                                click: emitClickDeleteButton
                            }
                        })
                    ]),
                ])
            }
            let contentsLabel = h('div',{
                class: {
                    'lego-tree-node__contents__label': true,
                    'lego-tree-node__contents__label--inline-edit': treeInfo.inlineEdit,
                    'lego-tree-node__contents__label--with-action-group': injections.labelAction
                },
                attrs: { draggable: true },
                style: treeInfo.inlineEdit?'line-height:0;overflow:visible;':'',
                on: {
                    click: onClickNode,
                    dragstart: dragstart,
                    dragenter: dragenterOnLabel,
                    dragleave: dragleaveOnLabel,
                    dragover: (e) => e.preventDefault(),
                    drop: dragendOnLabel
                }
            },[
                label,
                labelActionGroup
            ]);

            let content = h('div', {
                class: {
                    'lego-tree-node__contents': true,
                    'lego-tree-node__contents--searched': treeInfo.searched,
                    'lego-tree-node__contents--selected': treeInfo.selected,
                    'lego-tree-node__contents--root': treeInfo.depth===0,
                }
            }, [
                toggleButton,
                checkbox,
                contentsLabel
            ]);

            let childrenWrapper = '';
            if(treeInfo.hasChild && treeInfo.expanded){
                let childTreeNodes = [];
                let idx = 0;
                if(childNodes && childNodes.length > 0) {
                    for (let child of childNodes) {
                        let childPosition = props.position.slice(0);
                        childPosition.push(idx);
                        childTreeNodes.push(
                            h('lego-tree-node', {
                                props: {
                                    node: child,
                                    position: childPosition
                                },
                                scopedSlots:scopedSlots
                            })
                        );
                        idx += 1;
                    }
                } else {
                    childTreeNodes.push(
                        h('div', {

                        }, [
                            'loading...' // FIXME: 임시로 넣어놓음. 추후 수정필요
                        ])
                    )
                }
                childrenWrapper = h('div',{
                    class: 'lego-tree-node__vertical-line'
                }, childTreeNodes)
            }

            let contentHeader = '';
            if(props.position[props.position.length-1]===0) {
                contentHeader = h('div', {
                    class: 'lego-tree-node__header',
                    on: {
                        dragenter: dragenter,
                        dragleave: dragleave,
                        dragover: (e) => e.preventDefault(),
                        drop: dragendOnHeader
                    }
                });
            }

            let contentFooter = h('div', {
                class: 'lego-tree-node__footer',
                on: {
                    dragenter: dragenter,
                    dragleave: dragleave,
                    dragover: (e) => e.preventDefault(),
                    drop: dragendOnFooter
                }
            });

            return h('div', {
                class: 'lego-tree-node',
            }, [
                contentHeader,
                content,
                childrenWrapper,
                contentFooter
            ]);
            /*
            * <div class="lego-tree-node">
            *     <content-header />
            *     <content />
            *     <childrenWrapper />
            *     <contentFooter />
            * </div>
            * */
        },
    };

</script>