import legoTree from "./legoTree.vue";
export default {
    install(Vue){
        Vue.component(legoTree.name, legoTree);
    }
};