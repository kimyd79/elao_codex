<template>
    <div class="lego-tree" @click="onClickNode"><!--
        $ver: v0.1.0
        트리 상단에 표시되는 Expand All, Collapse All, Add 버튼 영역에 대한 전체 Slot 입니다.
        #Slot for the Expand All, Collapse All, and Add button areas displayed at the top of the tree.
     --><slot name="actionGroup"
              :expandAll="expandAll"
              :collapseAll="collapseAll"
              :selectedNode="selectedNode">
              <!--:checkedSet="checkedNode">-->
            <lego-action-bar class="lego-tree__btn-group">
                <!--TODO: 다국어처리-->
                <template slot="left"><!--
                    $ver: v0.1.0
                    트리 상단에 표시되는 좌측 버튼 영역 입니다. 기본적으로 Expand All, Collapse All 버튼이 표시됩니다.
                    #This is the right button area displayed at the top of the tree. By default, the Expand All and Collapse All buttons are displayed.
                --> <slot name="actionGroupLeft"
                          :expandAll="expandAll"
                          :collapseAll="collapseAll"
                          :emitClickAddButton="emitClickAddButton"
                          :selectedNode="selectedNode">
                        <lego-button small @click.stop="expandAll">Expand All</lego-button>
                        <lego-button small @click.stop="collapseAll">Collapse All</lego-button>
                    </slot>
                </template>
                <!--
                    $ver: v0.1.0
                    트리 상단에 표시되는 우측 버튼 영역 입니다. 기본적으로 Add 버튼이 표시됩니다.
                    #This is the left button area displayed at the top of the tree. By default, the Add buttons are displayed.
                -->
                <slot name="actionGroupRight"
                      :expandAll="expandAll"
                      :collapseAll="collapseAll"
                      :emitClickAddButton="emitClickAddButton"
                      :selectedNode="selectedNode">
                    <lego-button :hidden="hideAdd" small @click.stop="emitClickAddButton"> Add </lego-button>
                </slot>
            </lego-action-bar>
        </slot>

        <hr class="lego-tree__divider" />

        <div v-if="!value || value.length === 0">No item</div>
        <div class="lego-tree__contents">
            <lego-tree-node
                v-for="(node, idx) in value"
                :key="idx"
                :node="node"
                :position="[idx]">
                <template v-slot:treeNodeLabel="labelScope">
                    <!--
                    $ver: v0.1.2
                    이거 왜 vuese parser가 인식을 못하니...
                    -->
                    <slot name="treeNodeLabel" v-bind="labelScope"/>
                </template>
            </lego-tree-node>
        </div>
    </div>
</template>

<script>
    import legoTreeNode from './legoTreeNode';

    export default {
        name: 'lego-tree',
        components: {legoTreeNode},
        props: {
            // $ver: v0.1.0
            // $v-model
            // v-model로 바인딩되는 값으로, 트리에 표현할 항목의 배열입니다. 
            // 각 항목은 treeInfo 속성 아래에 고유의 속성을 할당할 수 있으며, 
            // children 속성에 하위 트리로 표현할 항목의 배열을 가지는 구조입니다.
            // #The value bound to v-model, an array of items to render in the tree.
            // #Each item can be assigned its own property under the treeInfo property, 
            // #which is a structure with an array of items to represent as a subtree in the children property.
            value: {type: Array, required: false},

            // $ver: v0.1.0
            // 각 항목의 앞에 체크박스를 사용할 지 여부입니다.
            // #Whether to use a checkbox in front of each item.
            // $default: false
            checkbox: {type: Boolean, default: false},

            // $ver: v0.1.2
            // 항목에 표현될 Label 값을 커스텀하는 속성입니다.
            // field목록과 saparator를 갖는 Object형태 혹은 Function형태로 사용할 수 있으며
            // 기본적으로 treeInfo.name을 표시합니다.
            // #This property customizes the Label value to be displayed in the item.
            // #It can be used in the form of an Object or Function with a field list and a saparator. By default, treeInfo.name is displayed.
            nodeLabel: {
                type: [Object,Function],
                default: () => ({
                    field: ['treeInfo.name'],
                    separator: '/'
                })
            },

            // $ver: v0.1.0
            // 항목의 우측에 수정, 삭제 버튼을 표시할 지 여부입니다. 각 버튼에 대한 동작은 직접 구현해야 합니다.
            // #Whether to display the edit or delete button on the right side of the item. You must implement the behavior for each button yourself.
            // $default: false
            labelAction: {type: Boolean, default: false},

            // $ver: v0.1.0
            // labelAction 속성이 true일 때, 표시되는 수정 버튼으로 항목 값을 수정할 수 있습니다.
            // #When the labelAction property is true, the modify button that is displayed allows you to modify the item value.
            // $default: false
            inlineEdit: {type: Boolean, default: false},

            // $ver: v0.1.0
            // inlineEdit 속성이 true일 때, 입력되는 값에 대한 유효성 검사를 위한 규칙을 설정할 수 있습니다. 
            // <em>lego-text-field</em>의 Validation을 위한 Rule을 입력하는 부분과 동일합니다.
            // #When the inlineEdit property is true, you can set a rule for validating values ​​that are entered.
            // #This is the same as entering Rule for Validation of <em>lego-text-field</em>.
            rules: {type: Array, default: ()=>[]},

            // $ver: v0.1.0
            // Add 버튼을 숨김처리 합니다.
            // #Hide the Add button.
            // $default: false
            hideAdd : {type: Boolean, default: false},
        },
        data() {return {
            selectedNode: undefined,
            dragInfo: {
                from: [],
                to: [],
                type: '' // BEFORE, AFTER, CHILD
            }
        }},
        provide(){return {
            checkbox: this.checkbox,
            labelInfo: this.nodeLabel,
            labelAction: this.labelAction,
            inlineEdit: this.inlineEdit,
            rules: this.rules,
            reRender: this.reRender,
            onClickNode: this.onClickNode,
            onClickExpand: this.onClickExpand,
            onClickCheckbox: this.onClickCheckbox,
            emitClickDeleteButton: this.emitClickDeleteButton,
            emitClickEditButton: this.emitClickEditButton,
            dragstart: this.dragstart,
            dragenter: this.dragenter,
            dragleave: this.dragleave,
            dragend: this.dragend,
        }},
        watch: {
            selectedNode() {
                this.emitSelectNode();
            }
        },
        created() {
        },
        methods: {
            /*****************
            * EVENT HANDLING *
            *****************/
            emitClickAddButton(e, selectedNode, posArray) {
                if(e instanceof Event) {e.stopPropagation();}
                if(selectedNode === undefined) {
                    selectedNode = Array.isArray(this.selectedNode)? this.selectedNode[0]: {};
                }
                if(posArray === undefined) {
                    posArray = Array.isArray(this.selectedNode)? this.selectedNode[1]: [];
                }
                // $ver: v0.1.0
                // $arg: button click event, selected node, position array
                // 트리 상단의 Add 버튼 클릭 시, 현재 선택된 노드 정보를 파라미터로 이벤트를 발생시킵니다.
                // #Clicking the Add button at the top of the tree will trigger an event with the currently selected node information as a parameter.
                this.$emit('addButton', e, selectedNode, posArray);
            },
            emitClickDeleteButton(e, selectedNode, posArray) {
                if(e instanceof Event) {e.stopPropagation();}
                if(selectedNode === undefined) {
                    selectedNode = Array.isArray(this.selectedNode)? this.selectedNode[0]: {};
                }
                if(posArray === undefined) {
                    posArray = Array.isArray(this.selectedNode)? this.selectedNode[1]: [];
                }
                // $ver: v0.1.0
                // $arg: button click event, selected node, position array
                // labelAction 속성으로 보이는 삭제 버튼 클릭 시, 해당 노드 정보를 파라미터로 이벤트를 발생시킵니다.
                // #When the delete button shown in the labelAction property is clicked, an event is triggered using the node information as a parameter.
                this.$emit('deleteButton',e, selectedNode, posArray);
            },
            emitClickEditButton(e, selectedNode, posArray) {
                if(e instanceof Event) {e.stopPropagation();}
                if(selectedNode === undefined) {
                    selectedNode = Array.isArray(this.selectedNode)? this.selectedNode[0]: {};
                }
                if(posArray === undefined) {
                    posArray = Array.isArray(this.selectedNode)? this.selectedNode[1]: [];
                }
                // $ver: v0.1.0
                // $arg: button click event, selected node, position array
                // labelAction 속성으로 보이는 수정 버튼 클릭 시, 해당 노드 정보를 파라미터로 이벤트를 발생시킵니다.
                // #When the edit button clicked on the labelAction property is clicked, an event is triggered using the node information as a parameter.
                this.$emit('editButton',e, selectedNode, posArray);
            },
            emitSelectNode(e) {
                if(e instanceof Event) {e.stopPropagation();}
                let selectedNode = Array.isArray(this.selectedNode)? this.selectedNode[0]: {};
                let posArray = Array.isArray(this.selectedNode)? this.selectedNode[1]: [];

                // $ver: v0.1.0
                // $arg: button click event, selected node, position array
                // 선택된 노드가 변경될 경우, 해당 노드 정보를 파라미터로 이벤트를 발생시킵니다.
                // #When the selected node is changed, an event is triggered using the node information as a parameter.
                this.$emit('selectNode', e, selectedNode, posArray);
            },
            emitMoveNode() {
                let fromNode = {
                    children: this.value
                };
                let fromCurr = [];
                for(let idx of this.dragInfo.from) {
                    fromCurr = fromNode.children;
                    fromNode = fromCurr[idx];
                }
                let toNode = {
                    children: this.value
                };
                let toCurr = [];
                for(let idx of this.dragInfo.to) {
                    toCurr = toNode.children;
                    toNode = toCurr[idx];
                }
                // $ver: v0.1.0
                // $arg: drag from to information object, from node, to node
                // 노드를 드래그&드랍으로 옮길 경우, 해당 노드 정보를 파라미터로 이벤트를 발생시킵니다.
                // #When dragging and dropping a node, an event is triggered using the node information as a parameter.
                this.$emit('moveNode', this.dragInfo, fromNode, toNode);
            },
            reRender() {
                // make dirty flag for force update
                this.value.splice(0,0);
                // $ver: v0.1.0
                // $arg: tree value array object
                // 트리가 다시 랜더링 될 경우, 현재 트리의 데이터 정보(value)를 파라미터로 이벤트를 발생시킵니다.
                // #When the tree is rendered again, an event is triggered with the data value of the current tree as a parameter.
                this.$emit('input', this.value);
            },
            onClickNode(e, node, position){
                if(e instanceof Event) {e.stopPropagation();}
                if(this.selectedNode && this.selectedNode[0] && this.selectedNode[0].treeInfo) {
                    if(node && node.treeInfo
                        && this.selectedNode[0].treeInfo.key === node.treeInfo.key) {
                        this.onClickExpand(e, node);
                    }
                    this.selectedNode[0].treeInfo.selected = false;
                }
                if(node && node.treeInfo) {
                    node.treeInfo.selected = true;
                }
                if(node === undefined && position === undefined) {
                    this.selectedNode = undefined;
                } else {
                    this.selectedNode = [node, position];
                }
                this.reRender();
            },
            onClickExpand(e, node){
                if(e instanceof Event) {e.stopPropagation();}
                if(node && node.treeInfo) {
                    if(node.treeInfo.hasChild) {
                        node.treeInfo.expanded = !node.treeInfo.expanded;
                    }
                }
                this.reRender();
            },
            onClickCheckbox(e, node, position){
                if(e instanceof Event) {e.stopPropagation();}
                if(!(node && node.treeInfo && this.checkbox)) {this.reRender();return;}
                if(node.treeInfo.checked === 'indeterminate' || !node.treeInfo.checked) {
                    node.treeInfo.checked = true;
                    this.setChildrenChecked(node, true);
                } else if (node.treeInfo.checked) {
                    node.treeInfo.checked = false;
                    this.setChildrenChecked(node, false);
                }
                let curr = this.value;
                let pPath = new Array(position.length-1),i=0;
                let pNode;
                for (let i = 0, ii = position.length - 1; i < ii; i++) {
                    pPath[i] = pNode = curr[position[i]];
                    curr = pNode.children;
                }
                pPath.reverse().filter(node=>{return !checkChild(node)});
                this.reRender();
                function checkChild(node) {
                    let tCount = node.children.filter(ch=>!!ch.treeInfo.checked).length;
                    let oldFlag = node.treeInfo.checked,
                        newFlag = tCount===0?false:tCount===node.children.length?true:'indeterminate';
                    if(oldFlag === newFlag) {return false;}
                    node.treeInfo.checked = newFlag;
                    return true;
                }
            },
            setChildrenChecked(node, b) {
                if(node.treeInfo.hasChild && node.children && node.children.length > 0) {
                    for(let child of node.children) {
                        child.treeInfo.checked = b;
                        this.setChildrenChecked(child, b);
                    }
                }
            },
            // @vuese
            // $ver: v0.1.0
            // $return: N/A
            // 모든 항목을 펼침 처리합니다.
            // #Expand all items.
            expandAll(e, nodeList = this.value) {
                if(e instanceof Event) {e.stopPropagation();}
                for(let child of nodeList) {
                    if(child && child.treeInfo && child.treeInfo.hasChild) {
                        child.treeInfo.expanded = true;
                        this.expandAll(e, child.children);
                    }
                }
                this.reRender();
            },
            // @vuese
            // $ver: v0.1.0
            // $return: N/A
            // 모든 항목을 닫힘 처리합니다.
            // #Close all items.
            collapseAll(e, nodeList = this.value) {
                if(e instanceof Event) {e.stopPropagation();}
                for(let child of nodeList) {
                    if(child && child.treeInfo && child.treeInfo.hasChild) {
                        child.treeInfo.expanded = false;
                        this.collapseAll(e, child.children);
                    }
                }
                this.reRender();
            },
            appendNode(newNode, position) {
                let pNode = {
                    children: this.value
                };
                let pos = position.slice(0);
                for(let idx of pos) {
                    pNode = pNode.children[idx];
                }
                pNode.children.push(newNode);
                pNode.treeInfo.hasChild = true;
                pNode.treeInfo.expanded = true;
                if(pNode.treeInfo.checked === true) {
                    newNode.treeInfo.checked = true;
                }
                this.reRender();
                // TODO: manage created list
            },
            deleteNode(node, position) {
                let pNode = {
                    children: this.value
                };
                let pos = position.slice(0);
                pos.pop();
                for(let idx of pos) {
                    pNode = pNode.children[idx];
                }
                let tIdx = pNode.children.indexOf(node);
                if(tIdx !== -1) {
                    pNode.children.splice(tIdx,1);
                }
                if(!pNode.children || pNode.children.length === 0) {
                    pNode.treeInfo.hasChild = false;
                    pNode.treeInfo.expanded = false;
                }
                this.reRender();
                // TODO: manage deleted list
            },
            updateNode(oldNode, newNode) {
                oldNode.treeInfo = {};
                oldNode.contents = {};
                oldNode.children = [];
                Object.assign(oldNode,newNode);
                this.reRender();
                // TODO: manage updated list
            },
            moveNode(dragInfo) {
                let fromPos = dragInfo.from;
                let toPos = dragInfo.to;
                let type = dragInfo.type;
                let fromNode = {
                    children: this.value
                };
                let fromCurr = [];
                for(let idx of fromPos) {
                    fromCurr = fromNode.children;
                    fromNode = fromCurr[idx];
                }
                let toNode = {
                    children: this.value
                };
                let toCurr = [];
                for(let idx of toPos) {
                    toCurr = toNode.children;
                    toNode = toCurr[idx];
                }
                let target = fromCurr.splice(fromPos[fromPos.length - 1], 1);
                if(type === 'BEFORE') {
                    toCurr.splice(toPos[toPos.length - 1], 0, target);
                } else if (type === 'AFTER') {
                    toCurr.splice(toPos[toPos.length], 0, target);
                } else if (type === 'CHILD') {
                    toNode.children.add(target);
                }
            },
            dragstart(e, position) {
                e.dataTransfer.dropEffect = "move";
                this.dragInfo.from = position;
            },
            dragleave(e) {
                e.target.classList.remove("lego-tree-node--drag-over");
            },
            dragenter(e) {
                e.target.classList.add("lego-tree-node--drag-over");
            },
            dragend(e, position, type) {
                e.preventDefault();
                e.target.classList.remove("lego-tree-node--drag-over");
                this.dragInfo.to = position;
                this.dragInfo.type = type;
                this.emitMoveNode();
            },
            // TODO: lazy loading은 나중에 ... 넣읍시다. 일단은 전체로딩만 사용
        }
    };

</script>