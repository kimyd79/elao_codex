<template functional>
    <notifications
        :width="props.width"
        :position="props.position"
        :duration="props.duration"
        :max="props.max"

        :group="props.group"
        :type="props.type"
        :classes="props.classes"
        :animationType="props.animationType"
        :animationName="props.animationName"
        :animation="props.animation"
        :speed="props.speed"
        :reverse="props.reverse"
        :closeOnClick="props.closeOnClick"
    />
</template>

<script>
    export default {
        name: 'lego-toast',
        props: {
            width: { // Width of notification holder, can be %, pxstring or number.Valid values: '100%', '200px', 200
                type: String,
                default: '50%',
            },
            position: { // Part of the screen where notifications will pop out
                type: String,
                default: 'bottom center'
            },
            duration: { // Time (ms) animation stays visible (if negative - notification will stay forever or until clicked)
                type: Number,
                default: 5000
            },

            /* Props provided by vendor, but not used in LEGO */
            group: {type: String, required: false}, // Name of the notification holder, if specified
            type: {type: String, required: false}, // Class that will be assigned to the notification
            classes: {type: [String, Array], default: 'vue-notification'}, // List of classes that will be applied to notification element
            animationType: {type: String, default: 'css'}, // Type of animation, currently supported types are css and velocity
            animationName: {type: String, required: false}, // Animation name required for css animation
            animation: {
                type: Object, // Animation configuration for Velocityanimation
                default: () => { return {enter: {opacity: [1, 0]}, leave: {opacity: [0, 1]}};}
            },
            max: {type: Number, default: Infinity}, // Maximum number of notifications that can be shown in notification holder
            speed: {type: Number, default: 300}, // Speed of animation showing/hiding
            reverse: {type: Boolean, default: false}, // Show notifications in reverse order
            closeOnClick: {type: Boolean, default: true}, // Close notification when clicked
        }
    };

</script>