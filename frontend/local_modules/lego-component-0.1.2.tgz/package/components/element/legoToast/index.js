import legoToast from "./legoToast.vue";
export default {
    install(Vue){
        Vue.component(legoToast.name, legoToast);
    }
};