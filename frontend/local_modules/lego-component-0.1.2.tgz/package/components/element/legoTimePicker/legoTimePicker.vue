<template>
    <div class="lego-timepicker" :value="getValue">
        <div class="lego-timepicker-time">
            <lego-counter v-model="time_hour" center :min="minHour" :max="maxHour" updown :disabled="this.disabled"></lego-counter>
            <lego-counter v-model="time_minute" center :min="0" :max="59" updown :disabled="this.disabled"></lego-counter>
        </div>
        <lego-segment-wrapper class="lego-timepicker-meridiem" primary v-model="mrdm">
            <lego-segment-button value="AM" ref="legoAMBtn">AM</lego-segment-button>
            <lego-segment-button value="PM" ref="legoPMBtn">PM</lego-segment-button>
        </lego-segment-wrapper>
    </div>
</template>

<script>
export default {
    name :'lego-time-picker',
    props :{
        // $ver: v0.1.0
        // 시간 값 속성 입니다. (1 ~ 12)
        // #This is a time value property. (1 to 12)
        hour: { type:Number, default:11},

        // $ver: v0.1.0
        // 분 값 속성 입니다. (0 ~ 59)
        // #Minute value property. (0 to 59)
        minute: { type:Number, default:10},

        // $ver: v0.1.0
        // 비활성화 상태로 전환합니다.
        // #Switch to inactive state.
        // $default: false
        disabled: {type:Boolean, default: false},

        // $ver: v0.1.0
        // 오전/오후 속성 입니다. 'AM', 'PM' 중 한 가지 속성 값을 가집니다.
        // #AM / PM property. It has one attribute value: "AM" or "PM".
        meridiem: {type: String, default: 'AM'},

    },
    data() { return {
        time_hour : this.hour,
        time_minute: this.minute,
        mrdm : this.meridiem,
        value: '',
    };},
    mounted(){
        this.value = this.getValue;
    },
    computed:{
        minHour() {
            return this.mrdm==='AM'? 1 : 0;
        },
        maxHour() {
            return this.mrdm==='AM'? 13 : 12;
        },
        getValue(){
            this.value = this.time_hour + ":" + this.time_minute + ":00 "+ this.mrdm;
            return this.time_hour + ":" + this.time_minute + ":00 "+ this.mrdm;
        },
        isAM(){
            return (this.mrdm==='AM');
        }
    },
    watch:{
        value (){
            // $ver: v0.1.0
            // $arg: selected item(s))
            // 시간 값이 바뀔 때, 현재 시간 값을 (HH:MM AM) 형태의 파라미터로 이벤트를 발생시킵니다.
            // #When the time value is changed, an event is generated with the current time value as a parameter of the form (HH: MM AM).
            this.$emit('input', this.value);
        },
        time_hour: function (val){
            if(this.mrdm==='AM' && val === 13){
                this.time_hour = 1;
                this.mrdm = 'PM';
            } else if(!(this.mrdm==='AM') && val === 0){
                this.time_hour = 12;
                this.mrdm = 'AM';
            }
        },
    },
    method:{

    }
}
</script>
