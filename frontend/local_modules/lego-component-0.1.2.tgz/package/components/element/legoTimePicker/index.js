import legoTimePicker from "./legoTimePicker.vue";
export default {
    install(Vue){
        Vue.component(legoTimePicker.name, legoTimePicker);

    }
};