import legoActionBar from "./legoActionBar.vue";
export default {
    install(Vue){
        Vue.component(legoActionBar.name, legoActionBar);
    }
};