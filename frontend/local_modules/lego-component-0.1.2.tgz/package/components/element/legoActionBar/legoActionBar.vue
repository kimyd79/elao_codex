<template>
    <div class="lego-action-bar lego-action-bar__default-zone">
        <slot/>
        <div class="lego-action-bar__alternative-zone">
            <slot name="left"/>
        </div>
    </div>
</template>

<script>
export default {
    name:"legoActionBar"
}

</script>