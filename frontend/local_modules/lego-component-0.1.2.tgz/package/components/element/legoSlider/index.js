import legoSlider from "./legoSlider.vue";
export default {
    install(Vue){
        Vue.component(legoSlider.name, legoSlider);
    }
};