<template>
    <div class="lego-slider" :class="sliderClass" :style="sliderStyle">
        <div class="lego-slider__track">
            <div class="lego-slider__progress" :style="progressStyle"></div>
            <div v-if="isTickMarkShow" class="lego-slider__tick-mark-wrapper">
                <div v-for="(pos,idx) in tickMarkPosition"
                     :class="tickClass(pos)"
                     :key="idx"
                     :style="{left:num2px(pos)}">
                </div>
            </div>
            <button v-if="isLeftShow"
                    class="lego-slider__handle lego-slider__handle--left"
                    :style="leftHandleStyle"
                    @mousedown="e=>onMousedown(e,0)">
                <div class="lego-slider__handle__tooltip" :value="rangeValue[0]+unit" />
            </button>
            <button v-if="isRightShow"
                    class="lego-slider__handle lego-slider__handle--right"
                    :style="rightHandleStyle"
                    @mousedown="e=>onMousedown(e,1)">
                <div class="lego-slider__handle__tooltip" :value="rangeValue[1]+unit" />
            </button>
        </div>
        <div v-if="isTickLabelShow" class="lego-slider__tick-label-wrapper">
            <div v-for="(pos,idx) in tickLabelPosition"
                 class="lego-slider__tick-label"
                 :key="idx"
                 :style="{left:num2px(pos)}"
            >{{tickLabelValue[idx]+unit}}</div>
        </div>
    </div>
</template>

<script>
export default {
    name: 'lego-slider',
    props: {
        // $ver: v0.1.0
        // Single 유형 슬라이더(기본값) 사용 시, 값의 증가 방향을 지정합니다. 'right','left' 속성을 가질 수 있습니다.
        // #When using the Single type slider (default), specify the direction of increase in the value. It can have 'right' and 'left' properties.
        single: {type: String, default: 'right'},

        // $ver: v0.1.0
        // Range 유형 슬라이더 사용 시 지정하는 속성입니다.
        // #This property is specified when using the Range type slider.
        // $default: false
        range: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 슬라이더에 Tick(구분자)를 표시하고자 할 때 사용하는 속성입니다.
        // #This property is used to display a tick on the slider.
        // $default: false
        tick: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Tick(구분자)의 유형을 지정하는 속성입니다. 'bar', 'dot' 두 가지 속성을 가질 수 있습니다.
        // #This property specifies the type of Tick. It can have two properties: 'bar' and 'dot'.
        tickMarkStyle: {type: String, default: 'bar',
            validator: (value) => {return ['bar','dot'].indexOf(value) !== -1;}
        },

        // $ver: v0.1.0
        // Tick(구분자)가 표시되는 단위를 설정합니다.
        // #Sets the unit in which the Tick is displayed.
        tickMark: {type: Number, default: 10},

        // $ver: v0.1.0
        // Tick(구분자)의 라벨이 표시되는 단위를 설정합니다.
        // #Sets the unit in which the label of the tick is displayed.
        tickLabel: {type: Number, default: 5},
        
        // $ver: v0.1.0
        // $v-model
        // v-model로 바인딩되는 값으로, 슬라이더의 값과 연결됩니다. Single 형인 경우 숫자로, Range 형인 경우 시작/끝 값 순서의 배열 형태로 바인딩 됩니다.
        // #The value bound to the v-model, which is associated with the value of the slider. 
        // #If it is a Single type, it is a number; if it is a Range type, it is bound as an array of start / end value sequences.
        value: [Number, Array],

        // $ver: v0.1.0
        // 값이 움직이는 단위를 설정합니다. TickMark 단위와 맞추면 Tick 표시 단위로만 움직이는 슬라이더를 구현할 수 있습니다.
        // #Sets the unit in which the value moves. Align with TickMark units to implement a slider that moves only in Tick mark units.
        valueInterval: {type: Number, default: 1},

        // $ver: v0.1.0
        // 슬라이더에 표현되는 최소값, 최대값을 설정합니다. 최소/최대 순서의 배열로 입력됩니다.
        // #Set the minimum and maximum values ​​displayed on the slider. It is entered in an array of min / max order.
        domain: {type: Array, default: ()=>[0,100]},

        // $ver: v0.1.0
        // 값이 가질 수 있는 최소값, 최대값을 설정합니다. 최소/최대 순서의 배열로 입력됩니다.
        // #Set the minimum and maximum values ​​that a value can have. It is entered in an array of min / max order.
        limit: {type: Array, default: undefined},
        
        // $ver: v0.1.0
        // 슬라이더의 너비를 지정합니다. 단위는 px 입니다.
        // #Specify the width of the slider. The unit is px.
        width: {type: [Number, String], default: 300},

        // $ver: v0.1.0
        // Tick(구분자)의 라벨 뒤에 붙일 단위 문자열을 지정합니다. 주로 퍼센트(%) 표시할 때 사용됩니다.
        // #Specifies the unit string to append to the label of the Tick. Mainly used to display percentages.
        unit: {type: String, default: ''},

        // $ver: v0.1.0
        // 비활성화 상태로 전환합니다.
        // #Switch to inactive state.
        // $default: false
        disabled: {type: Boolean, default: false},

    },
    computed: {
        sliderClass() {return {'lego-slider--disabled':this.disabled}},
        sliderStyle() {return {width: this.num2px(this.width)}},
        isLeftShow() { return this.range || this.single==='left';},
        isRightShow() { return this.range || this.single==='right';},
        isTickMarkShow() { return this.tick && this.tickMark > 0;},
        isTickLabelShow() { return this.tick && this.tickLabel > 0;},
        domainSize() {return this.domain[1] - this.domain[0];},
        widthSize() {return this.px2num(this.width);},
        limitValue() {
            if(!this.limit) {return this.domain;}
            return [Math.max(this.domain[0],this.limit[0]), Math.min(this.domain[1],this.limit[1])];
        },
        rangeValue() {
            let left = this.range ? this.value[0]
                    : this.single==='left' ? this.value
                    : this.domain[0];
            let right = this.range ? this.value[1]
                    : this.single==='right' ? this.value
                    : this.domain[1];
            return [left, right];
        },
        rangePosition() {
            let left = (this.rangeValue[0] - this.domain[0]) / this.domainSize * this.widthSize;
            let right = (this.domain[1] - this.rangeValue[1]) / this.domainSize * this.widthSize;
            return [left, right];
        },
        progressStyle() {
            return {
                left: this.num2px(this.rangePosition[0]),
                right: this.num2px(this.rangePosition[1])
            }
        },
        leftHandleStyle() {return {left: this.num2px(this.rangePosition[0])}},
        rightHandleStyle() {return {right: this.num2px(this.rangePosition[1])}},
        tickMarkValue() {
            if(this.tickMark <= 0) {return [];}
            let rtn = [this.domain[0]];
            for(let i = 1; i < this.tickMark ; i++) {
                rtn.push(this.domain[0] + this.domainSize * (i/this.tickMark));
            }
            rtn.push(this.domain[1]);
            return rtn;
        },
        tickMarkPosition() {
            return this.tickMarkValue.map(v => (v - this.domain[0]) / this.domainSize * this.widthSize);
        },
        tickLabelValue() {
            if(this.tickLabel <= 0) {return [];}
            let rtn = [this.domain[0]];
            for(let i = 1; i < this.tickLabel ; i++) {
                rtn.push(this.domain[0] + this.domainSize * (i/this.tickLabel));
            }
            rtn.push(this.domain[1]);
            rtn = rtn.map(v => Math.round(v / this.valueInterval) * this.valueInterval);
            return rtn;
        },
        tickLabelPosition() {
            return this.tickLabelValue.map(v => (v - this.domain[0]) / this.domainSize * this.widthSize);
        }
    },
    methods: {
        tickClass(pos) {
            return [
                'lego-slider__tick-mark',
                'lego-slider__tick-mark--'+this.tickMarkStyle,
                this.rangePosition[0] <= pos && pos <= this.widthSize - this.rangePosition[1]? 'lego-slider__tick-mark--active':''
            ]
        },
        num2px(v) {
            if(typeof v === 'number') { return Math.round(v) + 'px';}
            return v;
        },
        px2num(v) {
            if(typeof v === 'string') { return parseInt(/[0-9.]*/.exec(v)[0]);}
            return v;
        },
        onMousedown(e, lr) {
            let oldX = e.clientX;
            let oldV = this.value;
            let me = this;
            let mMoveBuilder = () => {return (ev) => {
                let newX = ev.clientX;
                //console.log('from '+oldX + ' to '+newX);
                let diffV = (newX - oldX);
                diffV = diffV / me.widthSize * me.domainSize;
                diffV = Math.round(diffV / me.valueInterval) * me.valueInterval;
                if(me.range) {
                    let newV = oldV[lr] + diffV;
                    if(newV < me.limitValue[0]) {newV = me.limitValue[0];}
                    if(newV > me.limitValue[1]) {newV = me.limitValue[1];}
                    let rtn = _.clone(me.value);
                    rtn[lr] = newV;
                    if(rtn[0] > rtn[1]) {rtn[(lr+1)%2] = rtn[lr];}
                    
                    // $ver: v0.1.0
                    // $arg: updated value
                    // 슬라이더의 값이 바뀔 경우, 변경된 값을 파라미터로 이벤트를 발생 시킵니다.
                    // #When the slider's value changes, an event is raised with the changed value as a parameter.
                    me.$emit('input', rtn);
                } else {
                    let newV = oldV + diffV;
                    if(newV < me.limitValue[0]) {newV = me.limitValue[0];}
                    if(newV > me.limitValue[1]) {newV = me.limitValue[1];}

                    me.$emit('input', newV);
                }
            }};
            let mMove = mMoveBuilder();
            let mUp = (ev) => {
                document.removeEventListener('mousemove', mMove);
                document.removeEventListener('mouseup', mUp);
            };
            document.addEventListener('mousemove',mMove);
            document.addEventListener('mouseup',mUp);
        }
    }
}
</script>