<template>
    <div :class="containerClass" ref="container" v-click-outside="clickOutside">
        <div :class="anchorClass" :style="computedAnchorStyle">
            <div ref="tooltip" class="lego-tooltip-wrapper" :style="computedTooltipStyle">
                <div v-if="!$scopedSlots.tooltip" :class="tooltipClass"><!--
                    $ver: v0.1.0
                    툴팁내 위치할 컨텐츠 영역입니다. 일반적으로 문자열이 위치합니다.
                    #The content area to place in the tooltip. Typically the string is located.
                 --><slot/>
                    <lego-icon v-show="closeIconShow" class="lego-tooltip__close" size="16px" @click="close">close</lego-icon>
                </div>
                <!--
                    $ver: v0.1.0
                    툴팁내 위치할 컨텐츠 영역입니다. tooltip으로 슬롯을 지정하여 사용할 수 있습니다. 일반적으로 문자열이 위치합니다.
                    #The content area to place in the tooltip. You can use the tooltip by specifying the slot. Typically the string is located.
                 -->
                <slot name="tooltip"/>
            </div>
        </div>
    </div>
</template>

<script>
import legoEventBus from '../../../utils/eventBus/LegoEventBus'
let idx = 0;
export default {
    name: 'lego-tooltip',
    props: {
        // $ver: v0.1.0
        // 툴팁이 적용될 객체의 id를 지정합니다.
        // 아무것도 지정하지 않으면 previousElementSibling을 선택합니다.
        // #Specifies the id of the object to which the tooltip is applied.
        // #If nothing is specified, select previousElementSibling.
        targetId: {type: String},

        // $ver: v0.1.0
        // 툴팁을 닫을 때 닫기버튼을 클릭하여 닫히도록 합니다.
        // #When closing the tooltip, click the Close button to close it.
        // $default: false
        manualClose: {type:Boolean, default: false},

        // $ver: v0.1.0
        // 왼쪽에 툴팁을 표현합니다.
        // #Show tooltips on the left.
        // $default: false
        left: {type:Boolean, default: false},

        // $ver: v0.1.0
        // 오른쪽에 툴팁을 표현합니다.
        // #Show tooltips on the right.
        // $default: false
        right: {type:Boolean, default: false},

        // $ver: v0.1.0
        // 위쪽에 툴팁을 표현합니다.
        // #Show tooltips at the top.
        // $default: false
        top: {type:Boolean, default: false},

        // $ver: v0.1.0
        // 아래쪽에 툴팁을 표현합니다.
        // #Show tooltips at the bottom.
        // $default: false
        bottom: {type:Boolean, default: false},

        // $ver: v0.1.0
        // 마우스 오버 시 툴팁을 표현합니다.
        // #Show tooltip on mouseover.
        // $default: false
        mouseOver: {type:Boolean, default: false},

        // $ver: v0.1.0
        // mouseOver 속성의 약어입니다.
        // $abbr: mouseOver
        mover: {type:Boolean, default: false}, // alias of mouseOver

        // $ver: v0.1.0
        // mouseOver 속성의 약어입니다.
        // $abbr: mouseOver
        hover: {type:Boolean, default: false}, // alias of mouseOver

        // $ver: v0.1.2
        // scroll (overflow) 설정이 되어있는 컨테이너를 지정합니다. querySelector 방식이며 기본값은 .lego-scroll입니다.
        // #Specifies the container that has scroll (overflow) set on it. The querySelector method, which defaults to .lego-scroll.
        scrollContainer: {
            type: String,
            default: '.lego-scroll'
        },

        // $ver: v0.1.2
        // scroll이 발생 했을 때 target element와 함께 움직이는 컨텐츠 영역입니다.
        // #The content area that moves with the target element when scrolling occurs.
        contentContainer: {
            type: String,
            default: '.lego-scroll__content'
        }
    },
    data() {return {
        targetEl: {},
        showToggle: false,
        location: '',
        multiline: false,
        computedAnchorStyle: {},
        computedTooltipStyle: {},
    }},
    computed: {
        closeIconShow() {return (this.manualClose || this.multiline) && !this.$_hover},
        $_hover() {
            return this.mouseOver || this.hover || this.mover;
        },
        containerClass() {
            return [
                'lego-tooltip-invisible-container',
                this.showToggle?'lego-tooltip-invisible-container--show':''
            ]
        },
        anchorClass() {
            return [
                'lego-tooltip-anchor',
                this.$scopedSlots.tooltip?'':'lego-tooltip-anchor__arrow--'+this.location
            ]
        },
        tooltipClass() {
            return [
                'lego-tooltip',
                this.manualClose||this.multiline?'lego-tooltip--with-close':'',
                this.multiline?'lego-tooltip--multiline':'',
            ]
        }
    },
    mounted() {
        // 1. find target element
        if(typeof this.targetId ==='string' && this.targetId[0] === '#') {
            this.targetEl= document.getElementById(this.targetId.slice(1));
        } else if(this.targetId) {
            this.targetEl = document.getElementById(this.targetId);
        } else {
            this.targetEl = this.$el.previousElementSibling
        }
        // 2. regist event
        if(this.$_hover) {
            // case.1 mouse-over 모드
            const elTagName = this.targetEl.tagName;
            this.targetEl.addEventListener('mouseenter',(e)=>{
                if(e.target.tagName !== elTagName) return;
                this.clickTrigger(e);
            },true); /* not MOUSE-OVER */
            this.targetEl.addEventListener('mouseleave',(e)=>{
                if(e.target.tagName !== elTagName) return;
                this.close(e);
            },true); /* not MOUSE-OUT */
            // 고민중 : 마우스를 올리면 켜지는데, 그상태에서 클릭하면 꺼짐. 
            //          클릭으로 켜지진 않는데 꺼짐 기능을 구지 없앨 이유가 있을까?
        } else {
            // case.2 Click 모드
            this.targetEl.addEventListener('click',this.clickTrigger);
            let me = this;
            legoEventBus.$on("close_tooltips", function(){
                me.clickOutside();
            });
        }
        if(this.$refs.tooltip.getBoundingClientRect().height> 32) {
            this.multiline = true;
        }
    },
    methods: {
        clickTrigger(e) {
            e.stopPropagation();
            if(this.showToggle===true) {
                this.clickOutside();
                return;
            }
            let contentContainer = this.targetEl.parentElement;
            let matchFuncName = contentContainer['matches']?'matches':'msMatchesSelector';
            if(!this.$el.parentElement[matchFuncName]('.lego-tooltip-outer-invisible-container')) {
                while(contentContainer && !(contentContainer[matchFuncName](this.contentContainer) || contentContainer.classList.contains('lego-screen'))) {
                    contentContainer = contentContainer.parentElement||undefined;
                }
                if (!contentContainer) {contentContainer = document.body;}
                let childNodes = contentContainer.children;
                let outerContainer;
                for(let node of childNodes) {
                    if(node.classList.contains('lego-tooltip-outer-invisible-container')) {
                        outerContainer = node;
                        break;
                    }
                }
                if(!outerContainer) {
                    outerContainer = document.createElement('div');
                    outerContainer.className ='lego-tooltip-outer-invisible-container';
                    contentContainer.prepend(outerContainer);
                    outerContainer.appendChild(this.$el);
                } else {
                    outerContainer.appendChild(this.$el);
                }
            } else {
                contentContainer = this.$el.parentElement.parentElement;
            }
            let scrollContainer = contentContainer;
            while(scrollContainer && !(scrollContainer[matchFuncName](this.scrollContainer) || scrollContainer.classList.contains('lego-system'))) {
                scrollContainer = scrollContainer.parentElement || undefined;
            }
            if(!scrollContainer) {scrollContainer = document.body;}


            let positionLimit = scrollContainer.getBoundingClientRect();
            let target = this.targetEl.getBoundingClientRect();
            let container = this.$el.getBoundingClientRect();
            let tooltip = this.$refs.tooltip.getBoundingClientRect();
            let arrowWidth = !this.$scopedSlots.tooltip? 12:0;

            this.computedAnchorStyle = this.getAnchorStyle(positionLimit, target, container, tooltip,arrowWidth);
            this.computedTooltipStyle= this.getToolTipStyle(positionLimit, target, tooltip,arrowWidth);
            this.open();
        },
        getAnchorStyle(parent, target, container, tooltip,arrowWidth){
            let anchorStyle = {};
            if(this.left) {
                this.location = 'left';
                anchorStyle.left = ((target.left - 4) - container.left) + 'px';
                anchorStyle.top = ((target.top + target.bottom) / 2 - container.top) + 'px';
            } else if(this.right) {
                this.location = 'right';
                anchorStyle.left = ((target.right + 4) - container.left) + 'px';
                anchorStyle.top = ((target.top + target.bottom) / 2 - container.top) + 'px';
            } else if(this.top) {
                this.location = 'top';
                anchorStyle.top = ((target.top - 4) - container.top) + 'px';
                anchorStyle.left = ((target.left + target.right) / 2 - container.left) + 'px';
            } else if(this.bottom) {
                this.location = 'bottom';
                anchorStyle.top = ((target.bottom + 4) - container.top) + 'px';
                anchorStyle.left = ((target.left + target.right) / 2 - container.left) + 'px';
            } else {
                if(target.right + 4 + arrowWidth + tooltip.width > parent.right){
                    if(target.bottom + 4 + arrowWidth + tooltip.height > parent.bottom) {
                        this.location='top';
                        anchorStyle.top = ((target.top - 4) - container.top) + 'px';
                        anchorStyle.left = ((target.left + target.right) / 2 - container.left) + 'px';
                    } else {
                        this.location = 'bottom';
                        anchorStyle.top = ((target.bottom + 4) - container.top) + 'px';
                        anchorStyle.left = ((target.left + target.right) / 2 - container.left) + 'px';
                    }
                } else {
                    this.location = 'right';
                    anchorStyle.left = ((target.right + 4) - container.left) + 'px';
                    anchorStyle.top = ((target.top + target.bottom) / 2 - container.top) + 'px';
                }
            }
            return anchorStyle;
        },
        getToolTipStyle(parent, target, tooltip,arrowWidth){
            let tooltipStyle = {};
            if(this.location === 'left') {
                tooltipStyle.right = (arrowWidth) + 'px';
                if((target.top + target.bottom) / 2 + tooltip.height - 16 > parent.bottom) {
                    tooltipStyle.bottom = ((target.top + target.bottom) / 2 - parent.bottom) +'px';
                }else {
                    tooltipStyle.top = '-16px';
                }
            } else if(this.location === 'right') {
                tooltipStyle.left = (arrowWidth) + 'px';
                if((target.top + target.bottom) / 2 + tooltip.height - 16 > parent.bottom) {
                    tooltipStyle.bottom = ((target.top + target.bottom) / 2 - parent.bottom) +'px';
                }else {
                    tooltipStyle.top = '-16px';
                }
            } else if(this.location === 'top') {
                tooltipStyle.bottom = (arrowWidth) + 'px';
                if((target.left + target.right) / 2 - tooltip.width / 2  < parent.left) {
                    tooltipStyle.left = (parent.left - (target.left + target.right) / 2) +'px';
                } else if((target.left + target.right) / 2 + tooltip.width / 2  > parent.right){
                    tooltipStyle.right = ((target.left + target.right) / 2 - parent.right) +'px';
                }else {
                    tooltipStyle.left = (-tooltip.width/2)+'px';
                }
            } else {
                tooltipStyle.top = (arrowWidth) + 'px';
                if((target.left + target.right) / 2 - tooltip.width / 2  < parent.left) {
                    tooltipStyle.left = (parent.left - (target.left + target.right) / 2) +'px';
                } else if((target.left + target.right) / 2 + tooltip.width / 2  > parent.right){
                    tooltipStyle.right = ((target.left + target.right) / 2 - parent.right) +'px';
                }else {
                    tooltipStyle.left = (-tooltip.width/2)+'px';
                }
            }
            return tooltipStyle;
        },
        clickOutside() {
            if(!this.manualClose) {
                this.close();
            }
        },
        open(){
            // $ver: v0.1.0
            // $arg: N/A
            // 툴팁이 펼쳐질 때, 다른 툴팁들을 닫는 이벤트를 발생시킵니다.
            // #When a tooltip is expanded, it raises an event that closes other tooltips.
            legoEventBus.$emit("close_tooltips");
            this.showToggle = true;
        },
        close(e) {
            this.showToggle = false;
        }
    },
    beforeDestroy() {
        if(this.targetEl) {
            this.targetEl.removeEventListener('mouseenter',this.clickTrigger);
            this.targetEl.removeEventListener('mouseout'  ,this.close);
        }
        this.$el.parentElement.removeChild(this.$el);
    }
}
</script>