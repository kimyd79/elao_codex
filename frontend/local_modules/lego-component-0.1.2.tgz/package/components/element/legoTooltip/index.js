import legoTooltip from "./legoTooltip.vue";
export default {
    install(Vue){
        Vue.component(legoTooltip.name, legoTooltip);
    }
};