import legoMultiSelectDropdown from "./legoMultiSelectDropdown.vue";
export default {
    install(Vue){
        Vue.component(legoMultiSelectDropdown.name, legoMultiSelectDropdown);
    }
};