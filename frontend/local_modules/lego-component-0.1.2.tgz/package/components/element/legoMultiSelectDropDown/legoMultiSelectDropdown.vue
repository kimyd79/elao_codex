<template>
    <div class="lego-dropdown lego-input" :class="dropdownClass" :style="[dropdownWidth, dropdownHeight]" v-click-outside="toggleItemOuter">
        <div class="lego-dropdown__title"  @click="toggleItem">
            <div class="lego-dropdown__selected" :style="dropdownTitleStyle" :title="getSelectedItemText">{{getSelectedItemText}}</div>
            <lego-icon-wrapper style="width:16px;margin-left:12px;">
                <lego-icon class="lego-dropdown__icon" icon="expand_menu" size="10px" :style="caretStyle"/>
            </lego-icon-wrapper>
        </div>
        <div class="lego-dropdown__downwrap" v-show="isItemShowing">
            <div class="lego-dropdown__item lego-dropdown__selectall" v-show="selectall" :style="[dropdownWidth]" >
                <lego-checkbox   :checked="selectAllChecked" :checked-icon="selectAllCheckedIcon" @click="clickSelectAll" >Select All</lego-checkbox>
            </div>
            <div class="lego-dropdown__items"  :style="[dropdownWidth]">
                <div class="lego-dropdown__item" v-for="(item, idx) in items" :key="idx">
                    <div class="lego-dropdown__label" @click="returnSelectedItem" >
                        <lego-checkbox :value="item.value" v-model="checkedArr" @click="returnSelectedItem" >{{getText(item)}}</lego-checkbox>
                    </div>
                </div>
            </div>
            <div class="lego-dropdown__apply lego-dropdown__apply_pos" v-show="applybtn" :style="[dropdownWidth]" >
                <lego-button @click="onApplyClick">Apply</lego-button>
            </div>
        </div>
    </div>
</template>

<script>
const UNSELECT_DROPDOWN_TITLE = "Select";
const DEFAULT_PLACEHOLDER = "Input value";
const DEFAULT_ITEM_TEXT  = "text";
const DEFAULT_ITEM_VALUE = "value";

import legoDropdown from '../legoDropdown/legoDropdown';
// lego-multi-dropdown은 lego-dropdown을 상속받은 컴포넌트 입니다. lego-dropdown의 모든 속성을 그대로 사용합니다.
// #lego-multi-dropdown is a component that inherits lego-dropdown. Accept all the properties of lego-dropdown.
export default {
    name :"lego-multi-dropdown",
    extends: legoDropdown,
    props: {
        // $ver: v0.1.2
        // $v-model
        // 드랍다운 리스트의 선택된 값 입니다.
        // #The selected value in the drop-down list.
        value: {
            type:[String,Array]
        },
        // $ver: v0.1.2
        // Apply 버튼을 표시합니다.
        // #Display the Apply button.
        // $default: false
        applybtn  : {type: Boolean, default: false},

        // $ver: v0.1.2
        // Select All 기능을 표시합니다.
        // #Displays the Select All function.
        // $default: false
        selectall  : {type: Boolean, default: false},
    },
    data(){return {
        checkedArr : [],
        prevCheckedArr : [],
        checkedSelectAll: false,
    }},
    mounted(){
        this.setCheckedArr();
        this.returnSelectedItem();
    },
    computed: {
        itemsMap() {
            let map = new Map(), me = this;
            buildMap(this.items);
            return map;
            function buildMap(arr) {
                arr.forEach(item => {
                    map.set(me.getValue(item),item);
                });
            }
        },
        getSelectedItemText(){
            return (this.checkedArr.length === 0)? UNSELECT_DROPDOWN_TITLE : this.checkedArr.join(", ");
        },
        selectAllChecked() {
            return (this.checkedArr.length > 0);
        },
        selectAllCheckedIcon() {
            if(this.checkedArr.length === 0) {return null;}
            return (this.checkedArr.length === this.items.length) ? 'checked' : 'indeterminate';
        },
    },

    methods: {
        setCheckedArr() {
            var me = this;
            me.items.forEach(item =>{
                if(!item.checked) return;
                me.checkedArr.push(item.value);
                if(me.applybtn && item.checked){
                    me.prevCheckedArr.push(item.value);
                }
            })
        },
        getValuesFromCheckedArr(){
            let selectedAllValues = [];
            buildSelectedAllArr(this.items);
            return selectedAllValues;
            function buildSelectedAllArr(arr) {
                arr.forEach(item => {
                    selectedAllValues.push(item.value);
                });
            }
        },
        getSelectedItem(){
            let selectedItemArr = [], me = this;
            buildArr(this.checkedArr);
            return selectedItemArr;
            function buildArr(arr) {
                arr.forEach(item => {
                    selectedItemArr.push(me.itemsMap.get(item));
                });
            }
        },
        returnSelectedItem(e){
            //case: applybtn && click item
            if(e !== undefined && this.applybtn){
                if(e.target.nodeName !== "BUTTON" ){
                    return;
                }
            }
            // $ver: v0.1.2
            // $arg: updated v-model value
            // v-model에 설정된값(value)을 업데이트합니다.
            // item-value props의 설정값에 따라 선택된 항목의 item-value key값 목록 또는 문자열을 가져옵니다.
            // # update v-model value(checked props).
            this.$emit('input', this.getSelectedItem());
            this.updatePrevCheckedItems();
        },
        updatePrevCheckedItems(){
            this.prevCheckedArr = this.checkedArr.slice(0);
        },
        restoreItems(){
            this.checkedArr = this.prevCheckedArr.slice(0);
        },
        toggleItem (event) {
            let flag = !this.isItemShowing;
            this.$root.$el.click();
            this.isItemShowing = flag;
        },
        toggleItemOuter (e) {
            if(this.applybtn && !this.selectall) {
                this.restoreItems();
            }
            this.isItemShowing = false;
        },
        onApplyClick(e){
            this.returnSelectedItem(e);
            this.isItemShowing = false;
        },
        clickSelectAll(event) {
            if (this.checkedArr.length === this.items.length) {
                this.checkedArr = [];
            } else {
                this.checkedArr = this.getValuesFromCheckedArr().slice(0);
            }
            this.returnSelectedItem();
        },
    },
}

</script>