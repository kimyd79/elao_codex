import legoProgress from "./legoProgress.vue";
import legoProgressMask from "./legoProgressMask";
export default {
    install(Vue){
        Vue.component(legoProgress.name, legoProgress);
        Vue.component(legoProgressMask.name, legoProgressMask);
    }
};