<template>
        <div class="lego-progress__wrapper" :class="wrapperClass">
            <!-- [TYPE] Circle -->
            <svg v-if="isCircle" class="lego-progress__circle" :class="circleClass" :style="circleStyle" viewBox="0 0 480 480" >
                <circle cx="240" cy="240" r="216" fill="none"
                        :class="circleBackgroundClass" stroke-width="48"/>
                <circle cx="240" cy="240" r="216" fill="none"
                        :class="circleProgressClass" stroke-width="48"
                        :stroke-dasharray="strokeCircle" :stroke-dashoffset="strokeCircleOffset"/>
            </svg>
            <!-- [TYPE] Line -->
            <div v-if="isLine" class="lego-progress__line" :class="lineClass" :style="lineStyle">
                <div class="lego-progress__line-progress" 
                     :class="lineProgressClass"
                     :style="lineProgressStyle"/>
            </div>
            <!-- [TYPE] none -->
            <div v-if="messageDirection !== 'none'" :class="textClass" >{{message}}</div>
        </div>
</template>

<script>
import numUtil from "../../../utils/static/numberUtil";
const WIDTH = 216;
export default {
    name :"legoProgress",
    props: {

        // $ver: v0.1.0
        // 컴포넌트의 크기를 지정하는 속성입니다. 'small', 'medium', 'large' 세 가지 속성을 지정할 수 있습니다.
        // #This property specifies the size of the component. You can specify three properties: "small", "medium", and "large".
        size: { /* small, medium, large */
            type: String,
            default: '',
            validator: function (val) {
                val = val || 'small';
                return ['small', 'medium', 'large'].indexOf(val.toLowerCase()) !== -1;
            }
        },

        // $ver: v0.1.0
        // 유형입니다. 원형으로 표현되는 'circle'과 막대 형태로 표시되는 'line' 속성을 지정할 수 있습니다.
        // #Type. You can specify 'circle' as a circle and 'line' as a bar.
        progressType: { /* circle, line*/
            type: String,
            default: 'circle',
            validator: function (val) {
                return ['circle', 'line'].indexOf(val) !== -1;
            }
        },

        // $ver: v0.1.0
        // 배경화면 반전 시 시인성을 높이기 위해 컴포넌트 색상을 지정하기 위한 속성입니다. 'normal','light' 두 가지 속성을 지정할 수 있습니다.
        // #This property is used to specify the component color for better visibility when the background is reversed. Two properties can be specified: 'normal', 'light'.
        colorType : { /* normal, light */
            type: String,
            default: 'normal',
            validator: function (val) {
                return ['normal', 'light'].indexOf(val) !== -1;
            }
        },

        // $ver: v0.1.0
        // 추가 텍스트가 표시될 위치를 지정하는 속성입니다. 'none' 지정 시 텍스트가 표시되지 않으며, 'right','bottom' 속성을 지정할 수 있습니다.
        // #This property specifies where additional text is displayed. If you specify 'none', no text is displayed. You can specify the 'right' and 'bottom' properties.
        messageDirection:{ /* none, right, bottom */
            type: String,
            default: 'none',
            validator: function (val) {
                return ['none', 'right', 'bottom'].indexOf(val) !== -1;
            }
        },

        // $ver: v0.1.0
        // 퍼센트 값으로 표현될 진행비율 값 입니다. 0 ~ 100 사이 숫자 값 지정이 가능합니다.
        // #Progress rate value to be expressed as a percentage value. You can specify a numeric value between 0 and 100.
        value: { /* 0 ~ 100 % */
            type: Number,
            validator: function (val) {
                return val >= 0 && val <= 100;
            }
        },

        // $ver: v0.1.0
        // 진행비율 값 지정 시 반영되는 속도입니다.
        // #The speed that is reflected when specifying the progress rate value.
        speed  : {type: Number , default: 0.9},

        // $ver: v0.1.0
        // 우측 또는 하단에 위치할 추가 텍스트 입니다.
        // #Additional text to be placed on the right or bottom.
        message: {type: String , default: ''},

        // $ver: v0.1.0
        // 현재 사용되지 않는 속성입니다.
        // #This property is not currently used.
        // $deprecated
        // $default: false
        masked : {type: Boolean, default: false,},

        // $ver: v0.1.0
        // 진행 중 오류 발생 시 색상전환을 위한 속성입니다. true로 지정하면 오류발생 색상으로 바뀝니다.
        // #This attribute is for color conversion when an error occurs in progress. If set to true, the color of error will be changed.
        // $default: false
        error  : {type: Boolean, default: false},

        // $ver: v0.1.0
        // 막대형 프로그래스인 경우 컴포넌트의 너비값 입니다. 단위는 px 입니다.
        // #For bar progress, this is the width of the component. The unit is px.
        width  : {type: [Number,String], default :216},

        // $ver: v0.1.0
        // 지정된 퍼센트 값(value 속성 활용)으로 진행상황을 제어하기 위한 속성입니다. false인 경우 계속 진행되는 형태로 표현됩니다.
        // #This property is used to control the progress by the specified percentage value (using the value attribute). If it is false, it will be displayed as a continuous form.
        // $default: false
        determinate: {type: Boolean, default: false},
    },
    data () {return {
        strokeCircle: 0,
        strokeCircleOffset: 0
    }},
    mounted() {
        if(!this.determinate){
            this.updateValue (75);
        }
    },
    computed: {
        isLine () { return this.progressType === 'line'; },
        isCircle () { return this.progressType === 'circle'; },
        wrapperClass() {
            let clazz = [];
            clazz.push('lego-progress__wrapper-' + this.messageDirection);
            if(this.masked) clazz.push('lego-progress__wrapper-masked'); 
            return clazz;
        },
        circleClass() {
            let clazz = [];
            clazz.push('lego-progress__circle-' + this.size);
            if(!this.determinate) clazz.push('lego-progress__circle-spin');
            return clazz;
        },
        circleBackgroundClass() {
            return ['lego-progress__circle-background-' + this.colorType,];
        },
        circleProgressClass() {
            let clazz = [];
            clazz.push('lego-progress__circle-progress-' + this.colorType);
            if(this.error) clazz.push('lego-progress__circle-progress-error')
            return clazz;
        },
        circleStyle() {
            let arrStyle={};
            if(!this.determinate){
                arrStyle['animation'] = 'lego-progress__spin ' + this.speed + 's linear infinite'
            }
            return arrStyle;
        },
        lineClass() {
            return ['lego-progress__line-background-' + this.colorType];
        },
        lWidthStr() {
            let width = this.width;
            if( numUtil.isNum(width) ) return parseInt(width)+"px";
            return width;
        },
        lineStyle() {
            let style = {};
            style['width'] = this.lWidthStr;
            return style;
        },
        lineProgressClass() {
            let clazz = [];
            clazz.push('lego-progress__line-progress-' + this.colorType);
            if(this.error) clazz.push('lego-progress__line-progress-error');
            return clazz
        },
        lineProgressStyle() {
            let arrStyle={};
            if(this.determinate) {
                arrStyle['width'] = this.value+'%';
            } else {
                arrStyle['width'] = '80px';
                arrStyle['animation'] = 'lego-progress__line-transform ' + this.speed + 's linear infinite'
            }
            return arrStyle;

        },
        //text
        textClass () {
            return [
                'lego-progress__text',
                'lego-progress__text-' + this.messageDirection,
                'lego-progress__text-' + this.colorType,
                this.error && 'lego-progress__text-error',
            ];
        },
    },
    methods: {
        updateValue (val) {
            if (this.isCircle) {
                this.strokeCircle = 2 * Math.PI * 216;
                this.strokeCircleOffset = this.strokeCircle * ((100 - val) / 100);
            }
        },
    },
    watch: {
        value: function (val) {
            this.updateValue(val)
        },
    }
}
</script>