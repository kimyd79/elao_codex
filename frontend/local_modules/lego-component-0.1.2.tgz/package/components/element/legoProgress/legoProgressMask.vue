<template>
    <div ref="mask" class="lego-progress__mask" :style="mask_style" >
        <lego-progress :size="this.size"
                       :line-size="this.lineSize"
                       :line-bg-color="this.lineBgColor"
                       :line-fg-color="this.lineFgColor"
                       :speed="this.speed"
                       :spacing="this.spacing"
                       :message="this.message"
                       :font-size="this.fontSize"
                       masked
                       message-direction="bottom"></lego-progress>
    </div>
</template>

<script>
    let isNumber = function(n) {
        return !isNaN(parseFloat(n)) && isFinite(n)
    };
    export default {
        name :"legoProgressMask",
        props: {
            size: {
                type: String,
                default: '',
                validator: function (val) {
                    if(val == null || val===''){
                        val = 'small';
                    }
                    let lowerVal = val.toLowerCase();
                    return ['small', 'medium', 'large', 'xlarge'].indexOf(lowerVal) !== -1;
                }
            },
            lineSize: {
                type: Number,
                default: 6
            },
            lineBgColor: {
                type: String,
                default: ''
            },
            lineFgColor: {
                type: String,
                default: ''
            },
            speed: {
                type: Number,
                default: 0.8
            },
            spacing: {
                type: Number,
                default: 20
            },
            message: {
                type: String,
                default: ''
            },
            fontSize: {
                type: Number,
                default: 13
            },
            targetObj: {
                type: String,
                default: ''
            }
        },
        computed: {
            mask_style(){
                let targetObj={};
                if(!!this.targetObj){
                    targetObj = document.getElementById(this.targetObj)
                } else {
                    targetObj = this.$parent.$el;
                }
                let top = '0px';
                let left = '0px';
                let width = '100%';
                let height = '100%';

                if(targetObj != null){
                    top = targetObj.getBoundingClientRect().top + 'px';
                    left = targetObj.getBoundingClientRect().left + 'px';
                    width = targetObj.getBoundingClientRect().width + 'px';
                    height = targetObj.getBoundingClientRect().height + 'px';
                }
                return{
                    'top': top,
                    'left': left,
                    'width': width,
                    'height': height,
                }
            },
        },
        mounted() {
            this.$nextTick(function(){
                window.addEventListener("resize", this.mask_resize);
            })
        },
        beforeDestroy() {
            window.removeEventListener("resize", this.mask_resize);
        },
        methods: {
            mask_resize(){
                if(this.$refs.mask) {
                    let targetObj = {}
                    if(!!this.targetObj){
                        targetObj = document.getElementById(this.targetObj)
                    } else {
                        targetObj = this.$parent.$el;
                    }
                    this.$refs.mask.style.width = targetObj.getBoundingClientRect().width + 'px';
                    this.$refs.mask.style.height = targetObj.getBoundingClientRect().height + 'px';
                }
            },
        }
    }
</script>