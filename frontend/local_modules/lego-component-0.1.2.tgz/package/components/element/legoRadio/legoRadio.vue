<template>
    <div class="lego-radio lego-input" :class="radioClass">
        <lego-icon class="lego-radio__icon" @click.stop="onClick" :icon="clicked? checkedIcon : unCheckedIcon"
            :class="{'lego-radio__unchecked' : !clicked,'lego-radio__checked' : clicked}" :iconType="iconType"/>
        <span class="lego-radio__label" @click.stop="onClick" v-if="$slots.default"><!--
            $ver: v0.1.0
            라디오버튼 아이콘 오른쪽으로 위치하는 label 영역입니다. text를 넣어주는 경우가 일반적입니다.
            # default label area on the right side of radio icon.
        --><slot/><!--
    --></span>
    </div>
</template>

<script>
export default {
    name :"lego-radio",
    model: {
        prop: 'checked'
    },
    inject: {
        legoRadioWrapper: {from:'legoRadioWrapper',default:()=>undefined},
        legoInput: {from:'legoInput', default: () => undefined}
    },
    props: {
        // $ver: v0.1.0
        // $v-model
        // v-model로 바인딩되는 값으로, <em>lego-radio-wrapper</em>를 사용할 경우
        // # Binding to v-model. If <em>lego-radio-wrapper</em> component used,
        // lego-radio-wrapper의 v-model값을 우선시하고 lego-radio의 v-model은 무시됩니다.
        // # v-model of this lego-checked box is ignored and v-model of lego-radio-wrapper is used instead.
        checked:{
            type:[Boolean, String], // actual value controlled by v-model (reactive 2-way binding)
        },
        // $ver: v0.1.0
        // 선택되었을 때 v-model의 값으로 설정되는 목표값입니다.
        // # If component is checked, v-model is set as this value.
        // $default: true
        value: {
            type: [Boolean, String],
            default: true
        },
        // $ver: v0.1.0
        // 선택되었을 때 표시될 아이콘입니다. 기본값으로 OPUS icon 중 'radio_select' 아이콘이 설정되어 있습니다.
        // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
        // #The icon to be displayed when selected. By default, the 'radio_select' icon is set among the OPUS icons.
        // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
        checkedIcon: {
            type: String,
            default: 'radio_select'
        },
        // $ver: v0.1.0
        // 미선택되었을 때 표시될 아이콘입니다. 기본값으로 OPUS icon 중 'radio'아이콘이 설정되어있습니다.
        // 아이콘에 대한 설명은 <a href="/#/dev/comp/icon">링크</a>를 참조하십시오.
        // #Icon to be displayed when not selected. By default, the 'radio' icon is set among the OPUS icons.
        // #See the <a href="/#/dev/comp/icon">links</a> for a description of the icons.
        unCheckedIcon: {
            type: String,
            default: 'radio'
        },
        // $ver: v0.1.0
        // 상호작용 불가능한 상태를 만듭니다.
        // #Create a non-interactive state.
        // $default: false
        disabled: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // 기본크기의 라디오버튼을 사용합니다.
        // #Use the default size radio button.
        // $default: false
        medium: {
            type: Boolean,
            default: false
        },
        // $abbr: medium
        md: {type:Boolean},
        // $ver: v0.1.0
        // 기본크기보다 작은 사이즈의 라디오버튼을 사용합니다.
        // #Use radio buttons that are smaller than the default size.
        // $default: false
        small: {
            type: Boolean,
            default: false
        },
        // $abbr: small
        sm: {type:Boolean},
        // $ver: v0.1.0
        // OPUS icon의 타입은 'picto'와 'line' 두가지 타입이 있습니다.
        // 라디오버튼 아이콘에 사용될 기본 아이콘 타입을 설정합니다.
        // #Type of OPUS icon There are two types of 'picto' and 'line'.
        // #Set the default icon type for the radio button icon.
        iconType: {
            type: String,
            default: 'picto'
        },
        // $ver: v0.1.1
        // <em>lego-radio-wrapper</em>와 함께 사용할 때 wrapper 하위에 위치하는 모든 라디오버튼이 아닌
        // 특정 라디오버튼에만 validate를 적용하고 싶을 경우 group이름을 지정하여 분리할 수 있습니다.
        // #When used with <em>lego-radio-wrapper</em>, you can separate it by specifying the group name 
        // #if you want to apply validate only to a specific radio button rather than to all the radio buttons located under the wrapper.
        group: {
            type:String,
            default: 'default'
        }
    },
    data(){
        return {
            default: {size:'medium'},
            strTypeClicked: false
        }
    },

    computed: {
        $_size() {
            if(this.medium || this.md) {return 'medium'}
            if(this.small || this.sm) {return 'small'}
            if(this.legoInput) {return this.legoInput.size}
            return this.default.size;
        },
        actualVModel() {
            if(this.legoRadioWrapper && this.legoRadioWrapper[this.group]) {
                if(this.checked){
                    console.warn('[LEGO-RADIO] if you use lego-radio-wrapper, v-model(=checked props) of lego-radio itself is being ignored.');
                }
                return this.legoRadioWrapper[this.group].checked;
            }
            return this.checked;
        },
        clicked(){
            return (this.actualVModel===this.value);
        },
        radioClass(){
            let clazz = [];
            if (this.disabled || (this.legoRadioWrapper
                                    && this.legoRadioWrapper[this.group]
                                    && this.legoRadioWrapper[this.group].disabled) ) {
                clazz.push('lego-radio--disabled')
            }

            clazz.push('lego-radio--'+this.$_size);
            if(this.legoRadioWrapper
                && this.legoRadioWrapper[this.group]
                && this.legoRadioWrapper[this.group].hasError) {clazz.push('lego-validator--error')}
            return clazz
        }
    },
    methods: {
        onClick(e) {
            // $ver: v0.1.2
            // $arg: click event
            // 컴포넌트 클릭 시 발생하는 이벤트 입니다.
            // # This event is raised when a component is clicked.
            this.$emit('click',e);
            if(this.legoRadioWrapper && this.legoRadioWrapper[this.group]) {
                this.legoRadioWrapper[this.group].click(e);
            }

            let emittedVal = (typeof(this.value) == "boolean")? !this.checked : this.value;
            if(this.legoRadioWrapper && this.legoRadioWrapper[this.group]) {
                this.legoRadioWrapper[this.group].emit(emittedVal);
            } else {
                // $ver: v0.1.0
                // $arg: updated v-model value
                // v-model에 설정된값(checked)을 업데이트합니다.
                // # update v-model value(checked props).
                this.$emit('input',emittedVal);
            }
        }
    }
}

</script>
