import legoRadio from "./legoRadio.vue";
import legoRadioWrapper from "./legoRadioWrapper.vue";
export default {
    install(Vue){
        Vue.component(legoRadio.name, legoRadio);
        Vue.component(legoRadioWrapper.name, legoRadioWrapper);
    }
};