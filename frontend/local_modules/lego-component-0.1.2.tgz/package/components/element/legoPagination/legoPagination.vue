<template>
    <div class="lego-pagination">
        <div class="lego-pagination__navi"
             :class="{'lego-pagination__icon--disable' : isLeftEnd}"
             @click.stop="onClickLeft">
            <lego-icon class="lego-pagination__left-icon">collapse_menu</lego-icon>
        </div>
        <template v-if="!simple">
            <template v-if="isShowFirstZone">
                <div class="lego-pagination__number" :class="{'lego-pagination__selected' : selectedPage(1)}">
                    1
                </div><!-- 
                --><div class="lego-pagination__number-dots">...</div>
            </template>
            <div v-for="(n, idx) in range" :key="idx" @click="clickToMovePage(n)" class="lego-pagination__number lego-pagination__range-area"
                 :class="{'lego-pagination__selected' : selectedPage(n)}">{{ n }}</div>
            <template v-if="isShowLastZone">
                <div class="lego-pagination__number-dots">...</div><!-- 
                --><div class="lego-pagination__number" :class="{'lego-pagination__selected' : selectedPage(pages)}">
                    {{pages}}
                </div>
            </template>
            <div v-if="this.pages === 0" class="lego-pagination__number lego-pagination__icon--disable">1</div>
        </template>
        <template v-else>
            <lego-counter class="lego-pagination__simple-pager"
                          :min="isNoItem?0:1"
                          :max="pages"
                          :value="isNoItem ?0:goToPage"
                          @input="goToInputValidation"
                          @enter="moveToPage"
                          /> / {{pagination.totalPages}}
        </template>
        <div class="lego-pagination__navi"
             :class="{'lego-pagination__icon--disable' : isRightEnd}"
             @click.stop="onClickRight">
            <lego-icon class="lego-pagination__right-icon" >collapse_menu</lego-icon>
        </div>
        <div class="lego-pagination__goto" v-if="!simple && (pages > 11)">
            <lego-counter :value="isNoItem ?0:goToPage"
                          :style="gotoCounterStyle"
                          @input="goToInputValidation"
                          @enter="moveToPage"
                          no-control
                          :min="isNoItem?0:1"
                          :max="pages"
                          :disabled="isNoItem"
                          ></lego-counter>
            <lego-button md @click="moveToPage" :disabled="isNoItem">{{$_moveMessage}}</lego-button>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'lego-pagination',
        props: {
            // $ver: v0.1.0
            // 페이징 처리를 위한 속성 객체입니다. rowsPerPage, currentPage, totalPages, totalItem 속성을 가지고 있습니다.
            // #Property object for paging processing. It has rowsPerPage, currentPage, totalPages and totalItem properties.
            // $default: rowsPerPage - 10, currentPage - 1, totalPages - 0, totalItem - 0
            pagination: {
                type: Object,
                required: true,
                default: () => {
                    return {
                        rowsPerPage: 10,
                        currentPage: 1,
                        totalPages: 0,
                        totalItems: 0
                    };
                }
            },
            // $ver: v0.1.0
            // Simple 유형 여부입니다.
            // #Whether it is a Simple type.
            // $default: false
            simple : {type:Boolean,default:false},

            // $ver: v0.1.2
            // 페이지 입력 및 바로 이동을 위한 버튼 텍스트 입니다.
            // #Button text for page input and direct navigation.
            // $default: 'GO'
            moveMessage: {type:String}
        },
        data() {
            return {
                default: {
                    moveMessage: 'GO'
                },
                page: 1,
                goToInputWidth: 42,
                goToPage: 1
            };
        },
        watch: {
            'pagination.currentPage': {
                immediate: true,
                handler(page) {
                    this.page = page;
                    this.goToPage = page;
                }
            }
        },
        computed: {
            $_moveMessage() {
                return this.moveMessage || this.default.moveMessage;
            },
            isNoItem() {
                return this.pagination.totalItems === 0
            },
            isLeftEnd() {
                return (this.page === 1 || this.pagination.totalItems === 0);
            },
            isRightEnd() {
                return (this.page === this.pages || this.pagination.totalItems === 0);
            },
            isShowFirstZone() {
                // 1. too short to show ellipsis zone
                if(this.pages <= 11) {return false;}
                // 2. too small to show first zone
                if(this.page <= 6 ) {return false;}
                return true;
            },
            isShowLastZone() {
                // 1. too short to show ellipsis zone
                if(this.pages <= 11) {return false;}
                // 2. too large to show last zone
                if(this.pages - 5 <= this.page ) {return false;}
                return true;
            },
            gotoCounterStyle() {
                let digit = Math.floor(Math.log10(this.pages)) + 1;
                return {width:((digit+2)*8 + 2)+"px"}
            },
            pages() {
                if((this.page === this.pagination.totalPages) && (this.pagination.totalItems <= this.pagination.rowsPerPage)){
                    return 1;
                }
                if (this.pagination.rowsPerPage == null || this.pagination.totalItems == null) {
                    return 0;
                } else {
                    return Math.ceil(this.pagination.totalItems / this.pagination.rowsPerPage);
                }
            },
            range() {
                let result = [];
                if (this.pages <= 11) {
                    // 1. total page is too small
                    for (let i = 1; i <= this.pages; i++) {result.push(i);}
                } else if (this.page <= 6) {
                    // 2. current page is too small
                    for (let i = 1; i <= 9; i++) {result.push(i);}
                } else if ((this.pages - 5) <= this.page) {
                    // 3. current page is too large
                    for (let i = (this.pages - 8); i <= this.pages; i++) {result.push(i);}
                } else {
                    // x. normal case
                    for (let i = (this.page - 3); i <= (this.page + 3); i++) {result.push(i);}
                }
                return result;
            }
        },
        methods: {
            goToInputValidation(targetValue) {
                let value = Number(targetValue);
                if (isNaN(value)) {
                    return;
                }
                // 정수필터
                if (!(/^(0|-?[1-9][0-9]*)$/.test(value))) {
                    targetValue = this.goToPage;
                    return;
                }
                this.goToPage = value;
            },
            // @vuese
            // $ver: v0.1.0
            // $arg: Page Number
            // $return: N/A
            // 지정한 페이지 번호로 이동합니다.
            // #Moves to the specified page number.
            clickToMovePage(n) {
                this.goToPage = n;
                this.moveToPage();
            },
            moveToPage() {
                let nextPage = parseInt(this.goToPage);
                if (nextPage === this.page) { return; }
                if (nextPage > this.pages) { nextPage = this.pages;}
                else if (nextPage <= 0) { nextPage = 1;}
                this.page = nextPage;
                this.goToPage = nextPage;

                // $ver: v0.1.0
                // $arg: Page Number
                // 페이지 전환 시 현재 페이지 번호를 파라미터로 이벤트를 호출합니다.
                // #When switching pages, call the event with the current page number as a parameter.
                this.$emit('move', nextPage);
            },
            selectedPage(n) {
                return (n === this.page);
            },
            onClickLeft() {
                if (this.isLeftEnd) { return; }
                this.page = (this.page - 1);
                this.goToPage = this.page;
                this.$emit('move', this.page);
            },
            onClickRight() {
                if (this.isRightEnd) { return; }
                this.page = (Number(this.page) + 1);
                this.goToPage = this.page;
                this.$emit('move', this.page);
            },
        }
    };

</script>