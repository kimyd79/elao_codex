import legoPagination from "./legoPagination.vue";
export default {
    install(Vue){
        Vue.component(legoPagination.name, legoPagination);
    }
};