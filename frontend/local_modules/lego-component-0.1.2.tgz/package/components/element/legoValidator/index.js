import legoValidator from "./legoValidator.vue";
export default {
    install(Vue){
        Vue.component(legoValidator.name, legoValidator);
    }
};