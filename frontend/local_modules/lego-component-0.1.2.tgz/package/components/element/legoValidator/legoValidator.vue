<script>
    import legoValidatorMixin from '../../../mixins/legoValidator/legoValidatorMixin.vue';

    export default {
        name: 'lego-validator',
        props: {
            value: [String,Number,Boolean,Array,Object,Date,Function,Symbol],
            successMessage: {
                type: String
            },
            guideMessage: {
                type: String
            }
            /* [FROM VALIDATOR] */
            // rules
            // disabled
            // lazy
            // noShake
            /********************/
        },

        mixins: [legoValidatorMixin],
        data() {return {
            /* [FROM VALIDATOR] */
            // hasError
            // errorMessage
            // showValid
            // shake
            /********************/
        }},
        computed: {
            /* [FROM VALIDATOR] */
            // isValidatable
            // el
            validateTarget() {return this.value;}, // validation setting
            /********************/
            messageShow() {
                if(this.hasError === undefined) {
                    return this.guideMessage;
                }
                if (this.hasError === true) {
                    return this.errorMessage;
                }
                if (this.hasError === false) {
                    return this.successMessage || this.guideMessage;
                }
                return undefined;
            },
            validatorClass() {
                let clazz = [];
                if(this.messageShow) {clazz.push('lego-validator--has-message')}
                if(this.hasError === true) {clazz.push('lego-validator--error')}
                if(this.showValid && this.hasError === false) {clazz.push('lego-validator--valid')}
                if(this.shake) {clazz.push('lego-validator--shake')}
                return clazz;
            }
        },
        watch: {
            successMessage: {
                immediate: true,
                handler(val) {
                    this.showValid = !!val;
                }
            },
        },
        mounted() {
        },
        methods: {
            /* [FROM VALIDATOR] */
            // validate()        --+
            // isValid()         --+-- exposed methods for manual validate control
            // clearValidation() --+
            // validateOnEvent() -> should be set by each component which uses legoValidatorMixin
            /********************/
        },
        render() {
            return this.$scopedSlots.default({
                // methods
                validate: this.validate,
                validateOnEvent: this.validateOnEvent,
                isValid: this.isValid,
                clearValidation: this.clearValidation,

                // variables
                hasError: this.hasError,
                messageShow: this.messageShow,
                validatorClass: this.validatorClass,
                disabled: this.disabled
            });
        }
    }
</script>