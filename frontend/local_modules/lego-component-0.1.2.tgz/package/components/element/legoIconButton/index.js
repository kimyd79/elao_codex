import legoIconButton from "./legoIconButton.vue";
export default {
    install(Vue){
        Vue.component(legoIconButton.name, legoIconButton);
    }
};