<template>
    <lego-button v-bind="buttonProps"
                 v-on="$listeners"
                 :class="buttonClass"
                 @click="mToggle"><lego-icon v-bind="iconProps"><slot/></lego-icon></lego-button>
</template>

<script>
import legoButton from '../legoButton/legoButton';
import legoIcon from '../legoIcon/legoIcon';
export default {
    name: 'lego-icon-button',
    components:{legoButton, legoIcon},
    props: {
        /* ICON BUTTON PROPS */
        toggle: {type:Boolean, default: false},
        value: {type:Boolean},

        /* COMMON PROPS*/
        large : {type: Boolean, default: false},
        medium : {type: Boolean, default: false},
        small: {type: Boolean, default: false},

        /* BUTTON PROPS */
        solid   : {type: Boolean, default: false},
        border  : {type: Boolean, default: true},
        disabled: {type: Boolean, default: false},
        loading : {type: Boolean, default: false},
        primary: {type: Boolean, default: false},
        point: {type: Boolean, default: false},
        color: {type:String, default: undefined},
        full : {type: Boolean, default: false},

        /* ICON */
        icon: {type: String, default: ''},
        iconType: {
            type: String,
            default: 'line',
            validator: function(value) {
                return ['line', 'picto'].indexOf(value) !== -1;
            }
        },
        iconSize: {type: [String, Number], default:'inherit'},
        spacing: {type: Boolean, default: false},
        brand   : Boolean,
        regular : Boolean,
        light   : Boolean,
        old     : Boolean,
        fab     : Boolean,
        far     : Boolean,
        fal     : Boolean,
        fa      : Boolean,

        /* abbr */
        type: {
            type: String,
            default: 'line',
            validator: function(value) {
                return ['line', 'picto'].indexOf(value) !== -1;
            }
        },
        size: {type: [String, Number]},
        bor: {type: Boolean, default: false},
        sol: {type: Boolean, default: false},
        bLess: {type: Boolean, default: false},
        prim: {type: Boolean, default: false},
        pnt: {type: Boolean, default: false},
        col: {type: String, default: undefined},
        lg: {type: Boolean, default: false},
        md: {type: Boolean, default: false},
        sm: {type: Boolean, default: false},
        borderless : {type: Boolean, default: false},
    },
    data(){return{
    }},
    computed: {
        buttonClass() {
            return [
            'lego-icon-button',
            this.toggle && this.value === false ? 'lego-icon-button--off': '',

        ]},
        buttonProps() {return {
            solid: this.solid,
            borderless: this.borderless,
            border: this.border,
            toggle: this.toggle,
            large: this.large,
            medium: this.medium,
            small: this.small,
            disabled: this.disabled,
            loading: this.loading,
            primary: this.primary,
            point: this.point,
            color: this.color,
            full: this.full,
            bor: this.bor,
            sol: this.sol,
            bLess: this.bLess,
            prim: this.prim,
            pnt: this.pnt,
            col: this.col,
            lg: this.lg,
            md: this.md,
            sm: this.sm,
        }},
        iconProps() {return {
            icon: this.icon,
            iconType: this.iconType,
            iconSize: this.iconSize,
            spacing: this.spacing,
            brand: this.brand,
            regular: this.regular,
            light: this.light,
            old: this.old,
            fab: this.fab,
            far: this.far,
            fal: this.fal,
            fa: this.fa,
            type: this.type,
            size: this.size,
        }}
    },
    methods: {
        mToggle(e) {
            if(!this.toggle) { return; }
            this.$emit('input', !this.value);
        }
    }
}
</script>