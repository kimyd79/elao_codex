import legoList from "./legoList.vue";
import legoListItem from "./legoListItem.vue";
export default {
    install(Vue){
        Vue.component(legoList.name, legoList);
        Vue.component(legoListItem.name, legoListItem);
    }
};