<template>
    <div class="list-item">
        <!--
            $ver: v0.1.0
            <em>lego-list</em> 컴포넌트로 표현되는 리스트 목록의 내부 영역입니다.
            #The internal area of ​​the list of lists represented by the <em>lego-list</em> component.
        -->
        <slot/>
    </div>
</template>

<script>
export default {
    name : "legoListItem"
}
</script>