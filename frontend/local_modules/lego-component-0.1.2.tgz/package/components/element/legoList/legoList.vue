<template>
    <div>
        <!--
            $ver: v0.1.0
            리스트 내부 영역입니다. 예제에서 사용된 class를 활용하여 리스트 내부를 표현할 수 있습니다.
            #The area inside the list. You can use the class used in the example to express the inside of the list.
        -->
        <slot/>
    </div>
</template>

<script>
export default {
    name : "legoList"
}
</script>