import legoSwitch from "./legoSwitch.vue";
export default {
    install(Vue){
        Vue.component(legoSwitch.name, legoSwitch);
    }
};