<template>
    <div class="lego-switch lego-input" :class="rootClass" @click.stop="toggleValue">
        <div class="lego-switch__circle"></div>
        <div v-if="labeled" class="lego-switch__text"> {{ innerText }} </div>
    </div>
</template>

<script>
    export default {
        name: 'lego-switch',
        model: { /*same as default*/
            event: 'input', prop: 'value'
        },
        inject: {
            legoInput: {from:'legoInput', default: () => undefined}
        },
        props: {
            // $ver: v0.1.0
            // $v-model
            // v-model로 바인딩되는 값으로, 스위치의 값과 연계됩니다. positiveValue/negativeValue 속성으로 지정한 값을 가집니다.
            // #The value bound to v-model, associated with the value of the switch. It has the value specified by the positiveValue / negativeValue property.
            // $default: true
            value: {
                type: [Boolean, String],
                default: true,
            },
            // $ver: v0.1.0
            // 토글 되었을 때 값을 지정합니다.
            // #Specifies the value when toggled.
            // $default: true
            positiveValue: {
                type: [Boolean, String],
                default: true
            },
            // $ver: v0.1.0
            // 토글 해제 되었을 때 값을 지정합니다.
            // #Specifies the value when toggled off.
            // $default: false
            negativeValue: {
                type: [Boolean, String],
                default: false
            },
            // $ver: v0.1.0
            // 컴포넌트 크기를 Large 사이즈로 설정합니다.
            // #Set the component size to Large.
            // $default: false
            large: {
                type: Boolean,
                default: false
            },
            // $abbr: large
            lg:{type:Boolean},
            // $ver: v0.1.2
            // 컴포넌트 크기를 Medium 사이즈로 설정합니다.
            // #Set the component size to Medium size.
            // $default: false
            medium: {
                type: Boolean,
                default: false
            },
            // $abbr: medium
            md:{type:Boolean},
            // $ver: v0.1.2
            // 컴포넌트 크기를 Small 사이즈로 설정합니다.
            // #Set the component size to Small size.
            // $default: false
            small: {
                type: Boolean,
                default: false
            },
            // $abbr: large
            sm:{type:Boolean},
            // $ver: v0.1.0
            // 비활성화 상태로 변경합니다.
            // #Change to inactive state.
            // $default: false
            disabled: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.0
            // ON/OFF 문자를 토글/토글해제 시 표시합니다.
            // #ON / OFF Displays characters when toggled / toggled.
            // $default: false
            labeled: {
                type: Boolean,
                default: false
            },
        },
        data() {return{
            default:{
                size: 'medium'
            }
        }},
        computed: {
            $_size() {
                if(this.large || this.lg) {return 'large'}
                if(this.medium || this.md) {return 'medium'}
                if(this.small || this.sm) {return 'small'}
                if(this.legoInput) {return this.legoInput.size}
                return this.default.size;
            },
            rootClass() {
                let rtn = [];
                rtn.push('lego-switch--'+this.$_size);
                if(this.labeled){rtn.push('lego-switch--labeled');}
                if(this.disabled){rtn.push('lego-switch--disabled');}
                if(this.value===this.negativeValue) {rtn.push('lego-switch--off');}
                else {rtn.push('lego-switch--on');}
                return rtn;
            },
            innerText() {
                return (this.value===this.positiveValue ? 'ON' : 'OFF');
            },
        },
        methods: {
            // @vuese
            // $ver: v0.1.0
            // $return: N/A
            // 토글/토글해제 처리합니다.
            // #Toggles / untoggles.
            toggleValue() {
                if (!this.disabled) {
                    if(this.value===this.positiveValue) {
                        // $ver: v0.1.0
                        // $return: updated value
                        // 토글/토글해제 될 때, 변경된 값을 파라미터로 이벤트를 발생시킵니다.
                        // #When toggled / untoggled, triggers an event with the changed value as a parameter.
                        this.$emit('input', this.negativeValue);
                    } else {
                        this.$emit('input', this.positiveValue);
                    }
                }
            }
        }
    };

</script>