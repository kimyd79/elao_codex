<template>
    <div class="lego-date-picker lego-input" :class="'lego-date-picker--'+$_size" v-picker-click-outside="onClickOutside">
        <lego-text-field ref="from-text" class="lego-date-picker__text-field"
                         v-model="from.textInput"
                         :mask="inputType.replace(/#/g,'%#').replace(/[ymd]/gi,'#')"
                         :placeholder="noPlaceholder?'':inputType.toUpperCase()"
                         :disabled="disabled"
                         :no-shake="noShake"
                         @focus="onFocus(1)"
                         @enter="onUpdate(1)"
                         @keydown.tab="(e)=>onUpdate(1,e)"/><!--
     --><lego-icon-wrapper class="lego-date-picker__icon-wrapper" @click.native.stop="onClickIcon(1)">
            <lego-icon class="lego-date-picker__icon" icon="calendar"></lego-icon>
        </lego-icon-wrapper>
        <template v-if="range||strictRange">
            <lego-icon-wrapper>
                ~
            </lego-icon-wrapper>
            <lego-text-field ref="to-text" class="lego-date-picker__text-field" id="aaa"
                             v-model="to.textInput"
                             :mask="inputType.replace(/#/g,'%#').replace(/[ymd]/gi,'#')"
                             :placeholder="noPlaceholder?'':inputType.toUpperCase()"
                             :disabled="disabled"
                             :no-shake="noShake"
                             tabindex="-1"
                             @focus="onFocus(2)"
                             @enter="onUpdate(2)"
                             @keydown.tab="(e)=>onUpdate(2,e)"/><!--
         --><lego-icon-wrapper class="lego-date-picker__icon-wrapper" @click.native.stop="onClickIcon(2)">
                <lego-icon class="lego-date-picker__icon" icon="calendar"></lego-icon>
            </lego-icon-wrapper>
        </template>
        <lego-segment-wrapper v-if="preset.length >0" v-model="presetName" v-bind="segmentWrapperBind" class="lego-date-picker__segment-wrapper">
            <template v-for="(item,idx) in preset">
                <lego-segment-button :value="item.action"
                                     :key="idx"
                                     @click.stop="onClickSegment(item.action)"><!--
                     -->{{item.label}}<!--
                 --></lego-segment-button>
            </template>
        </lego-segment-wrapper>

        <div class="lego-date-picker__calendar" :class="calendarClass" v-show="showFlag">
            <div class="lego-date-picker__calendar__month-area">
                <lego-icon-wrapper @click.native.stop="onClickPrevMonth(showFlag)">
                    <lego-icon icon="expand_menu" ></lego-icon>
                </lego-icon-wrapper>
                <span>
                    {{monthFilter(calendarMonth,1)}}
                </span>
                <template v-if="showFlag===2">
                    -
                    <span>
                        {{monthFilter(calendarMonth,2)}}
                    </span>
                </template>

                <lego-icon-wrapper @click.native.stop="onClickNextMonth(showFlag)">
                    <lego-icon icon="collapse_menu" ></lego-icon>
                </lego-icon-wrapper>
            </div>
            <div class="lego-date-picker__calendar__range-container">
                <div class="lego-date-picker__calendar__date-area">
                    <div class="lego-date-picker__calendar__day lego-date-picker__calendar__row">
                        <div class="lego-date-picker__calendar__row-background"></div>
                        <div class="lego-date-picker__calendar__row-content">
                            <template v-for="(day, idx) in weekDay">
                                <span :key="idx" :class="weekDayClass(idx)">{{day.text}}</span>
                            </template>
                        </div>

                    </div>
                    <div class="lego-date-picker__calendar__date-wrapper" @mouseleave="hoverDate=''">
                        <template v-for="(week,wIdx) in monthCalendar(calendarMonth,1)">
                            <div :key="wIdx" class="lego-date-picker__calendar__week lego-date-picker__calendar__row">
                                <div class="lego-date-picker__calendar__row-background">
                                    <template v-for="(date,dIdx) in week">
                                        <div :key="dIdx" :class="date.rangeColor"></div>
                                    </template>
                                </div>
                                <div class="lego-date-picker__calendar__row-content">
                                    <template v-for="(date,dIdx) in week">
                                        <span :key="dIdx"
                                              :class="dateClass(date,dIdx)"
                                              @click.stop="onClickDate(date)"
                                              @mouseenter="hoverDate=date.value">{{date.text}}</span>
                                    </template>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
                <template v-if="showFlag===2">
                    <div class="lego-date-picker__calendar__divider"></div>
                    <div class="lego-date-picker__calendar__date-area">
                        <div class="lego-date-picker__calendar__day lego-date-picker__calendar__row">
                            <div class="lego-date-picker__calendar__row-background"></div>
                            <div class="lego-date-picker__calendar__row-content">
                                <template v-for="(day, idx) in weekDay">
                                    <span :key="idx" :class="weekDayClass(idx)">{{day.text}}</span>
                                </template>
                            </div>
                        </div>
                        <div class="lego-date-picker__calendar__date-wrapper" @mouseleave="hoverDate=''">
                            <template v-for="(week,wIdx) in monthCalendar(calendarMonth,2)">
                                <div :key="wIdx" class="lego-date-picker__calendar__week lego-date-picker__calendar__row">
                                    <div class="lego-date-picker__calendar__row-background">
                                        <template v-for="(date,dIdx) in week">
                                            <div :key="dIdx" :class="date.rangeColor"></div>
                                        </template>
                                    </div>
                                    <div class="lego-date-picker__calendar__row-content">
                                        <template v-for="(date,dIdx) in week">
                                            <span :key="dIdx"
                                                  :class="dateClass(date, dIdx)"
                                                  @click.stop="onClickDate(date)"
                                                  @mouseenter="hoverDate=date.value">{{date.text}}</span>
                                        </template>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>
                </template>
            </div>
            <lego-action-bar class="lego-date-picker__action-bar">
                <template v-slot:left>
                    <lego-button tabindex="-1" sm borderless @click.native.stop="onClickToday">{{todayLabel}}</lego-button>
                </template>
                <lego-button tabindex="-1" sm main @click.native.stop="onConfirm">{{confirmLabel}}</lego-button>
            </lego-action-bar>
        </div>
    </div>
</template>

<script>
    import legoValidatorMixin from '../../../mixins/legoValidator/legoValidatorMixin.vue';

    const DUMMY_EVENT = {
        preventDefault: ()=>{}
    };
    // lego-date-picker는 v0.1.1버전까지 tui-date-picker를 사용하다가
    // v0.1.2버전부터 dependency없이 자체개발 컴포넌트로 전환되었습니다.
    // #The lego-date-picker used tui-date-picker until v0.1.1, but was converted to a self-developed component without dependency from v0.1.2.
    export default {
    // TODO: validator를 넣어놓긴했는데 message띄우는 영역 설정을 안했네요.. lego-radio-wrapper등을 참고하여 메시지를 넣고 css설정을 해주시면 되겠습니다.
    // rules를 통합으로 넣을지 fromRules, toRules, rules 세가지를 사용하고 fromValidate->toValidate->validate 순서로 validate를 할지 고민하다가 결론을 못내고 미루다가 깜빡했나봐요
    // TODO: dropdown, datepicker 같이 클릭했을 때 위로 뜨는 창이 생기는 경우 lego-tooltip 혹은 v-lego-tooltip처럼 wrapper의 overflow설정에 영향을 안받으면서 뜰 수 있도록 설정을...
    // 1~2월중에 하려고는 했었는데 미루다가 못했습니다 ㅠ
    name: 'lego-date-picker',
    mixins: [legoValidatorMixin],
    inject: {
        legoInput: {from:'legoInput', default: () => undefined}
    },
    props: {
        // $ver: v0.1.2
        // $v-model
        // 선택된 date 혹은 date range를 나타내는 값입니다. model-type props의 설정에 따라
        // date, range, 혹은 설정한 format의 문자열로 반환됩니다.
        // range형태라면 해당 타입의 값을 element로 하는 length 2의 Array형태로 반환됩니다.
        // 형식에 맞지 않는 데이터가 입력될 경우 빈값('' 혹은 ['',''])으로 변경될 수 있습니다.
        // #A value representing the selected date or date range. Depending on the model-type props setting, 
        // #it is returned as a string in date, range, or the format you set.
        // #If it is a range type, it is returned as an Array of length 2 whose value is the element.
        // #If incorrect data is entered, it may be changed to empty value ('' or ['', '']).
        value: {
            type: [String, Array, Date],
            required: true
        },
        // $ver: v0.1.2
        // text-field영역에 입력되는 date-format입니다.
        // YY,YYYY,MM,DD와 특수문자등을 포함한 문자열로 설정할 수 있습니다.
        // 만약 MM/DD/YY를 inputType으로 설정한다면 text-field에 날짜 입력시에도
        // 동일 순서로 일,월,년도 순으로 입력해야합니다.
        // #The date-format entered in the text-field area.
        // #Can be set to a string containing YY, YYYY, MM, DD and special characters.
        // #If MM / DD / YY is set as inputType, even when entering date in text-field
        // #You must enter the date, month, year in the same order.
        inputType: {
            type: String,
            default: 'YYYY-MM-DD',
            validator: (val) => {
                return /^(?=.*yy)(?=.*mm)(?=.*dd)(yy|mm|dd|\W)+$/i.test(val)
                    && val.match(/y{1,4}/gi).length === 1
                    && val.match(/m{1,2}/gi).length === 1
                    && val.match(/d{1,2}/gi).length === 1;
            }
        },
        // $ver: v0.1.2
        // v-model로 반환될 date-format입니다.
        // 'date'(javascript Date object), 'array'([YYYY,MM,DD]) 혹은 input-type과 동일하게 YY,YYYY,MM,DD와 특수문자등을
        // 포함한 문자열로 설정할 수 있습니다.
        // #Like 'date' (javascript Date object), 'array' ([YYYY, MM, DD]) or input-type,
        // #it can be set to a string including YY, YYYY, MM, DD and special characters.
        modelType: {
            type: String,
            default: 'YYYY-MM-DD',
            validator: (val) => {
                if(/^(date|array)$/i.test(val)) {return true;}
                return /^(?=.*yy)(?=.*mm)(?=.*dd)(yy|mm|dd|\W)+$/i.test(val)
                    && val.match(/y{1,4}/gi).length === 1
                    && val.match(/m{1,2}/gi).length === 1
                    && val.match(/d{1,2}/gi).length === 1;
            }
        },
        // $ver: v0.1.2
        // 컴포넌트가 created되는 시점에 v-model의 초기값을 설정할 수 있습니다.<br>
        // 'none': default값으로, 아무런 설정을 하지 않습니다. 원래의 v-model값을 그대로 사용합니다.<br>
        // 'clear': v-model값을 '' 혹은 ['','']로 설정합니다.<br>
        // 'today': v-model값을 오늘날짜로 설정합니다. range설정이 있다면 오늘~오늘로 설정합니다.<br>
        // 그 외에 자유롭게 특정일 혹은 특정기간을 설정할 수 있습니다. {unit}에는 'day', 'week', 'month', 'year'이 사용됩니다.<br>
        // '{unit}+?': 오늘을 기준으로 ?{unit} 뒤의 날짜를 설정합니다. range설정이 있다면 오늘~해당일로 설정합니다.<br>
        // '{unit}-?': 오늘을 기준으로 ?{unit} 전의 날짜를 설정합니다. range설정이 있다면 해당일~오늘로 설정합니다.<br>
        // #You can set the initial value of v-model when the component is created. <br>
        // #'none': This is the default value and no setting is done. Accept the original v-model value. <br>
        // #'clear': Set the v-model value to '' or ['', '']. <br>
        // #'today': Set the v-model value to today. If there is a range setting, set today to today. <br>
        // #In addition, you can freely set a specific date or period. {unit} uses 'day', 'week', 'month', and 'year'. <br>
        // #'{unit} +?': Set the date after? {unit} as of today. If there is a range setting, set it as today ~ the day. <br>
        // #'{unit}-?': Set the date before? {unit} as of today. If there is a range setting, set it from today to today. <br>
        init:{
            type:String,
            default: 'none',
            validator: (val) => {
                return /^(none|clear|today|day[+-][0-9]+|week[+-][0-9]+|month[+-][0-9]+|year[+-][0-9]+)$/i.test(val);
            }
        },
        // $ver: v0.1.2
        // YYYY-MM-DD의 형식으로 선택가능한 minimum date를 설정할 수 있습니다.
        // #You can set a selectable minimum date in the format YYYY-MM-DD.
        minDate: {
            type: String,
            default: '1970-01-01',
            validate: (val) => {
                return /^(19[7-9][0-9]|[2-9][0-9]{3})-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/.test(val);
            }
        },
        // $ver: v0.1.2
        // YYYY-MM-DD의 형식으로 선택가능한 maximum date를 설정할 수 있습니다.
        // #You can set a selectable maximum date in the format YYYY-MM-DD.
        maxDate: {
            type: String,
            default: '9999-12-31',
            validate: (val) => {
                return /^(19[7-9][0-9]|[2-9][0-9]{3})-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/.test(val);
            }
        },
        // $ver: v0.1.2
        // range 혹은 strictRange를 true로 주면 date-range를 선택할 수 있습니다.
        // #If you set range or strictRange to true, you can select a date-range.
        // $default: false
        range: {
            type:Boolean,
            default: false
        },
        // $ver: v0.1.2
        // range 혹은 strictRange를 true로 주면 date-range를 선택할 수 있습니다.
        // strict-range가 false인 경우 시작일 혹은 종료일이 빈값으로 설정될 수 있으나
        // strict-range가 true인 경우 시작일과 종료일이 둘 다 선택되어야 v-model값이 업데이트 됩니다.
        // #If you set range or strictRange to true, you can select a date-range.
        // #If strict-range is false, the start date or end date can be set to an empty value. 
        // #If strict-range is true, the v-model value will not be updated until both start date and end date are selected.
        // $default: false
        strictRange: {
            type:Boolean,
            default: false
        },
        // $ver: v0.1.2
        // <em>lego-date-picker</em>우측으로 프리셋 버튼을 생성합니다.
        // {label: String, action: String}을 element로 갖는 Array이며 각각의 element는 하나의 segment-button을 의미합니다.
        // label은 segment-button에 표시되는 text이고,
        // action은 init props와 동일한 형식으로 'clear', 'today', '{unit}[+-]?'등의 값을 사용합니다.
        // #<em>lego-date-picker</em> Create a preset button to the right.
        // #{label: String, action: String} An Array with elements, each element representing one segment-button.
        // #label is the text displayed in the segment-button, and action uses the same format as init props, with values ​​such as 'clear', 'today', '{unit} [+-]?'.
        preset: {
            type:Array,
            validate: (arr) => {
                return arr.every((item)=>{
                    return item.label && /^(clear|today|day[+-][0-9]+|week[+-][0-9]+|month[+-][0-9]+|year[+-][0-9]+)$/.test(item.action)
                })
            },
            default: () => []
        },
        // $ver: v0.1.2
        // text-field영역의 placeholder는 기본적으로 input-type이 형식에 따라 적절한 placeholder를 갖지만
        // no-placeholder 옵션을 통해 placeholder를 표시하지 않을 수 있습니다.
        // #Placeholders in the text-field area have an appropriate placeholder by default, 
        // #although the input-type has a proper placeholder, but the no-placeholder option may not display the placeholder.
        // $default: false
        noPlaceholder: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // preset props설정으로 생기는 <em>lego-segment-wrapper</em>에 추가적인 옵션을 주고싶다면
        // segment-wrapper-bind에 object 타입으로 props 및 class, style등을 전달할 수 있습니다.
        // #If you want to add additional options to the <em>lego-segment-wrapper</em> resulting from the preset props configuration, 
        // #you can pass props, class and style as object types to the segment-wrapper-bind.
        segmentWrapperBind: {
            type: Object,
            default: () => {}
        },
        // $ver: v0.1.2
        // medium 크기의 date-picker를 사용합니다. calendar의 크기는 변하지 않습니다.
        // #Use a medium size date-picker. The size of the calendar does not change.
        // $default: false
        medium: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // $abbr: medium
        md: {type: Boolean},
        // $ver: v0.1.2
        // small 크기의 date-picker를 사용합니다. calendar의 크기는 변하지 않습니다.
        // #Use a small size date-picker. The size of the calendar does not change.
        // $default: false
        small: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // $abbr: small
        sm: {type: Boolean},
        // $ver: v0.1.2
        // calendar영역의 today button에 들어갈 text를 설정할 수 있습니다. 다국어 처리를 위해 만들었습니다.
        // #You can set the text for the today button in the calendar area. Created for multilingual processing.
        todayLabel: {
            type:String,
            default: 'Today'
        },
        // $ver: v0.1.2
        // calendar영역의 confirm button에 들어갈 text를 설정할 수 있습니다. 다국어 처리를 위해 만들었습니다.
        // #You can set the text for the confirm button in the calendar area. Created for multilingual processing.
        confirmLabel: {
            type: String,
            default: 'Confirm'
        },

        // $ver: v0.1.x
        // 미완성
        guideMessage: {type:String, default: undefined},
        // $ver: v0.1.x
        // 미완성
        successMessage: {type:String, default: undefined},
        /* [FROM VALIDATOR] */
        // rules
        // disabled
        // lazy
        // noShake
        /********************/
    },
    data() {return {
        default: {
            size: 'medium'
        },
        weekDay: [
            {text:'S', value: 'SUN'},
            {text:'M', value: 'MON'},
            {text:'T', value: 'TUE'},
            {text:'W', value: 'WED'},
            {text:'T', value: 'THU'},
            {text:'F', value: 'FRI'},
            {text:'S', value: 'SAT'}
        ],
        monthAbbr: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],

        today: '', // YYYY-MM-DD
        currTime: {}, // Date object

        // if user changes textInput, set selected same as textInput. and then $emit to v-model from selected
        // if user changes selected, set textInput same as selected. and then $emit to v-model from selected
        from: {
            actualDate: '', // YYYY-MM-DD // always equal to v-modal value but form of YYYY-MM-DD
            textInput:'', // only Numbers. YMD order depends on inputType // text-field value
            selected: '', // YYYY-MM-DD // calendar selected value. equal to textInput but form of YYYY-MM-DD
        },
        to: {
            actualDate: '', // YYYY-MM-DD // always equal to v-modal value but form of YYYY-MM-DD
            textInput: '', // only Numbers. YMD order depends on inputType // text-field value
            selected: '', // YYYY-MM-DD // calendar selected value. equal to textInput but form of YYYY-MM-DD
        },


        hoverDate: '', // YYYY-MM-DD
        calendarMonth: [], // [YYYY, MM]
        showFlag: 0, // 0: none, 1: single calendar, 2: double calendar

        presetName: '',
        presetVal: '', // YYYY-MM-DD or [YYYY-MM-DD, YYYY-MM-DD]

        /* [FROM VALIDATOR] */
        // hasError
        // errorMessage
        // showValid
        // shake
        /********************/
        validateFlag:false
    }},
    computed: {
        /* [FROM VALIDATOR] */
        // isValidatable
        // el
        validateTarget() {return this.value;}, // validation setting
        /********************/

        $_size() {
            if(this.medium || this.md) {return 'medium'}
            if(this.small || this.sm) {return 'small'}
            if(this.legoInput) {return this.legoInput.size}
            return this.default.size;
        },
        $_isRange() {
            return this.range || this.strictRange;
        },
        calendarClass() {
            return {
                'lego-date-picker__calendar--range': this.showFlag === 2,
                'lego-date-picker__calendar--select-range': this.showFlag === 2 && (this.from.selected || this.to.selected)
            }
        },
        sundayIdx() {
            for(let idx in this.weekDay) {
                if(this.weekDay[idx].value ==='SUN') {
                    return parseInt(idx);
                }
            }
            return -1;
        },
        saturdayIdx() {
            for(let idx in this.weekDay) {
                if(this.weekDay[idx].value ==='SAT') {
                    return parseInt(idx);
                }
            }
            return -1;
        }
    },
    watch: {
        // for validatorMixin
        successMessage: {
            immediate: true,
            handler(val) {
                this.showValid = !!val;
            }
        },

        value: {
            immediate: true,
            handler(value){
                // from.actualDate & to.actualDate only controlled by this handler. they must be equal to v-model
                if(!this.today) {
                    this.currTime = new Date();
                    this.today = this.dateToYmd(this.currTime);
                }
                let rtn, targetMonth, validVal;
                if(this.$_isRange) {
                    validVal = this.toValidRange(value);
                    if( this.from.actualDate !== validVal[0] ){
                        this.from.actualDate = validVal[0];
                        this.from.textInput = this.ymdToText(this.from.actualDate);
                        this.from.selected = validVal[0];
                    }
                    if( this.to.actualDate !== validVal[1] ) {
                        this.to.actualDate = validVal[1];
                        this.to.textInput = this.ymdToText(this.to.actualDate);
                        this.to.selected = validVal[1];
                    }

                    if(validVal[1]) {
                        targetMonth = validVal[1].split('-');
                        targetMonth[1] = parseInt(targetMonth[1]) - 1;
                    } else if(validVal[0]) {
                        targetMonth = validVal[0].split('-');
                    }

                    if(!this.isEqualArray(this.presetVal,validVal)) this.presetName = '';
                    rtn = [this.ymdToModel(validVal[0]),this.ymdToModel(validVal[1])];
                    if(!this.isEqualArray(value,rtn)) {
                        // ~documentation~
                        // $ver: v0.1.2
                        // $arg: updated v-model value
                        // v-model을 업데이트하기 위한 이벤트
                        // #Event to update v-model
                        this.$emit('input',rtn);
                    }
                    else if(this.validateFlag) {this.validateFlag=false;this.validateOnEvent();}
                } else {
                    validVal = this.modelToYmd(value);
                    validVal = this.toValidYmd(validVal);
                    if( this.from.actualDate !== validVal ) {
                        this.from.actualDate = validVal;
                        this.from.textInput = this.ymdToText(this.from.actualDate);
                        this.from.selected = validVal;
                    }

                    if(validVal) {
                        targetMonth = validVal.split('-');
                    }

                    if(this.presetVal !== validVal) this.presetName = '';
                    rtn = this.ymdToModel(validVal);
                    if(!this.isEqualModel(value,rtn)) {this.$emit('input',rtn);}
                    else if(this.validateFlag) {this.validateFlag=false;this.validateOnEvent();}
                }
                if(!targetMonth) {
                    let date = this.today;
                    if(date < this.minDate) {date = this.minDate;}
                    if(date > this.maxDate) {date = this.maxDate;}
                    targetMonth = date.split('-');
                }
                this.setCalendarMonth([parseInt(targetMonth[0]), parseInt(targetMonth[1])]);
            }
        },
        showFlag(newFlag,oldFlag) {
            let tmp;
            if(newFlag === 1) {
                if(this.$_isRange) {
                    this.to.textInput = '';
                    this.to.selected = '';
                }
                if(this.from.selected) {
                    tmp = this.from.selected;
                } else {
                    tmp = this.today < this.minDate? this.minDate : this.today > this.maxDate? this.maxDate : this.today;
                }
                tmp = tmp.split('-');
                this.setCalendarMonth([parseInt(tmp[0]),parseInt(tmp[1])]);
            } else if(newFlag === 2) {
                if(this.to.selected){
                    tmp = this.dateToYmd(this.ymdToDate(this.to.selected,0,-1,0));
                } else if(this.from.selected) {
                    tmp = this.from.selected;
                } else {
                    tmp = this.today < this.minDate? this.minDate : this.today > this.maxDate? this.maxDate : this.today;
                }
                tmp = tmp.split('-');
                this.setCalendarMonth([parseInt(tmp[0]),parseInt(tmp[1])]);
            }
        }
    },
    created() {
        this.currTime = new Date();
        this.today = this.dateToYmd(this.currTime);
        this.onClickSegment(this.init);
        if(!Array.isArray(this.calendarMonth) || this.calendarMonth.length !==2 || this.isEqualArray(['',''],this.calendarMonth)) {
            let date = this.today < this.minDate? this.minDate : this.today > this.maxDate? this.maxDate : this.today;
            let tmp = this.dateToYmd(this.ymdToDate(date,0,0,0));
            tmp = tmp.split('-');
            this.setCalendarMonth([parseInt(tmp[0]),parseInt(tmp[1])]);
        }
    },
    methods: {
        /* [FROM VALIDATOR] */
        // validate()        --+
        // isValid()         --+-- exposed methods for manual validate control
        // clearValidation() --+
        // validateOnEvent() -> should be set by each component which uses legoValidatorMixin
        /********************/

        toValidRange(value) {
            let newVal;
            if(!(Array.isArray(value) && value.length === 2)) {
                return ['',''];
            }
            newVal = [this.modelToYmd(value[0]), this.modelToYmd(value[1])];
            if(this.strictRange && !(newVal[0]&&newVal[1])) {
                return ['',''];
            }
            newVal[0] = this.toValidYmd(newVal[0]);
            newVal[1] = this.toValidYmd(newVal[1]);
            if(newVal[0] && newVal[1] && newVal[0] > newVal[1]) {
                newVal[1] = newVal[0];
            }
            return newVal;
        },
        toValidYmd(ymd) {
            if(!ymd || typeof ymd !== 'string') {return '';}
            if(ymd > this.maxDate) {ymd = this.maxDate;}
            if(ymd < this.minDate) {ymd = this.minDate;}
            return ymd;
        },
        $_parseInt(val) {
            let tmp = parseInt(val);
            if(Number.isNaN(tmp)) {return undefined;}
            return tmp;
        },
        setCalendarMonth(calendarMonth) {
            let YYYY,MM;
            if(Array.isArray(calendarMonth) && calendarMonth.length ===2) {
                this.calendarMonth = [];
                YYYY = parseInt(calendarMonth[0]);
                MM = parseInt(calendarMonth[1]);
                if(MM < 1) {
                    YYYY -= 1;
                    MM += 12;
                }
                if(MM > 12) {
                    YYYY += 1;
                    MM -= 12;
                }
                this.calendarMonth.push(YYYY);
                this.calendarMonth.push(MM);
            }
        },
        isEqualArray(arr1,arr2) {
            if(!(Array.isArray(arr1) && Array.isArray(arr2))) {return false;}
            if(arr1.length !== arr2.length){return false;}
            for(let i = 0 ; i < arr1.length ; i++) {
                if(!this.isEqualModel(arr1[i],arr2[i])) {return false;}
            }
            return true;
        },
        isEqualModel(m1, m2) {
            if(m1 instanceof Date && m2 instanceof Date) {
                if(m1.getFullYear() === m2.getFullYear() && m1.getMonth() === m2.getMonth() && m1.getDate() === m2.getDate() ) {
                    return true;
                }
            }
            if(Array.isArray(m1) && Array.isArray(m2)) {return this.isEqualArray(m1,m2);}
            return m1 === m2;
        },

        /*
        ~  CONVERTERS
        ~  'ymd': fixed format that used on default date format in this component 'YYYY-MM-DD'
        ~  'input': string used in text-field. only have Numbers.
        ~  'model': Date or Array or some formatted string which is set as props.modelType.
        ~           It is used as type of v-model in single date-picker.
        ~           In case of using range or strictRange, v-model will be [modelType, modelType]
        ~
        ~  inputToYmd(input)
        ~  ymdToInput(ymd)
        ~  textToYmd(text, textFormat)
        ~  ymdToText(ymd, textFormat)
        ~  changeTextFormat(text, fromFormat, toFormat)
        ~  ymdToModel(ymd)
        ~  ModelToYmd(model)
        ~  dateToYmd(date)
        ~  ymdToDate(ymd, dy, dm, dd): dy, dm, dd is difference of year, month, date. default is 0.
        ~                              eg.) ymdToDate('1991-02-04', 1, -1, 3) => new Date(1992, 0, 7) [*2nd arg 0 is Jan.]
        */

        // @vuese
        // $ver: v0.1.2
        // $arg: target data to convert
        // $arg: target data's format string (eg. YYYY-MM-DD)
        // $arg: return data's format string (eg. DD/MM/YYYY)
        // $return: converted data
        // <em>arg1</em>의 format을 가진 <em>arg0</em>값을 <em>arg2</em>의 format에 맞게 변환하여 반환합니다.
        // #Converts <em>arg0</em> with the format of <em>arg1</em> to match the format of <em>arg2</em> and returns.
        changeTextFormat(data, fromFormat, toFormat) {
            if(fromFormat === toFormat) {
                return data;
            }
            let tmp = this.textToYmd(data, fromFormat);
            return this.ymdToText(tmp, toFormat);
        },
        inputToYmd(input){
            if(!input || typeof(input) !== 'string') {return '';}
            let inputFormat = this.inputType.replace(/[^ymd]/gi,'').toUpperCase();
            let sIdx = inputFormat.indexOf('Y');
            let y4Flag = inputFormat.indexOf('YYYY') !== -1;
            let YYYY, tmp;
            if(input.length === 4) {
                // no YYYY or YY
                YYYY = this.today.split('-')[0];
                if(y4Flag) {
                    tmp = input.slice(0,sIdx) + YYYY + input.slice(sIdx);
                } else {
                    tmp = input.slice(0,sIdx) + YYYY.slice(2) + input.slice(sIdx);
                }
            } else if(input.length === 6) {
                // YY
                if(y4Flag) {
                    YYYY = input.slice(sIdx,sIdx+2);
                    YYYY = parseInt(YYYY)<70?'20'+YYYY:'19'+YYYY;
                    tmp = input.slice(0,sIdx) + YYYY + input.slice(sIdx+2);
                } else {
                    tmp = input;
                }
            } else if(input.length === 8) {
                // YYYY
                if(y4Flag) {
                    tmp = input;
                } else {
                    YYYY = input.slice(sIdx, sIdx+4);
                    tmp = input.slice(0,sIdx) + YYYY.slice(2) + input.slice(sIdx+4);
                }
            } else {
                return '';
            }
            return this.textToYmd(tmp, inputFormat);
        },
        ymdToInput(ymd) {
            return this.ymdToText(ymd, this.inputType.replace(/[^ymd]/gi,''));
        },
        textToYmd(val, textFormat) {
            let tmp, rtn;
            // valid val?
            if(!val || typeof(val) !== 'string') {return '';}
            // valid textFormat?
            if(!/^(?=.*yy)(?=.*mm)(?=.*dd)(yy|mm|dd|\W)+$/i.test(textFormat)
                || textFormat.match(/y{1,4}/gi).length !== 1
                || textFormat.match(/m{1,2}/gi).length !== 1
                || textFormat.match(/d{1,2}/gi).length !== 1) {
                console.error('[LEGO-DATE-PICKER] invalid text format is given: '+textFormat);
                return '';
            }
            // val is fit on textFormat?
            if(!(new RegExp(textFormat.replace(/[ymd]/gi,'\\d')).test(val))) {return '';}

            let YYYY, MM, DD;
            textFormat = textFormat.replace(/y{4}/i,'(?<year>\\d\\d\\d\\d)');
            textFormat = textFormat.replace(/y{2}/i,'(?<year>\\d\\d)');
            textFormat = textFormat.replace(/m{2}/i,'(?<month>\\d\\d)');
            textFormat = textFormat.replace(/d{2}/i,'(?<date>\\d\\d)');
            tmp = val.match(new RegExp(textFormat)).groups;
            YYYY = tmp.year;
            MM = tmp.month;
            DD = tmp.date;
            if(YYYY.length === 2) {
                if(parseInt(YYYY)<70) {
                    YYYY = '20'+YYYY;
                } else {
                    YYYY = '19'+YYYY;
                }
            }
            rtn = [YYYY,MM,DD].join('-');
            return /^(19[7-9][0-9]|[2-9][0-9]{3})-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/.test(rtn)?rtn:'';
        },
        ymdToText(val, textFormat) {
            let tmp, rtn;
            // valid val?
            if(!val || typeof(val) !== 'string') {return '';}
            tmp = val.split('-');
            if(tmp.length !== 3) {return '';}
            // valid textFormat?
            if(!/^(?=.*yy)(?=.*mm)(?=.*dd)(yy|mm|dd|\W)+$/i.test(textFormat)
                || textFormat.match(/y{1,4}/gi).length !== 1
                || textFormat.match(/m{1,2}/gi).length !== 1
                || textFormat.match(/d{1,2}/gi).length !== 1) {
                console.error('[LEGO-DATE-PICKER] invalid text format is given: '+textFormat);
                return '';
            }
            rtn = textFormat.toUpperCase();
            rtn = rtn.replace('YYYY',tmp[0]);
            rtn = rtn.replace('YY', tmp[0].slice(2));
            rtn = rtn.replace('MM', tmp[1]);
            rtn = rtn.replace('DD', tmp[2]);
            return rtn;
        },
        // @vuese
        // $ver: v0.1.2
        // $arg: target data to convert (format is YYYY-MM-DD)
        // $return: converted data
        // 입력값을 <em>lego-date-picker</em>에 설정된 model-type에 맞게 변환합니다.
        // 입력값은 YYYY-MM-DD의 format으로 주어져야 합니다.
        // #Convert the input to match the model-type set in the <em>lego-date-picker</em>.
        // #Input must be given in the format of YYYY-MM-DD.
        ymdToModel(val) {
            // from YYYY-MM-DD to v-model value
            let tmp, rtn;
            if(!val || typeof(val) !== 'string') {return '';}
            tmp = val.split('-');
            if(tmp.length !== 3) {return '';}
            if(/^date$/i.test(this.modelType)) {
                return new Date(parseInt(tmp[0]), parseInt(tmp[1])-1);
            }
            if(/^array$/i.test(this.modelType)) {
                return val.split('-');
            }
            return this.ymdToText(val, this.modelType);
        },
        // @vuese
        // $ver: v0.1.2
        // $arg: target data to convert (format is same as model-type)
        // $return: converted data (YYYY-MM-DD)
        // 입력값을 YYYY-MM-DD format의 문자열로 변환하여 반환합니다.
        // 입력값은 <em>lego-date-picker</em>의 model-type과 같은 형식으로 주어져야합니다.
        // #Convert the input to a string in YYYY-MM-DD format and return it.
        // #The input should be given in the same format as the model-type of the <em>lego-date-picker</em>.
        modelToYmd(val) {
            // from v-model value to YYYY-MM-DD
            let rtn;
            if(!val || typeof (val) !== 'string') {return '';}
            if(/^date$/i.test(this.modelType)) {
                // model type = date object
                return this.dateToYmd(val);
            }
            if(/^array$/i.test(this.modelType)) {
                // model type = array [YYYY,MM,DD]
                if( !( Array.isArray(val) && val.length === 3 ) ) {return '';}
                rtn = [];
                // year
                let ymd = parseInt(val[0]);
                if(isNaN(ymd)) {return '';}
                if(ymd < 70) {
                    rtn.push('20'+ymd);
                } else if (ymd < 100) {
                    rtn.push('19'+ymd);
                } else if (ymd < 1970 || ymd > 9999) {
                    return '';
                }
                // month
                ymd = parseInt(val[1]);
                if(isNaN(ymd) || ymd<=0 || ymd>12) {return '';}
                if(ymd<10) {rtn.push('0'+ymd);}
                else {rtn.push(''+ymd);}
                // date
                ymd = parseInt(val[2]);
                if(isNaN(ymd) || ymd<=0 || ymd>31) {return '';}
                if(ymd<10) {rtn.push('0'+ymd);}
                else {rtn.push(''+ymd);}

                rtn = rtn.join('-');
                return /^(19[7-9][0-9]|[2-9][0-9]{3})-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/.test(rtn)?rtn:'';
            }
            return this.textToYmd(val,this.modelType);
        },
        // @vuese
        // $ver: v0.1.2
        // $arg: target data to convert (javascript Date object)
        // $return: converted data (YYYY-MM-DD)
        // javascript Date object를 입력값으로 주면 YYYY-MM-DD 형식의 문자열로 변환하여 반환합니다.
        // #If a javascript Date object is given as input, it is converted to a string in YYYY-MM-DD format and returned.
        dateToYmd(date) {
            if(!(date instanceof Date)) {return '';}
            let YYYY = date.getFullYear();
            let MM = date.getMonth() + 1;
            MM = MM < 10 ? '0'+MM:MM;
            let DD = date.getDate();
            DD = DD < 10 ? '0'+DD:DD;
            return [YYYY,MM,DD].join('-');
        },
        ymdToDate(ymd,dy=0,dm=0,dd=0) {
            let tmp = ymd.split('-');
            return new Date(parseInt(tmp[0]) + dy,parseInt(tmp[1]) - 1 + dm,parseInt(tmp[2]) + dd);
        },
        /*
        * EVENT HANDLERS
        * */
        onClickSegment(str) {
            this.presetName = str;
            let tmp, dy=0,dm=0,dd=0;
            if(this.$_isRange) {
                switch(str) {
                    case 'today':
                        this.presetVal = [this.today, this.today];
                        tmp = [this.ymdToModel(this.presetVal[0]), this.ymdToModel((this.presetVal[1]))];
                        if (!this.isEqualArray(this.value, tmp)) this.$emit('input', tmp);
                        return;
                    case 'clear':
                        this.presetVal = ['', ''];
                        this.$emit('input', ['', '']);
                        return;
                    default:
                        break;
                }
                if (!/^(day|week|month|year)[+-][0-9]+$/.test(str)) {
                    // else = 'none' : do nothing
                    return;
                }
                tmp = str.split(/(?=[+-])/);
                switch (tmp[0]) {
                    case 'day':
                        dd = parseInt(tmp[1]);
                        break;
                    case 'week':
                        dd = parseInt(tmp[1]) * 7;
                        break;
                    case 'month':
                        dm = parseInt(tmp[1]);
                        break;
                    case 'year':
                        dy = parseInt(tmp[1]);
                        break;
                }
                if (parseInt(tmp[1]) > 0) {
                    this.presetVal = [this.today, this.dateToYmd(this.ymdToDate(this.today, dy, dm, dd))];
                } else {
                    this.presetVal = [this.dateToYmd(this.ymdToDate(this.today, dy, dm, dd)), this.today];
                }
                tmp = [this.ymdToModel(this.presetVal[0]), this.ymdToModel((this.presetVal[1]))];
                if (!this.isEqualArray(this.value, tmp)) this.$emit('input', tmp);
                return;
            }
            // else
            switch(str) {
                case 'today':
                    this.presetVal = this.today;
                    tmp = this.ymdToModel(this.presetVal);
                    if (!this.isEqualModel(this.value, tmp)) this.$emit('input', tmp);
                    return;
                case 'clear':
                    this.presetVal = '';
                    this.$emit('input', '');
                    return;
                default:
                    break;
            }
            if (!/^(day|week|month|year)[+-][0-9]+$/.test(str)) {
                // else = 'none' : do nothing
                return;
            }
            tmp = str.split(/(?=[+-])/);
            switch(tmp[0]) {
                case 'day':
                    dd = parseInt(tmp[1]);
                    break;
                case 'week':
                    dd = parseInt(tmp[1]) * 7;
                    break;
                case 'month':
                    dm = parseInt(tmp[1]);
                    break;
                case 'year':
                    dy = parseInt(tmp[1]);
                    break;
            }
            this.presetVal = this.dateToYmd(this.ymdToDate(this.today,dy,dm,dd));
            tmp = this.ymdToModel(this.presetVal);
            if(!this.isEqualModel(this.value,tmp)) this.$emit('input',tmp);
        },
        onFocus(idx) {
            if(idx === 2 && this.strictRange && !this.from.selected) {
                this.$refs['from-text'].focus();return;
            }
            this.showFlag = idx;
        },
        onClickIcon(idx) {
            this.showFlag = this.showFlag === idx ? 0 : idx;
        },
        onUpdate(idx, tabEvent = DUMMY_EVENT) {
            if(tabEvent.shiftKey) {this.showFlag=0;return;}
            // textInput is updated
            let tmp, rtn = ['', ''], newValue;
            if(this.$_isRange && idx === 1) {
                // range date picker && on update 'from' text
                newValue = this.inputToYmd(this.from.textInput);
                newValue = this.toValidYmd(newValue);
                if (newValue !== '') {
                    // proper input received
                    this.from.textInput = this.ymdToInput(newValue);
                    this.from.selected = newValue;
                    tmp = this.from.selected.split('-');
                    this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
                    this.$refs['to-text'].focus();
                    tabEvent.preventDefault();
                    return;
                }
                if (this.from.textInput) {
                    // intend to input some date text but not valid -> restore text same as actualDate
                    this.from.textInput = this.ymdToInput(this.from.actualDate);
                    tabEvent.preventDefault();
                    return;
                }
                if (!this.strictRange) {
                    // empty input but want to enter 'to' date first. (only when strictRange false)
                    // strictRange true -> not allow to input 'to' date before 'from' date confirmed.
                    this.from.selected = '';
                    this.$refs['to-text'].focus();
                    tabEvent.preventDefault();
                    return;
                }
                // strictRange true
                if (!this.isEqualArray(rtn, [this.from.selected, this.to.selected])) {
                    // when strictRange true, empty input make selected date clear.
                    this.from.selected = '';
                    this.to.selected = '';
                    tabEvent.preventDefault();
                    return;
                }
                // already clear, update v-model & close calendar
                this.onConfirm();return; // not execute e.preventDefault
            }
            if(!this.$_isRange) {
                // single date picker
                newValue = this.inputToYmd(this.from.textInput);
                newValue = this.toValidYmd(newValue);
                if(newValue !== '') {
                    // proper input received
                    if(newValue !== this.from.selected) {
                        // change selected date same as input
                        this.from.textInput = this.ymdToInput(newValue);
                        this.from.selected = newValue;
                        tmp = this.from.selected.split('-');
                        this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
                        tabEvent.preventDefault();return;
                    }
                    // if selected date is already set, update v-model & close calendar
                    this.onConfirm();return; // not execute e.preventDefault
                } else if(this.from.textInput) {
                    // intend to input some date text but not valid -> restore text same as actualDate
                    this.from.textInput = this.ymdToInput(this.from.actualDate);
                    tabEvent.preventDefault();return;
                } else if(this.from.selected) {
                    // empty input
                    this.from.selected = '';
                    tabEvent.preventDefault();return;
                }
                // already clear, update v-model & close calendar
                this.onConfirm();return; // not execute e.preventDefault
            }
            // idx = 2
            // range date picker && on update 'to' text
            newValue = this.inputToYmd(this.to.textInput);
            newValue = this.toValidYmd(newValue);
            if(newValue !== '' && this.strictRange) {
                // proper input received & strictRange true
                if (!this.from.selected) {
                    // strictRange true -> not allow to input 'to' date before 'from' date confirmed.
                    this.$refs['from-text'].focus();
                    tabEvent.preventDefault();return;
                }
                if (this.from.selected > newValue) {
                    // 'to' date input is earlier than 'from' date -> update 'from' date as received input.
                    this.from.textInput = this.ymdToInput(newValue);
                    this.from.selected = newValue;
                    tmp = this.from.selected.split('-');

                    this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
                    this.to.textInput = '';
                    this.to.selected = '';
                    tabEvent.preventDefault();return;
                }
                if (newValue !== this.to.selected) {
                    // update selected 'to' date as received input.
                    this.to.textInput = this.ymdToInput(newValue);
                    this.to.selected = newValue;
                    tmp = this.to.selected.split('-');

                    if (!this.isEqualArray(this.calendarMonth, [parseInt(tmp[0]), parseInt(tmp[1])])) {
                        tmp = this.dateToYmd(this.ymdToDate(this.to.selected, 0, -1, 0)).split('-');
                        this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
                    }
                    tabEvent.preventDefault();return;
                }
                // selected date already updated, update v-model & close calendar
                this.onConfirm();return; // not execute e.preventDefault
            } else if(newValue !== '' && newValue !== this.to.selected) {
                // proper input received & strictRange false -> make selected 'to' date as received input
                this.to.textInput = this.ymdToInput(newValue);
                this.to.selected = newValue;
                tmp = this.to.selected.split('-');
                if(!this.isEqualArray(this.calendarMonth,[parseInt(tmp[0]),parseInt(tmp[1])])) {
                    tmp = this.dateToYmd(this.ymdToDate(this.to.selected,0,-1,0)).split('-');
                    this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
                }
                tabEvent.preventDefault();return;
            } else if(newValue !== '') {
                // proper input received & strictRange false & selected 'to' date already updated
                // -> update v-model & close calendar
                this.onConfirm();return; // not execute e.preventDefault
            } else if(this.to.textInput) {
                // intend to input some date text but not valid -> restore text same as actualDate
                this.to.textInput = this.ymdToInput(this.to.actualDate);
                tabEvent.preventDefault();return;
            } else if(this.strictRange || this.to.selected) {
                // empty input recieved -> clear selected 'to' date
                this.to.selected = '';
                tabEvent.preventDefault();return;
            }
            // selected 'to' date already cleared & strictRange is false -> update v-model & close calendar
            this.onConfirm(); // not execute e.preventDefault
        },
        onClickDate(date) {
            if(date.state === 'prev') {
                this.onClickPrevMonth(this.showFlag);
            } else if (date.state === 'next') {
                this.onClickNextMonth(this.showFlag);
            }
            if(this.showFlag === 1) {
                this.from.textInput = this.ymdToInput(date.value);
                this.from.selected = date.value;
                if(this.$_isRange) {
                    this.showFlag=2;
                }
            } else if(this.showFlag === 2){
                if(this.from.selected) {
                    if(date.value < this.from.selected) {
                        this.from.textInput = this.ymdToInput(date.value);
                        this.from.selected = date.value;
                    } else {
                        this.to.textInput = this.ymdToInput(date.value);
                        this.to.selected = date.value;
                    }
                } else if(this.to.selected) {
                    if(this.to.selected < date.value) {
                        this.to.textInput = this.ymdToInput(date.value);
                        this.to.selected = date.value;
                    } else {
                        this.from.textInput = this.ymdToInput(date.value);
                        this.from.selected = date.value;
                    }
                } else {
                    this.to.textInput = this.ymdToInput(date.value);
                    this.to.selected = date.value;
                }
            }
        },
        onConfirm(e) {
            // selected confirmed and want to be update v-model & actual date
            // close calendar
            let rtn;
            if(this.$_isRange) {
                rtn = [this.ymdToModel(this.from.selected), this.ymdToModel(this.to.selected)];
                if(!this.isEqualArray(this.value,rtn)){this.$emit('input',rtn);this.validateFlag=true;}
                else {this.validateOnEvent();}
            } else {
                rtn = this.ymdToModel(this.from.selected);
                if(!this.isEqualModel(this.value, rtn)){this.$emit('input',rtn);this.validateFlag=true;}
                else {this.validateOnEvent();}
            }
            this.showFlag = 0;
        },
        onClickToday(e) {
            // update currTime & today
            this.currTime = new Date();
            this.today = this.dateToYmd(this.currTime);
            // change selected
            let date = this.today > this.maxDate?this.maxDate:this.today<this.minDate?this.minDate:this.today;
            this.onClickDate({
                value: date
            });
            let tmp = date.split('-');
            if(!this.isEqualArray(this.calendarMonth, [parseInt(tmp[0]),parseInt(tmp[1])])) {
                tmp =this.dateToYmd(this.ymdToDate(date,0,-1,0)).split('-');
                if(!this.isEqualArray(this.calendarMonth, [parseInt(tmp[0]),parseInt(tmp[1])])) {
                    if(this.to.selected === date) {
                        this.setCalendarMonth([tmp[0],tmp[1]]);
                    } else {
                        tmp = date.split('-');
                        this.setCalendarMonth([tmp[0],tmp[1]]);
                    }
                }
            }
        },
        onClickPrevMonth(idx) {
            this.setCalendarMonth([parseInt(this.calendarMonth[0]),parseInt(this.calendarMonth[1]) - 1]);
        },
        onClickNextMonth(idx) {
            this.setCalendarMonth([parseInt(this.calendarMonth[0]),parseInt(this.calendarMonth[1]) + 1]);
        },
        onClickOutside(e) {
            // set selected back to original value
            // close calendar
            let tmp;
            if(this.$_isRange) {
                this.from.textInput = this.ymdToInput(this.from.actualDate);
                this.from.selected = this.from.actualDate;
                this.to.textInput = this.ymdToInput(this.to.actualDate);
                this.to.selected = this.from.actualDate;

                if(this.to.actualDate) {
                    tmp = this.to.actualDate.split('-');
                    tmp[1] = parseInt(tmp[1]) - 1;
                } else if(this.from.actualDate) {
                    tmp = this.from.actualDate.split('-');
                } else {
                    tmp = this.today.split('-');
                }
                this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
            } else {
                this.from.textInput = this.ymdToInput(this.from.actualDate);
                this.from.selected = this.from.actualDate;
                if(this.from.actualDate) {
                    tmp = this.from.actualDate.split('-');
                } else {
                    tmp = this.today.split('-');
                }
                this.setCalendarMonth([parseInt(tmp[0]), parseInt(tmp[1])]);
            }
            this.showFlag=0;
        },

        /*
        * ACT LIKE COMPUTED but need some argument from template side
        * */
        monthFilter(month,flag) {
            let m = parseInt(month[1])-2+flag;
            let y = parseInt(month[0]);
            if(m < 0 ) {
                m = m + 12;
                y = y - 1;
            } else if (m>11) {
                m = m - 12;
                y = y + 1;
            }
            m = m < 0 ? m+12 : m > 11 ? m-12 : m;
            return this.monthAbbr[m] + ' ' + y;
        },
        makePrevDate(calendarMonth, flag) {
            let arr = [];
            // prev month's last few days
            let selMon = new Date(calendarMonth[0],calendarMonth[1]-2+flag);
            let idx = selMon.getDay();
            for(let i = 1 - idx;i < 1;i++) {
                let tmp = new Date(calendarMonth[0],calendarMonth[1]-2+flag,i);
                let value = this.dateToYmd(tmp);
                let state = 'prev',rangeColor=[];
                if(value < this.minDate) {state = 'disabled';}
                if(this.maxDate < value) {state = 'disabled';}
                if(this.showFlag===2) {
                    if(flag ===2) {
                        state = 'invisible';
                    } else {
                        rangeColor = this.makeRangeColor(value,this.from.selected, this.to.selected, this.hoverDate);
                    }
                }
                arr.push({
                    text: tmp.getDate(),
                    value: value,
                    state: state,
                    rangeColor:rangeColor
                });
            }
            return [arr, idx];
        },
        makeCurrDate(calendarMonth, flag, arr, idx) {
            let rtn = [] ;
            // curr month's full days
            let tmp = this.dateToYmd(new Date(calendarMonth[0],calendarMonth[1]-2+flag)).slice(0,8);
            let maxDate = (new Date(calendarMonth[0],calendarMonth[1]-1+flag) - new Date(calendarMonth[0],calendarMonth[1]-2+flag)) / 24 / 60 / 60 / 1000;
            for(let i = 1; i <= maxDate; i++) {
                let value = tmp + (i<10?'0'+i:i);
                let state = false,rangeColor=[];
                if(value < this.minDate) {state = 'disabled';}
                if(this.maxDate < value) {state = 'disabled';}
                if(this.showFlag===2) {
                    rangeColor = this.makeRangeColor(value,this.from.selected, this.to.selected, this.hoverDate);
                }
                arr.push({
                    text: i,
                    value: value,
                    state: state,
                    rangeColor:rangeColor
                });
                if(idx === 6) {
                    idx = 0;
                    rtn.push(arr);
                    arr = [];
                } else {
                    idx++;
                }
            }
            return [rtn, arr, idx];
        },
        makeNextDate(calendarMonth, flag, rtn, arr, idx) {
            // next month's first few days
            for(let i = idx; i<=6; i++) {
                let tmp = new Date(calendarMonth[0],calendarMonth[1]-1+flag,i-idx+1);
                let value = this.dateToYmd(tmp);
                let state = 'next',rangeColor=[];
                if(value < this.minDate) {state = 'disabled';}
                if(this.maxDate < value) {state = 'disabled';}
                if(this.showFlag===2 ) {
                    if(flag ===1) {
                        state = 'invisible';
                    } else {
                        rangeColor = this.makeRangeColor(value,this.from.selected, this.to.selected, this.hoverDate);
                    }
                }
                arr.push({
                    text: tmp.getDate(),
                    value: value,
                    state: state,
                    rangeColor: rangeColor
                });
            }
            rtn.push(arr);
            return rtn;
        },
        monthCalendar(calendarMonth,flag) {
            let rtn = [], arr = [], tmp;
            let idx;

            tmp = this.makePrevDate(calendarMonth, flag);
            idx = tmp[1];
            arr = tmp[0];

            tmp = this.makeCurrDate(calendarMonth, flag, arr, idx);
            rtn = tmp[0];
            arr = tmp[1];
            idx = tmp[2];
            if(idx === 0 ){
                return rtn;
            }
            rtn = this.makeNextDate(calendarMonth, flag, rtn, arr, idx);
            return rtn;
        },
        makeRangeColor(val, frm, to, hov){
            let ss=false,se=false,hs=false,he=false;
            // select color
            if(frm && to && frm<to) {
                // from ~ to
                if(frm<val && val<to) {ss=true;se=true;}
                if(frm===val) {ss=true;}
                if(val===to) {se=true;}
            }
            // hover color
            if(hov) {
                if(frm) {
                    if(hov<frm && to) {
                        // hover ~ from
                        if(hov<val && val<frm) {hs=true;he=true;}
                        if(hov===val) {hs=true;}
                        if(val===frm) {he=true;}
                    }else if(frm<hov && !to){
                        // from ~ hover
                        if(frm<val && val<hov) {hs=true;he=true;}
                        if(frm===val) {hs=true;}
                        if(val===hov) {he=true;}
                    }
                }
                if(to) {
                    if(to<hov && frm) {
                        // to ~ hover
                        if(to<val && val<hov) {hs=true;he=true;}
                        if(to===val) {hs=true;}
                        if(val===hov) {he=true;}
                    } else if(hov<to && !frm) {
                        // hover ~ to
                        if(hov<val && val<to) {hs=true;he=true;}
                        if(hov===val) {hs=true;}
                        if(val===to) {he=true;}
                    }
                }
                if(frm&&to) {
                    if(frm<=hov && hov<to) {
                        // hover ~ to
                        if(hov<val && val<to) {hs=true;he=true;}
                        if(hov===val) {hs=true;}
                        if(val===to) {he=true;}
                    }
                }
            }

            let rtn = [];
            if(hs&&he) {
                rtn.push('hover-between');
            } else if(hs) {
                rtn.push('hover-start');
            } else if(he){
                rtn.push('hover-end');
            }
            if(ss&&se) {
                rtn.push('select-between');
            } else if(ss) {
                rtn.push('select-start');
            } else if(se) {
                rtn.push('select-end');
            }
            return rtn;
        },
        dateClass(date, dIdx) {
            let rtn = [];
            rtn.push('lego-date-picker__calendar__date');
            if(date.value === this.today) rtn.push('lego-date-picker__calendar__date--today');
            if(date.value === this.from.selected || date.value === this.to.selected) rtn.push('lego-date-picker__calendar__date--selected');
            if(date.value === this.hoverDate) rtn.push('lego-date-picker__calendar__date--hover');
            if(date.state === 'disabled') rtn.push('lego-date-picker__calendar__date--disabled');
            if(date.state === 'invisible') rtn.push('lego-date-picker__calendar__date--invisible');
            else if(date.state) rtn.push('lego-date-picker__calendar__date--other-month');
            rtn.push(this.weekDayClass(dIdx));
            return rtn;
        },
        weekDayClass(idx) {
            if(idx === this.sundayIdx) return 'lego-date-picker__calendar__date--sunday';
            if(idx === this.saturdayIdx) return 'lego-date-picker__calendar__date--saturday';
            return '';
        }
    },
    provide() {
        let rtn = {};
        let odf = Object.defineProperty;
        let legoInput = {};
        odf(legoInput, 'size', {get: ()=>this.$_size});
        rtn['legoInput'] = legoInput;
        return rtn;
    },
    directives:  {
        'picker-click-outside': {
            inserted(el,binding, vnode) {
                const handler = (e) => {
                    if (!(el.contains(e.target) || el === e.target)) {
                        binding.value(e)
                    }
                };
                el.__vueClickOutside__ = handler;
                document.body.addEventListener('click', el.__vueClickOutside__);
            },
            unbind(el,binding,vnode) {
                document.body.removeEventListener('click', el.__vueClickOutside__);
                delete el.__vueClickOutside__;
            }
        }
    }
}
</script>
