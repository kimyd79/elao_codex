import legoDatePicker from "./legoDatePicker.vue";
export default {
    install(Vue){
        Vue.component(legoDatePicker.name, legoDatePicker);
    }
};