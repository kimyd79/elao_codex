<template>
    <div class="lego-table" ref="legoTableRef">

        <!-- Table Title -->
        <div class="lego-table__title" v-if="title">
            <label class="lego-table__title__label">{{title}}</label>
            <span class="lego-table__title__desc">{{titleDesc}}</span>
            <div class="lego-table__title__action"><!--
                $ver: v0.1.0
                테이블 제목 우측에 위치하는 영역입니다. title 속성으로 테이블의 제목을 표시할 때 사용할 수 있습니다.
                #The area located to the right of the table title. You can use it to display the title of a table with the title attribute.
            --> <slot name="title-action"/>
            </div>
        </div>
        <!-- Table Control -->
        <div class="lego-table__control" v-if="!noControl" :class="controlClass">
            <div class="lego-table__counter"><!--
                $ver: v0.1.0
                총 항목 수, 페이지 당 항목 수를 보여주는 영역입니다. 다른 컨텐츠로 대체할 수 있습니다.
                #This area shows the total number of items and the number of items per page. You can replace it with other content.
            --> <slot name="counter-instead">
                    <span class="lego-table__counter__total">{{$_totalText}} <b>{{pagination.totalItems}}</b></span>
                    <lego-dropdown v-if="!noPage" class="lego-table__counter__per-page left-divider"
                                   @input="v=>{$emit('change',v);}" :items="$_perPageItems"
                                   :height="26" v-model="rowPerPage">
                        <template v-slot:itemText="itemTextScope">
                            <b>{{itemTextScope.item && itemTextScope.item.text}}</b> {{$_perPageText}}
                        </template>
                    </lego-dropdown>
                </slot>
            </div>
            <div class="lego-table__action">
                <div class="lego-table__action-selected" v-if="isActionSelect">
                    <span>{{selected.length}} items selected</span>
                </div><!--
                $ver: v0.1.0
                테이블 우측 상단에 위치하는 영역입니다. 일반적으로 테이블의 추가, 수정, 삭제에 대한 버튼이 위치합니다.
                #This area is in the upper right corner of the table. In general, there are buttons for adding, modifying, and deleting tables.
            --> <slot name="action"></slot>
            </div>
            <div class="lego-table__extra-action" v-if="$scopedSlots['extra-action']"><!--
                $ver: v0.1.1
                테이블 우측 상단에 위치하는 영역입니다. action 영역에 추가로 영역이 더 필요할 경우 사용합니다.
                #This area is in the upper right corner of the table. Use if you need more areas in addition to the action area.
            --> <slot name="extra-action"/>
            </div>
        </div>
        
        <!-- Table -->
        <table class="lego-table__area"
                @mousemove="headerDragOver" @dragover="headerDragOver"
                @mouseup  ="headerDragEnd"  @dragend ="headerDragEnd">
            <colgroup><!--
                $ver: v0.1.0
                table 태그 아래 colgroup 태그 영역입니다. 기본적으로 전체 체크, 각 컬럼의 헤더에 맞춰서 생성됩니다.
                #The colgroup tag area below the table tag. By default, all checks are made to match the header of each column.
            --> <slot name="colgroup">
                    <col v-if="selectAll" :width="selectAllWidth + 'px'"/>
                    <col v-for="(header, hIdx) in dumpHeaders" :width="header.width" :class="header.displayFrom?'lego-table__col__from-'+header.displayFrom:''" :key="hIdx"/>
                </slot>
            </colgroup>
            <!-- Header -->
            <thead class="lego-table__header"><!--
                $ver: v0.1.0
                table 태그 아래 thead 태그 영역입니다. 기본적으로 자동 생성되나, customHeader 속성으로 tr/th 태그로 커스텀 할 수 있습니다.
                #Thead tag area below the table tag. It is automatically created by default, but can be customized with the tr / th tag with the customHeader attribute.
            --> <slot v-if="customHeader" name="header"></slot>
                <tr class="lego-table__header__row" v-else :style="{'height': headerHeight + 'px'}"
                        ><!-- @mouseleave="headerMouseLeave" -->
                    <th v-if="selectAll" class="lego-table__header-checker">
                        <lego-checkbox small :checked="selectAllChecked" :checked-icon="selectAllCheckedIcon" @click="clickSelectAll"/>
                    </th>
                    <th v-for="(header, hIdx) in dumpHeaders" :key="hIdx" :style=thStyle(header)
                        :class="header.displayFrom?'lego-table__col__from-'+header.displayFrom:''">
                        <span :style="{'line-height' : headerContentHeight}">
                            {{header.text}}
                            <lego-icon v-if="header.sortable" class="lego-table__icon-sort" icon="sort" type="picto"
                                       :class="{'lego-table__icon-sort--selected' : (sortIdx == hIdx)}"
                                       :style="sortIconStyle(hIdx)" @click.stop="sortIconClick(hIdx)"/>
                            <lego-icon v-if="header.filterable" class="lego-table__icon-filter" icon="filter" type="picto"
                                       @click.stop="filterIconClick(hIdx)"/>
                        </span>
                        <lego-icon-wrapper class="lego-table__hidden-icon" >
                            <lego-icon icon-size="16px" icon="change_width" style="cursor:pointer;" @click="header.displayFrom=''"/>
                        </lego-icon-wrapper>
                        <div class="lego-table__header-resize" v-if="resizeColumn" :style="headerResizeBoxStyle(hIdx)"
                             @dragstart="headerDragStart(hIdx, $event)" @mousedown="headerDragStart(hIdx, $event)"/>
                    </th>
                </tr>
                <tr style="height:0px !important;min-height:0px !important"><!--  -->
                    <td class="lego-table__header__resizer-td"><div v-if="resizeColumn" v-show="toggleResize" class="lego-table__resize-line" :style="resizeLineStyle"/></td>
                </tr>
            </thead>
            <!-- Body -->
            <tbody class="lego-table__body">
                <tr v-if="(singleSelect && (multiSelect || selectAll))" class="lego-table__body__alert">
                    <td :colspan="alertColspan">You can't use 'singleSelect prop' with multiSelect or selectAll prop</td>
                </tr>
                <tr v-else-if="items.length === 0" class="lego-table__body__no-data">
                    <td :colspan="alertColspan">{{$_noDataText}}</td>
                </tr>
                <template v-else v-for="(item, iIdx) in items" >
                    <tr :key="item.id+'_'+iIdx" @click="onClickRow(item)" :style="{'height': tableRowHeight}"
                        :id="item.id+'_'+iIdx" :class="{ 'lego-table__selected': isSelected(item), 'sortableRow': rowSortable, 'lego-table__sorted': item.flag==='E' }"><!--
                        $ver: v0.1.0
                        각 Row 영역입니다. 기본적으로 입력된 데이터에 따라 자동생성되나, <td> 태그를 활용하여 커스텀 할 수 있습니다.
                        #Each Row area. By default, it is automatically generated based on the data entered, but can be customized using the <td> tag.
                    --> <slot name="items" :item="item">
                            <!-- Default Cell -->
                            <td v-if="multiSelect" class="lego-table__cell-checker">
                                <!-- 191202 backup <lego-checkbox small v-model="value" :value="item"/> -->
                                <lego-checkbox small :checked="selected" @input="onClickRow(item)" :value="item"/>
                            </td>
                            <td v-if="singleSelect" class="lego-table__cell-checker">
                                <lego-checkbox small @input="(v)=>{$emit('input',v)}" :checked="value" :value="item"/>
                            </td>
                            <template v-for="(header, hIdx) in dumpHeaders">
                                <td v-if="!header.checker"
                                    :class="header.displayFrom?'lego-table__col__from-'+header.displayFrom:''" :key="item.id+'_'+iIdx+'_'+hIdx">
                                    {{item[header.value]}}
                                    <lego-icon-wrapper class="lego-table__hidden-icon">
                                        <lego-icon icon-size="16px" icon="more"/>
                                    </lego-icon-wrapper>
                                </td>
                            </template>
                            <!-- Default Cell END -->
                        </slot>
                    </tr>
                    <tr v-if="item.expand" :key="item.id+'_'+iIdx+'_expand'">
                        <td :colspan="alertColspan" class="lego-table__cell--expand"><!--
                            $ver: v0.1.0
                            각 Row 가 펼침/닫힘 처리가 가능할 경우, 펼쳐지는 부분에 대한 컨텐츠 영역 입니다.
                            #If each row can be expanded / closed, this is the content area for the expanded part.
                        --> <slot name="expand" :item="item"/>
                        </td>
                    </tr>
                </template>
                
            </tbody>
        </table>
    </div>
</template>

<script>

    export default {
        name: 'legoTable',
        props: {
            // $ver: v0.1.0
            // 테이블 내 표시할 항목 배열 입니다. 각 항목의 속성은 headers 배열의 value 속성 값과 일치되어야 합니다.
            // #An array of items to display within the table. Each item's attributes must match the value of the value attribute in the headers array.
            items       : [Array, Object],

            // $ver: v0.1.0
            // 항목의 각 컬럼에 대한 배열 정보 입니다. items 배열 내 속성들의 key와 같은 값으로 value가 입력되어야 합니다.
            // 화면에 표시될 명칭은 text 속성으로 지정합니다. ([{value:key1, text:headerText1},{value:key2, text:headerText2},...])
            // #Array information for each column of the item. value must be entered with the same value as the key for the attributes in the items array.
            // #The name to be displayed on the screen is specified by the text attribute. ([{value: key1, text: headerText1}, {value: key2, text: headerText2}, ...])
            headers     : {type: [Array, Object]},

            // $ver: v0.1.0
            // 커스텀헤더를 사용합니다. header 슬롯 내에 tr, th 태그를 활용하여 구현할 수 있습니다.
            // #Use a custom header. It can be implemented using the tr and th tags in the header slot.
            // $default: false
            customHeader: {type: Boolean,default: false},

            // $ver: v0.1.0
            // 컬럼 Resize 기능을 활성화 합니다. 커스텀헤더를 사용할 경우 동작하지 않습니다.
            // #Enable the column resize function. If you use a custom header, it will not work.
            // $default: false
            resizeColumn: {type: Boolean,default: false},

            // $ver: v0.1.0
            // 페이지 당 항목 수 선택을 위한 드랍다운 리스트를 구성하는 배열 입니다.
            // #An array of drop-down lists for selecting the number of items per page.
            perPageItems: {type: Array},

            // $ver: v0.1.0
            // 페이징 처리를 하지 않습니다.
            // #No paging mode.
            // $default: false
            noPage        : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 컨트롤 영역을 표시하지 않습니다. 총 항목 수, 페이지 당 항목 수 선택, 커스텀 버튼이 위치하는 영역입니다.
            // #Do not display the control area. This is the area where the total number of items, the number of items per page, and the custom button are located.
            // $default: false
            noControl     : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 컨트롤 영역의 좌우를 바꿉니다. 총 항목 수, 페이지 당 항목 수 선택 드랍다운이 우측으로, 커스텀 버튼이 좌측에 위치합니다.
            // #Reverse the control area. The Total Items, Select Items per Page drop-down is on the right, and the custom button is on the left.
            // $default: false
            reverseControl: {type: Boolean,default: false},

            // $ver: v0.1.0
            // 행을 클릭하여 펼침/닫힘 처리 기능을 사용합니다. expend 슬롯에 펼쳐졌을 때 보여질 컨텐츠를 구성해야 합니다.
            // #Click the row to use the expand / close handling feature. You need to configure the content that will be shown when expanded in the expend slot.
            // $default: false
            expandable    : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 단일 행 선택만 가능합니다. 항목 앞에 체크박스가 나타납니다.
            // #Only single row selection is possible. A checkbox appears in front of the item.
            // $default: false
            singleSelect  : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 여러 행 선택이 가능합니다. 항목 앞에 체크박스가 나타납니다.
            // #Multiple rows can be selected. A checkbox appears in front of the item.
            // $default: false
            multiSelect   : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 헤더 영역의 전체 체크박스가 나타나며, 체크 시 모든 행이 선택됩니다. singleSelect 모드에서는 나타나지 않습니다.
            // #The entire checkbox in the header area appears, and all rows are selected when checked. It does not appear in singleSelect mode.
            // $default: false
            selectAll     : {type: Boolean,default: false},

            // $ver: v0.1.0
            // rowSortable 속성으로 대체되었습니다.
            // #Replaced by the rowSortable property.
            // $default: false
            // $deprecated
            sortable      : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 헤더클릭 시 정렬 기능을 사용합니다.
            // #Click the header to use the sort function.
            // $default: false
            rowSortable   : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 행의 높이를 지정합니다. 단위는 px 입니다.
            // #Specifies the height of the row. The unit is px.
            rowHeight   : {type: [Number, String],default: 48},

            // $ver: v0.1.0
            // 헤더의 높이를 지정합니다. 단위는 px 입니다.
            // #Specifies the height of the header. The unit is px.
            headerHeight: {type: [Number, String],default: 40},

            // $ver: v0.1.0
            // <em>lego-pagination</em> 연계를 위한 객체입니다. 페이지 별 항목 수, 현재 페이지, 총 페이지 수, 총 항목 수 정보가 입력됩니다.
            // 자세한 내용은 <a href="/#/dev/comp/pagination">링크</a>를 참조하십시오.
            // #Object for <em>lego-pagination</em> associations. Information about the number of items per page, current page, total number of pages, and total number of items is entered.
            // #See the <a href="/#/dev/comp/pagination">links</a> for more information.
            pagination: {type: Object,
                default: () => {
                    return {
                        rowsPerPage: 10,
                        currentPage: 1,
                        totalPages: 0,
                        totalItems: 0
                    };
                }
            },

            // $ver: v0.1.0
            // $v-model
            // v-model로 바인딩되는 값으로, 테이블 내 선택된 항목 객체와 연결됩니다.
            // #The value bound to v-model, associated with the selected item object in the table.
            value: {type: [Number, String, Array, Object]},

            // $ver: v0.1.0
            // 테이블 내 항목이 없을 경우, 표시할 텍스트 입니다.
            // #Text to display if there is no entry in the table.
            noDataText: {type: String},

            // $ver: v0.1.2
            // 테이블 상단 총 개수 항목에서 앞쪽에 표시할 텍스트 입니다.
            // #Text to display in front of the tabletop total count entry.
            // $default: 'Total'
            totalText: {type: String},

            // $ver: v0.1.2
            // 테이블 상단 총 개수 항목에서 뒤쪽에 표시할 텍스트 입니다.
            // #Text to display later in the tabletop total count entry.
            // $default: 'per page'
            perPageText: {type: String},

            // $ver: v0.1.0
            // 제목에 표시될 문자열 입니다. 지정하지 않으면 제목 영역이 보이지 않습니다.
            // #The string to be displayed in the title. If not specified, the subject area is not visible.
            title    : {type:String, default:null},

            // $ver: v0.1.0
            // 제목에 표시될 설명 문자열 입니다. 제목의 우측에 위치하며, title 속성을 사용하지 않을 경우 보이지 않습니다.
            // #Description string to be displayed in the title. Located to the right of the title, invisible unless the title attribute is used.
            titleDesc: {type:String, default:null}
        },
        data() {
            return {
                default: {
                    noDataText: 'Sorry, nothing to display here',
                    totalText: 'Total',
                    perPageText: 'per page',
                    perPageItems:  [
                        {text: '10', value: 10},
                        {text: '15', value: 15},
                        {text: '20', value: 20}
                    ]
                },
                resizeOver: [],
                selected: [],
                dumpHeaders: [],
                selectAllWidth: 34,
                rowPerPage: 10,
                toggleResize: false,
                resizeBeforeWidth: 0,
                resizeBeforePositionX: 0,
                resizeTargetIdx: 0,
                resizeLineTop: 0,
                resizeLineLeft: 0,
                sortIdx: -1
            };
        },
        created() {
            this.buildDumpHeader();
            this.rowPerPage = this.pagination.rowsPerPage;
        },
        mounted() {},
        computed: {
            $_noDataText() {
                return this.noDataText || this.default.noDataText;
            },
            $_totalText() {
                return this.totalText || this.default.totalText;
            },
            $_perPageText() {
                return this.perPageText || this.default.perPageText;
            },
            $_perPageItems() {
                return this.perPageItems || this.default.perPageItems;
            },
            isActionSelect() {
                return this.selected.length>0;
            },
            controlClass() {
                let clazz = [];
                if(this.reverseControl) {clazz.push("lego-table__control--reverse")}
                if(this.noPage) {clazz.push("lego-table__control--no-page")}
                return clazz;
            },
            headerContentHeight() {
                return (this.headerHeight - 10) + 'px';
            },
            tableRowHeight() {
                return (this.rowHeight) + 'px';
            },
            selectAllChecked() {
                return (this.selected.length > 0);
            },
            selectAllCheckedIcon() {
                return (this.selected.length === this.items.length) ? 'checked' : 'indeterminate';
            },
            resizeLineStyle() {
                let tmpStyle = {};
                tmpStyle['position'] = 'absolute';
                // tmpStyle['margin-top'] = this.headerHeight + 'px'
                tmpStyle['height'] = (this.rowHeight * this.pagination.rowsPerPage) + 'px';
                tmpStyle['left'] = this.resizeLineLeft;
                return tmpStyle;
            },
            alertColspan() {
                return this.selectAll ? (this.dumpHeaders.length + 1) : this.dumpHeaders.length;
            }
        },
        watch: {
            headers: {
                deep: true,
                handler: function (val, oldVal) {
                    this.buildDumpHeader();
                }
            },
            rowPerPage(newVal) {
                /*this.selected = [];
                this.$emit('input', this.selected);
                this.$emit('change', newVal);/**/
                this.clearSelected();
                // this.$emit('change', newVal)
            },
            'pagination.currentPage': {
                deep: true,
                handler: function (newVal, oldVal) {
                    /*this.selected = [];
                    this.$emit('input', this.selected);/**/
                    this.clearSelected();
                }
            },
            /* value(newVal){
                if(newVal !== this.selected){
                    this.selected = newVal
                }
            } */
        },
        methods: {
            buildDumpHeader() {
                //this.dumpHeaders = Object.assign([], this.dumpHeaders, this.headers);
                this.dumpHeaders = Object.assign([], this.headers);
                if(this.resizeColumn) {
                    let lastIdx = this.dumpHeaders.length - 1;
                    this.dumpHeaders[lastIdx].width = undefined;
                }
            },
            headerDragStart(targetIdx, event) {
                if(this.toggleResize) return;
                this.toggleResize = true;
                let $pEL = event.target.parentElement;
                this.resizeBeforeWidth = $pEL.getBoundingClientRect().width;
                this.resizeBeforePositionX = $pEL.getBoundingClientRect().left + this.resizeBeforeWidth;
                this.resizeTargetIdx = targetIdx;
                this.resizeLineLeft = event.layerX + 'px';
            },
            headerDragEnd(event) {
                if (this.toggleResize) {
                    let nWidth = Number(event.pageX - this.resizeBeforePositionX) + this.resizeBeforeWidth;
                    this.$set(this.dumpHeaders[this.resizeTargetIdx], 'width', nWidth + 'px');
                    this.toggleResize = false;
                }
            },
            headerDragOver(event) {
                if (this.toggleResize) {
                    this.resizeLineLeft = event.layerX + 'px';
                }
            },
            headerMouseLeave() { /*NOT USE*/
                if (this.toggleResize) {
                    this.toggleResize = false;
                }
            },
            clearSelected() {
                this.selected = [];
                // $ver: v0.1.0
                // $arg: updated value
                // 테이블 행이 선택/선택해제 될 때, 해당 항목 객체를 파라미터로 이벤트를 발생 시킵니다.
                // #When a table row is selected / unselected, it raises an event with that item object as a parameter.
                this.$emit('input',this.selected);
            },
            clickSelectAll(event) {
                if (this.selected.length === this.items.length) {
                    /*this.selected = [];/**/
                    this.clearSelected();
                } else {
                    this.selected = this.items.slice();
                    this.$emit('input',this.selected)
                }
                /*this.$emit('input', this.selected);/**/
            },
            thStyle(header) {
                let h = {};
                h['text-align'] = header.align ? header.align : 'left';
                return h;
            },
            onClickRow(row) {
                if(!this.expandable && !this.multiSelect && !this.singleSelect){
                    // $ver: v0.1.0
                    // $arg: row object
                    // 테이블 행이 클릭 될 때, 해당 항목 객체를 파라미터로 이벤트를 발생 시킵니다.
                    // #When a table row is clicked, it raises an event with the item object as a parameter.
                    this.$emit('click-row', row);
                }
                
                if (this.expandable) {
                    let myExpand = row.expand;
                    if (!this.multiSelect) {
                        for (let item of this.items) {
                            if (item.expand) {
                                item.expand = false;
                            }
                        }
                    }
                    this.$set(row,'expand',!myExpand);
                }

                if (!this.multiSelect && !this.singleSelect) { return; }
                if (this.multiSelect) {
                    if (this.selected.indexOf(row) >= 0) {
                        this.selected.splice(this.selected.indexOf(row), 1);
                    } else {
                        this.selected.push(row);
                    }
                    this.$emit('input', this.selected);
                } else {
                    let tmp = this.selected.pop();
                    if (tmp !== row) {
                        this.selected.push(row);
                    }
                    this.$emit('input', this.selected);
                }
            },
            isSelected(row) {
                if (this.value) {
                    if (this.value.length) {
                        return (this.value.indexOf(row) >= 0);
                    } else {
                        return (this.value === row);
                    }
                }
                return false;
            },
            headerResizeBoxStyle(hIdx) {
                let tmpStyle = {};
                tmpStyle['height'] = this.headerContentHeight;
                if ((hIdx + 1) === this.dumpHeaders.length) {
                    tmpStyle['display'] = 'none';
                    tmpStyle['pointer-events'] = 'none';
                }
                return tmpStyle;
            },
            sortIconStyle(hIdx) {
                let sortStyle = {};
                sortStyle['transform'] = (!this.dumpHeaders[hIdx].desc) ? 'rotate(0deg)' : 'scaleY(-1)';
                return sortStyle;
            },
            sortIconClick(hIdx) {
                this.$set(this.dumpHeaders[hIdx], 'desc', !this.dumpHeaders[hIdx].desc);
                this.sortIdx = hIdx;
                // $ver: v0.1.0
                // $arg: header object
                // 테이블 헤더의 정렬 아이콘을 클릭할 때, 해당 해더 객체를 파라미터로 이벤트를 발생시킵니다.
                // #When you click the sort icon in the table header, it raises an event with the header object as a parameter.
                this.$emit('sort', this.dumpHeaders[hIdx]);
            },
            filterIconClick(hIdx) {
                // $ver: v0.1.0
                // $arg: header object
                // 테이블 헤더의 필터 아이콘을 클릭할 때, 해당 해더 객체를 파라미터로 이벤트를 발생시킵니다.
                // #When you click the filter icon in the table header, it raises an event with the header object as a parameter.
                this.$emit('filter', this.dumpHeaders[hIdx]);
            },
        }
    };
</script>
