<template>
    <div class="lego-page-table" :class="pageTableClass">
        <lego-table :items="data" :headers="meta"
                :singleSelect="$_singleSelect" :multiSelect="$_multiSelect">
            <template slot="action" v-if="hasBtn">
                <lego-button v-if="hasAddBtn" small bordered @click="btnAdd">Add</lego-button>
                <lego-button v-if="hasMdfBtn" small bordered @click="btnMdf">Modify</lego-button>
                <lego-button v-if="hasDelBtn" small bordered @click="btnDel">Delete</lego-button>
            </template>
            <template slot="items" slot-scope="props">
                <td v-for="m in meta" >{{props.item[m.value]}}</td>
            </template>
        </lego-table>
    </div>
</template>

<script>
const EVT_BTN_ADD = "btn::add";
const EVT_BTN_MDF = "btn::edit";
const EVT_BTN_DEL = "btn::del";

export default {
    name : "legoPageTable",
    inject:['screen'],
    props : {
        /* [SELF] meta : 컬럼정보 */
        meta : {type:Array,default:[],required: true},
        /* [SELF] data : table을 그릴 아이템 목록 */
        data : {type:Array,default:[]},
        /* [TABLE] */
        singleSelect: {type: Boolean,default: false},
        multiSelect : {type: Boolean,default: false},
        select      : {type: String, defulat: ""},
    },
    computed : {
        /* [FLAG] button event */
        hasBtn()    { return this.hasAddBtn || this.hasEditBtn || this.hasDelBtn; },
        hasAddBtn() { return this.$listeners.hasOwnProperty(EVT_BTN_ADD); },
        hasMdfBtn() { return this.$listeners.hasOwnProperty(EVT_BTN_MDF); },
        hasDelBtn() { return this.$listeners.hasOwnProperty(EVT_BTN_DEL); },
        /* [FLAG] row selection mode */
        $_singleSelect() { /*충돌나면 false*/
            let flag   = this.select === "single" || !!this.singleSelect;
            let opFlag = !!this.multiSelect;
            return flag && !opFlag;
        },
        $_multiSelect() { /*충돌나면 false*/
            let flag   = this.select === "multi" || !!this.multiSelect;
            let opFlag = !!this.singleSelect;
            return flag && !opFlag;
        },
        /* [CLASS] */
        pageTableClass() {
            let clazz = [];
            // TODO check has pagination or not
            clazz.push("lego-page-table--no-title");
            return clazz;
        }
    },
    created() {},
    methods : {
        btnAdd() {
            this.$emit(EVT_BTN_ADD,[]);
        },
        btnMdf() {
            this.$emit(EVT_BTN_MDF,[]);
        },
        btnDel() {
            this.$emit(EVT_BTN_DEL,[]);
        }
    }
}
</script>