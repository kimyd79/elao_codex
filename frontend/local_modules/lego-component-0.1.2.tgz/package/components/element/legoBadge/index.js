import legoBadge from "./legoBadge.vue";
export default {
    install(Vue){
        Vue.component(legoBadge.name, legoBadge);
    }
};