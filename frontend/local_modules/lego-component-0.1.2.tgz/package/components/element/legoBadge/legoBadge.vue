<template>
    <div ref="container"  :class="containerClass">
        <div :class="badgeClass" v-if="badgeType!=='hidden'&&(badgeType==='status-dot'||badgeType==='identifier-start')" :style="badgeStyle">{{badgeType==='status-dot' ? '' : value}}</div>
        <!--
            $ver: v0.1.0
            뱃지와 함께 표시될 텍스트 영역입니다. 단순 문자열만 입력하는 경우가 일반적이고, lego-icon 컴포넌트를 활용하여 아이콘을 표시할 수 있습니다.
            #The text area to be displayed with the badge. It is common to enter only simple strings, and you can use the lego-icon component to display icons.
        -->
        <slot :class="slotClass"></slot>
        <div :class="badgeClass" v-if="badgeType!=='hidden'&&(badgeType!=='status-dot'&&badgeType!=='identifier-start')" :style="badgeStyle">{{value}}</div>
    </div>
</template>

<script>
    export default {
        /* TODO: lego-badge전체적으로 개편이 필요합니다... */
        name: "lego-badge",
        data () {
            return{
                containerWidth: 0,
            }
        },
        props: {
            // $ver: v0.1.0
            // Badge에 표시되는 숫자나 문자열값 입니다. Dot 형태의 뱃지인 경우 값을 입력해도 표시되지 않습니다.
            // #The number or string value displayed on the badge. If the badge is a dot, it will not display even if you enter a value
            // $default: null
            value: {
                type: [String,Number],
                default: null,
            },
            // $ver: v0.1.0
            // 텍스트 또는 아이콘과 겹쳐지게 표현할 지 여부입니다.
            // #Whether to overlap text or icons.
            // $default: false
            overlap: {
                type: Boolean,
                default: false,
            },
            // $ver: v0.1.0
            // 텍스트 및 아이콘 기준으로 뱃지가 표시될 위치입니다. 현재는 아무런 영향이 없는 속성입니다.
            // #Where the badge will appear based on text and icons. Currently this property has no effect.
            position: {
                type: String,
                default: 'top',
            },
            // $ver: v0.1.0
            // 색상입니다. 사전에 정의된 색상 문자열만 입력 가능합니다. 
            // #Color. Only predefined color strings can be entered.
            // ('success', 'error', 'default', 'processing', 'warning', 'notification','failure', 'info', 'active', 'disabled', 'valid', 'invalid', 'created', 'modified', 'deleted')
            // #('success', 'error', 'default', 'processing', 'warning', 'notification','failure', 'info', 'active', 'disabled', 'valid', 'invalid', 'created', 'modified', 'deleted')
            badgeColor: {
                type: String,
                validator: function (value) {
                    // The value must match one of these strings
                    return ['success', 'error', 'default', 'processing', 'warning', 'notification',
                        'failure', 'info', 'active', 'disabled', 'valid', 'invalid', 'created', 'modified', 'deleted'].indexOf(value) !== -1
                },
                default: 'notification',
            },
            // $ver: v0.1.0
            // 유형입니다. 사전에 정의된 유형 문자열만 입력 가능합니다. 
            // ('notification', 'status', 'status-dot', 'identifier-start', 'identifier-end', 'hidden')
            // #Type. Only predefined type strings can be entered.
            // #('notification', 'status', 'status-dot', 'identifier-start', 'identifier-end', 'hidden')
            badgeType: {
                type: String,
                validator: function (value) {
                    // The value must match one of these strings
                    return ['notification', 'status', 'status-dot', 'identifier-start', 'identifier-end', 'hidden'].indexOf(value) !== -1
                },
                default: 'notification',
            }
        },
        mounted() {
            if(this.$refs.container){
                this.containerWidth = this.$refs.container.clientWidth;
            }
            setTimeout(() => { // 길이를 바로 못 가져올 가능성이 있으므로 시간차로 한번 더 체크
                if(this.$refs.container){
                    this.containerWidth = this.$refs.container.clientWidth;
                }
            }, 100);
        },
        computed: {
            containerClass() {
                let clazz = [];
                clazz.push('lego-badge-container');
                if (this.badgeType === 'notification') {
                    clazz.push('lego-badge-container__notification');
                }
                return clazz;
            },
            slotClass() {
                let clazz = [];
                if (this.badgeType === 'notification') {
                    clazz.push('lego-badge-slot__notification');
                }
                return clazz;
            },
            badgeClass() {
                let clazz = [];
                clazz.push('lego-badge');
                clazz.push('lego-badge__' + this.badgeType);
                clazz.push('lego-badge__badge-color-' + this.badgeColor);
                return clazz;
            },
            badgeStyle() {
                let style = {};

                if(this.badgeType==='notification') {

                    if (this.value.length === 0) {
                        style['width'] = '4px';
                        style['height'] = '4px';
                        style['top'] = '-4px';
                        style['left'] = '4px';
                    } else if (this.value.length === 1) {
                        style['width'] = '16px';
                    } else {
                        style['width'] = 'auto';
                        style['padding-left'] = '8px';
                        style['padding-right'] = '8px';
                    }

                    if(this.overlap){
                        if(this.value.length === 0) {
                            style['top'] = '4px';
                            style['left'] = (this.containerWidth - 4) +'px';
                        } else {
                            style['left'] = (this.containerWidth - 16) +'px';
                        }
                    }else{
                        style['left'] = this.containerWidth + 'px';
                    }
                }

                return style;
            }
        }
    }
</script>