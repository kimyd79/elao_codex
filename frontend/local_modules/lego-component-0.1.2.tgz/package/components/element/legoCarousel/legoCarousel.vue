<template>
    <div class="lego-carousel" :style="compoStyle" :class="compoClass">
        <div class="lego-carousel__window" :style="horseStyle">
            <div class="lego-carousel__left-move" @click="moveTick(-1)" :class="leftCarotClass">
                <lego-icon md type="picto">collapse_menu</lego-icon>
            </div>
            <div class="lego-carousel__horse-wrapper" :style="wrapperStyle"><!--
                $ver: v0.1.0
                <em>lego-carousel-horse</em> 컴포넌트들로 구성되는 컨텐츠 영역입니다.
                #A content area consisting of <em>lego-carousel-horse</em> components.
             --><slot/>
            </div>
            <div class="lego-carousel__right-move" @click="moveTick(1)" :class="rightCarotClass">
                <lego-icon md type="picto">collapse_menu</lego-icon>
            </div>
        </div>
        <!-- [PAGER] -->
        <template v-if="isDot">
            <div class="lego-carousel__pager lego-carousel__pager-wrapper">
                <div v-for="n in horseCount" class="lego-carousel__pager-dot"
                    :class="pagerClass(n)" @click="goARound(n)" :key="n"/>
            </div>
        </template>
        <template v-if="isThumb">
            <div class="lego-carousel__pager">
                <div class="lego-carousel__pager-caret-left" @click="moveTick(-1)">
                    <lego-icon sm type="picto">collapse_menu</lego-icon>
                </div>
                <div class="lego-carousel__pager-window">
                    <div class="lego-carousel__pager-wrapper" :style="thumbWrapperStyle">
                        <img v-for="(src,i) in thumbList" class="lego-carousel__pager-thumb"
                            :src="src" :class="pagerClass(i+1)" :style="thumbStyle"
                            @click="goARound(i+1)" :key="i"/>
                    </div>
                </div>
                <div class="lego-carousel__pager-caret-right" @click="moveTick(+1)">
                    <lego-icon sm type="picto">collapse_menu</lego-icon>
                </div>
            </div>
        </template>
        
        
    </div>
</template>

<script>

const DEFAULT_WIDTH  = 460;
const DEFAULT_HEIGHT = 210;
const THUMB_IMG_WIDTH  = 54;
const THUMB_IMG_HEIGHT = 41;
export default {
    name: 'legoCarousel',
    props: {
        // $ver: v0.1.0
        // 너비를 지정합니다. 단위는 px 입니다.
        // #Specify the width. The unit is px.
        // $default: 460
        width : { type: [Number,String], default: DEFAULT_WIDTH },

        // $ver: v0.1.0
        // 높이를 지정합니다. 단위는 px 입니다.
        // #Specify the height. The unit is px.
        // $default: 210
        height: { type: [Number,String], default: DEFAULT_HEIGHT },

        // $ver: v0.1.0
        // $abbr: width
        w : { type: [Number,String] },

        // $ver: v0.1.0
        // $abbr: height
        h : { type: [Number,String] },

        // $ver: v0.1.0
        // 페이징 영역을 Dot 유형으로 표현합니다.
        // #Paging area is represented by Dot type.
        // $default: true
        dot       : {type:Boolean,default:true},

        // $ver: v0.1.0
        // 페이징 영역을 썸네일 유형으로 표현합니다. thumbnail과 같은 속성입니다.
        // #Represents a paging area as a thumbnail type.
        // $default: false
        thumbnail : {type:Boolean,default:false},

        // $ver: v0.1.0
        // $abbr: thumbnail
        // $default: false
        thumb     : {type:Boolean,default:false},

        // $ver: v0.1.0
        // 마지막 페이지에서 다음 버튼으로 첫 페이지로 전환되지 않도록 합니다.
        // #Prevents you from switching to the first page from the last page with the Next button.
        // $default: false
        noRotate  : {type:Boolean,default:false},

        // $ver: v0.1.0
        // 현재 사용되지 않는 Prop 입니다.
        // #Prop not currently used.
        // $deprecated
        initScroll: { type:[Number,String] },
    },
    data() {return {
        scroll : 1,
    }},
    computed: {
        isDot()   {return this.dot && !this.isThumb},
        isThumb() {return this.thumb || this.thumbnail},
        nWidth() {
            let val = this.w || this.width;
            return parseInt(val) || DEFAULT_WIDTH;
        },
        nHeight() {
            let val = this.h || this.height ;
            return parseInt(val) || DEFAULT_WIDTH;
        },
        compoClass() {
            return {'lego-carousel--thumb':this.isThumb};
        },
        compoStyle() {return {width:this.nWidth+"px"}},
        horseStyle() {return {width:this.nWidth+"px",height:this.nHeight+"px"}},
        wrapperStyle() { return {
            'width'      : this.nWidth*this.horseCount+"px",
            'height'     : this.nHeight+"px",
            'margin-left': (this.nWidth*(1-this.scroll))+"px"
        }},
        thumbStyle()       {return {width:THUMB_IMG_WIDTH+"px",height:THUMB_IMG_HEIGHT+"px"}},
        thumbWindowStyle() {return {width:this.nWidth+"px",height:THUMB_IMG_HEIGHT+"px"}},
        thumbWrapperStyle(){
            let w = this.nWidth;
            let wrapperWidth = (THUMB_IMG_WIDTH+8)*this.horseCount;
            let diff = wrapperWidth - 8 - w;
            let lMargin = -4;
            if( diff > 0 ) {
                lMargin -= parseInt((this.scroll-1) * (diff /(this.horseCount-1)));
            }
            return {
                "width"      :wrapperWidth + "px",
                "height"     :THUMB_IMG_HEIGHT + "px",
                "margin-left":lMargin + "px"
            };
        },
        leftCarotClass() {
            return {"lego-carousel__move--block":this.noRotate&&this.scroll===1}
        },
        rightCarotClass() {
            return {"lego-carousel__move--block":this.noRotate&&this.scroll===this.horseCount}
        },
        
        sharedData() {
            let rtn = {}, odf = Object.defineProperty;
            odf(rtn, "width"  , {get:()=>this.nWidth});
            odf(rtn, "height" , {get:()=>this.nHeight});
            odf(rtn, "hStyle" , {get:()=>this.horseStyle});
            return rtn;
        },
        horseCount() {
            let slot = this.$slots.default, cnt=0;
            slot.forEach(item => {
                if(!item.componentOptions) return;
                let name = item.componentOptions.Ctor.options.name;
                if(name === 'legoCarouselHorse') cnt++;
            })
            return cnt;
        },
        thumbList() {
            let slot = this.$slots.default, arr = [];
            slot.forEach(item => {
                if(!item.componentOptions) return;
                let name = item.componentOptions.Ctor.options.name;
                if(name !== 'legoCarouselHorse') return;
                arr.push(item.componentOptions.propsData.thumb);
            })
            return arr;
        }
    },
    created() {
        
    },
    provide() {return {carousel:this.sharedData}},
    methods: {
        // @vuese
        // $ver: v0.1.0
        // $arg: Number - 이동할 페이지 번호
        // $return: N/A
        // 지정한 페이지로 보여지는 컨텐츠가 바뀝니다.
        // #The content shown on the specified page changes.
        goARound(n) {
            this.scroll = n;
        },

        pagerClass(n) {
            let clazz = [];
            if(n === this.scroll) { clazz.push('lego-carousel__pager--active'); }
            return clazz;
        },
        moveTick(of) {
            this.scroll += of;
            
            if( this.scroll > this.horseCount ) {this.scroll = this.noRotate?this.horseCount:1;}
            if( this.scroll < 1 ) {this.scroll = this.noRotate?1:this.horseCount;}
        }
    }
};


</script>