<template>
    <div class="lego-carousel-horse" :style="carousel.hStyle"><!--
        $ver: v0.1.0
        컨텐츠 영역입니다. 주로 이미지로 활용됩니다.
        #The content area. It is mainly used as an image.
    --><slot></slot>
    </div>
</template>

<script>
export default {
    name: 'legoCarouselHorse',
    inject: ['carousel'],
    props:{
        // $ver: v0.1.0
        // 썸네일 문자열 입니다. 현재 사용되지 않습니다.
        // #Thumbnail string. Currently not used.
        // $deprecated
        thumb:{type:String}
    }
};


</script>