import legoCarousel from './legoCarousel.vue';
import legoCarouselHorse from './legoCarouselHorse.vue';

export default {
    install(Vue) {
        Vue.component(legoCarousel.name, legoCarousel);
        Vue.component(legoCarouselHorse.name, legoCarouselHorse);
    }
};