<template>
    <div :class="iconWrapperClass">
        <slot/>
    </div>
</template>

<script>
export default {
    name: 'lego-icon-wrapper',
    props: {
        small: {type: Boolean, default: false},
    },
    computed: {
        iconWrapperClass() {
            let rtn =[];
            rtn.push('lego-icon-wrapper');
            if(this.small  || this.sm) {rtn.push('lego-icon-wrapper--small' );}
            if(this.medium || this.md) {rtn.push('lego-icon-wrapper--medium');}
            if(this.large  || this.lg) {rtn.push('lego-icon-wrapper--large' );}
            return rtn;
        }
    }
}
</script>