<script>
import {opusIconsPicto,opusIconsLine} from "./opusIconPath.js";
export default {
    name: "lego-icon",
    // Why functional?
    // svn object가 static하게 component정의부에만 한벌 존재하고
    // 컴포넌트 사용시에 복사본 instance state에는 포함되길 원하지않음.
    functional: true,
    props: {
        icon: {type: String},
        iconType: {
            type: String,
            validator: function(value) {
                return ['line', 'picto'].indexOf(value) !== -1;
            }
        },
        iconSize: {type: [String, Number]},
        spacing: {type: Boolean, default: false},
        default: {type:Boolean, default: false},
        primary: {type: Boolean, default: false},
        point: {type: Boolean, default: false},
        color: {type:String, default: undefined},
        large : {type: Boolean, default: false},
        medium : {type: Boolean, default: false},
        small: {type: Boolean, default: false},
        xsmall: {type: Boolean, default: false},

        /* font-awesome */
        brand   : Boolean,
        regular : Boolean,
        light   : Boolean,
        old     : Boolean,
        fab     : Boolean,
        far     : Boolean,
        fal     : Boolean,
        fa      : Boolean,

        /* abbr */
        type: {
            type: String,
            default: 'line',
            validator: function(value) {
                return ['line', 'picto'].indexOf(value) !== -1;
            }
        },
        size: {type: [String, Number]},
        dft: {type:Boolean, default: false},
        prim: {type: Boolean, default: false},
        pnt: {type: Boolean, default: false},
        col: {type: String, default: undefined},
        lg: {type: Boolean, default: false},
        md: {type: Boolean, default: false},
        sm: {type: Boolean, default: false},
        xs: {type: Boolean, default: false},
        focusable: {type:Boolean, default: false} // this is for IE. On IE, tab key make unnecessary focus to svg tag
    },
    render(h, {props, data,listeners, children = []}) {
        let opusIcons = {};
        let cType = props.iconType || props.type;
        if (cType === 'picto') {
            opusIcons = opusIconsPicto;
        } else if (cType === 'line') {
            opusIcons = opusIconsLine;
        }
        let cColor ='';
        if (props.primary||props.prim) { cColor= 'primary'; }
        else if (props.point||props.pnt) { cColor= 'point'; }
        else if (props.default||props.dft) { cColor= 'default'; }
        else if (!!props.color||!!props.col) { cColor= props.color||props.col; }

        let cSize = '' ;
        if(props.large || props.lg) {cSize= 'large';}
        else if(props.medium || props.md) {cSize= 'medium';}
        else if(props.small || props.sm) {cSize= 'small';}
        else if(props.xsmall || props.xs) {cSize= 'xsmall';}

        let customSize = props.iconSize || props.size;
        if(typeof customSize === 'number') {customSize = customSize + 'px';}

        let iconName = props.icon || children.pop().text;
        let options = {
            class: [
                'lego-icon',
                cType && 'lego-icon--'+cType,
                cColor && 'lego-icon--'+cColor,
                cSize &&'lego-icon--'+cSize,
                props.spacing && 'lego-icon--spacing'
            ],
            style: {
                fontSize: customSize
            },
            on: listeners
        };
        if(data.class) {
            if(Array.isArray(data.class)) {
                options.class = options.class.concat(data.class);
            }
            if(typeof data.class === 'string' || typeof data.class === 'object') {
                options.class.push(data.class);
            }
        }
        if(data.style) {
            options.style = Object.assign(data.style, options.style);
        }
        let child = [];
        if (opusIcons[iconName] !== undefined) {
            // !!! BE CAREFUL !!! this component uses v-html(innerHTML).
            // So, opusIcons object MUST NOT contain XSS vulnerability.
            options.class.push('opus-icon__'+iconName);
            let svg = opusIcons[iconName];
            if(!props.focusable) {svg = svg.replace('<svg ','<svg focusable="false" ');}
            options.domProps={innerHTML:svg};
        } else {
            // 1. icon class
            options.class.push('fa-'+iconName);
            // 2. type class
            if     ( props.brand )   { options.class.push('fab'); }
            else if( props.fab)      { options.class.push('fab'); }
            else if( props.regular ) { options.class.push('far'); }/* pro only */
            else if( props.far )     { options.class.push('far'); }/* pro only */
            else if( props.light)    { options.class.push('fal'); }/* pro only */
            else if( props.fal)      { options.class.push('fal'); }/* pro only */
            else if( props.old)      { options.class.push('fa'); }/* font-awesome 4.0*/
            else if( props.fa)       { options.class.push('fa'); }/* font-awesome 4.0*/
            else { options.class.push("fas"); }
        }
        return h('i',Object.assign(data, options));
    },
}
</script>