import legoIcon from "./legoIcon.vue";
import legoIconWrapper from "./legoIconWrapper.vue";
export default {
    install(Vue){
        Vue.component(legoIcon.name, legoIcon);
        Vue.component(legoIconWrapper.name, legoIconWrapper);
    }
};