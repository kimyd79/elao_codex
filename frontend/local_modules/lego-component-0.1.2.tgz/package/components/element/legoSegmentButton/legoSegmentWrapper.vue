<template>
    <div class="lego-segment-wrapper lego-input" :class="wrapperClass">
        <!--
            $ver:v0.1.1
            여러 <em>lego-segment-button</em> 컴포넌트를 하나로 묶기 위한 영역입니다.
            #An area for grouping multiple <em>lego-segment-button</em> components into one.
        -->
        <slot></slot>
        <!--
        FIXME: validator 넣어놓긴 했는데 absolute로 띄우고 메시지 출력하는걸 깜빡함.
        css 설정 필요. radio wrapper같은거 참고하면 좋을듯.
        -->
        <div v-if="messageShow"
             class="lego-segment-wrapper__message lego-validator__message">
            {{messageShow}}
        </div>
    </div>
</template>

<script>
    import legoValidatorMixin from '../../../mixins/legoValidator/legoValidatorMixin.vue';
    export default {
        name: 'lego-segment-wrapper',
        mixins: [legoValidatorMixin],
        model: {
            prop: 'checked',
        },
        inject: {
            legoInput: {from:'legoInput', default: () => undefined}
        },
        props: {
            // $ver: v0.1.2
            // $v-model
            // v-model로 바인딩 되는 값입니다. <em>lego-segment-wrapper</em>하위에 존재하는
            // <em>lego-segment-button</em>의 v-model을 덮어씁니다.(단, group이 다른 경우 제외)
            // #The value bound to v-model. Overrides the v-model of <em>lego-segment-button</em> that exists under <em>lego-segment-wrapper</em> (unless group is different)
            checked: {type: [Boolean, String, Array]},
            // $ver: v0.1.2
            // 하단에 표시되는 가이드 메시지입니다. 별도의 설정이 없다면 출력되지 않습니다.
            // <em>lego-segment-wrapper</em>는 메시지 출력을 위한 공간을 별도로 점유하지않습니다.
            // 메시지 출력을 원할 경우 공간확보가 필요합니다.
            // #The guide message that appears at the bottom. If there is no setting, no output.
            // #<em>lego-segment-wrapper</em> does not occupy any space for message output.
            // #If you want to output a message, you need to make space.
            guideMessage: {type:String, default: undefined},
            // $ver: v0.1.2
            // validate를 통과한 경우 출력되는 메시지입니다.
            // 별도설정이 없다면 가이드 메시지가 출력되거나 아무런 메시지도 출력되지 않습니다.
            // <em>lego-segment-wrapper</em>는 메시지 출력을 위한 공간을 별도로 점유하지않습니다.
            // 메시지 출력을 원할 경우 공간확보가 필요합니다.
            // #The message that is output if validate passes.
            // #If there is no setting, guide message or no message is printed.
            // #<em>lego-segment-wrapper</em> does not occupy any space for message output.
            // #If you want to output a message, you need to make space.
            successMessage: {type:String, default: undefined},
            // $ver: v0.1.2
            // <em>lego-segment-wrapper</em>하위에 존재하는 <em>lego-segment-button</em>중에서
            // <em>lego-segment-wrapper</em>와 group이 같게 설정된 <em>lego-segment-button</em>만 영향을 받게됩니다.
            // segment-wrapper와 segment-button 모두 기본값은 'default'로 설정되어있습니다.
            // #<em>lego-segment-button</em> from the <em>lego-segment-wrapper</em>,
            // #Only <em>lego-segment-button</em> with the same <em>lego-segment-wrapper</em> and group set will be affected.
            // #Both segment-wrapper and segment-button are set to 'default' by default.
            group: {
                type: String,
                default: 'default'
            },
            // $ver: v0.1.2
            // <em>lego-segment-wrapper</em>하위에 존재하는 <em>lego-segment-button</em>를 disabled 상태로 설정합니다.
            // <em>lego-segment-wrapper</em>와 group 이 같게 설정된 <em>lego-segment-button</em>만 영향을 받게됩니다.
            // #Set the <em>lego-segment-button</em> below the <em>lego-segment-wrapper</em> to the disabled state.
            // #Only <em>lego-segment-button</em> with the same <em>lego-segment-wrapper</em> and group set will be affected.
            // $default: false
            disabled: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // 선택된 <em>lego-segment-button</em>의 색상을 Primary 색상으로 정의합니다.
            // #Defines the color of the selected <em>lego-segment-button</em> as the primary color.
            // $default: false
            primary: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: primary
            prim: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 선택된 <em>lego-segment-button</em>의 색상을 Point 색상으로 정의합니다.
            // #Defines the color of the selected <em>lego-segment-button</em> as the Point color.
            // $default: false
            point: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: point
            pnt: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 하위 <em>lego-segment-button</em>의 모양새를 solid-button 스타일로 정의합니다.
            // #Define the appearance of the child <em>lego-segment-button</em> in the solid-button style.
            // $default: false
            solid: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: solid
            sol: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 하위 <em>lego-segment-button</em>의 모양새를 border-button 스타일로 정의합니다.
            // #Define the appearance of the child <em>lego-segment-button</em> with the border-button style.
            // $default: false
            border: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: border
            bor: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 하위 <em>lego-segment-button</em>의 크기를 medium으로 정의합니다.
            // #Define the size of the child <em>lego-segment-button</em> as medium.
            // $default: false
            medium: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: medium
            md: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 하위 <em>lego-segment-button</em>의 크기를 small로 정의합니다.
            // #Define the size of the child <em>lego-segment-button</em> as small.
            // $default: false
            small: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: small
            sm: {
                type:Boolean,
                default: false,
            },
            clearable: Boolean
            /* [FROM VALIDATOR] */
            // rules
            // disabled
            // lazy
            // noShake
            /********************/
        },
        data() {return {
            default : {
                size: 'medium',
                style: 'border',
                color: 'default'
            }
            /* [FROM VALIDATOR] */
            // hasError
            // errorMessage
            // showValid
            // shake
            /********************/
        }},
        computed: {
            $_style() {
                if(this.border || this.bor) {return 'border'}
                if(this.solid || this.sol) {return 'solid'}
                return this.default.style;
            },
            $_color() {
                if(this.primary || this.prim) {return 'primary'}
                if(this.point || this.pnt) {return 'point'}
                return this.default.color;
            },
            $_size() {
                if(this.medium || this.md) {return 'medium'}
                if(this.small || this.sm) {return 'small'}
                if(this.legoInput) {return this.legoInput.size}
                return this.default.size;
            },
            wrapperClass() { return {
                'lego-validator--error': this.hasError === true,
                'lego-validator--valid': this.showValid && this.hasError === false,
                'lego-validator--shake': this.shake
            }},
            sharedData() {
                let rtn = {}, odf = Object.defineProperty;
                odf(rtn, "checked"     , {get:()=>this.checked});
                odf(rtn, "emit"        , {get:()=>this.emit});
                odf(rtn, "click"        , {get:()=>this.click});
                odf(rtn, 'disabled' , {get:()=>this.disabled});
                odf(rtn, 'hasError' , {get:()=>this.hasError});
                odf(rtn, 'style' , {get:()=>this.$_style});
                odf(rtn, 'color' , {get:()=>this.$_color});
                odf(rtn, 'clearable' , {get:()=>this.clearable});
                return rtn;
            },
            messageShow() {
                if(this.hasError === undefined) {
                    return this.guideMessage;
                }
                if(this.hasError === true) {
                    return this.errorMessage;
                }
                if(this.hasError === false) {
                    return this.successMessage || this.guideMessage;
                }
                return undefined;
            },
            /* [FROM VALIDATOR] */
            // isValidatable
            // el
            validateTarget() {return this.checked;}, // validation setting
            /********************/
        },
        watch: {
            validateTarget(val) {
                this.validateOnEvent(); // whenever checked value changes, execute validate() if lazy is false
            },
            successMessage: {
                immediate: true,
                handler(val) {
                    this.showValid = !!val;
                }
            }
        },
        provide() {
            let rtn = {legoSegmentWrapper:{}};
            let odf = Object.defineProperty;
            rtn.legoSegmentWrapper[this.group] = this.sharedData;
            let legoInput = {};
            odf(legoInput, 'size', {get: ()=>this.$_size});
            rtn['legoInput'] = legoInput;
            return rtn;
        },
        methods: {
            /* [FROM VALIDATOR] */
            // validate()        --+
            // isValid()         --+-- exposed methods for manual validate control
            // clearValidation() --+
            // validateOnEvent() -> should be set by each component which uses legoValidatorMixin
            /********************/

            emit(val) {
                // $ver: v0.1.1
                // $arg: updated v-model value
                // v-model에 설정된값(checked)을 업데이트합니다.
                // # update v-model value(checked props).
                this.$emit('input', val);
            },
            click(e) {
                // $ver: v0.1.2
                // $arg: click event
                // click 시 이벤트를 호출합니다.
                // # Call event on click.
                this.$emit('click', e);
            }
        }
    }
</script>