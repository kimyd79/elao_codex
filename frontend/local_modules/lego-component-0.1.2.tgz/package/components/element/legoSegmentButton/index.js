import legoSegmentWrapper from "./legoSegmentWrapper.vue";
import legoSegmentButton from "./legoSegmentButton.vue";
export default {
    install(Vue){
        Vue.component(legoSegmentWrapper.name, legoSegmentWrapper);
        Vue.component(legoSegmentButton.name, legoSegmentButton);
    }
};