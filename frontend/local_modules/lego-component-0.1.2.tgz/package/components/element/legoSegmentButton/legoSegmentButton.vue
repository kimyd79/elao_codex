<template>
    <button class="lego-segment-button"
            :class="segmentButtonClass"
            @click.stop="onClick">
    <!-- 
        $ver: v0.1.0
        버튼 내부에 위치하는 영역입니다. 일반적으로 버튼 텍스트가 사용됩니다.
        #The area located inside the button. Typically button text is used.
     --><slot />
    </button>
</template>

<script>
    export default {
        name: 'lego-segment-button',
        model: {
            prop: 'checked'
        },
        inject: {
            legoSegmentWrapper: {from: 'legoSegmentWrapper', default: () => undefined},
            legoInput: {from:'legoInput', default: () => undefined}
        },
        props: {
            // $ver: v0.1.2
            // $v-model
            // v-model로 바인딩되는 값으로, <em>lego-segment-wrapper</em>를 사용할 경우
            // lego-segment-wrapper의 v-model값을 우선시하고 lego-segment-button의 v-model은 무시됩니다.
            // 단일 세그먼트버튼으로 사용되는 경우에만 Boolean, String 타입을 사용하고 다중선택이 필요한경우 Array타입을 사용해야 합니다.
            // # Binding to v-model. If <em>lego-segment-wrapper</em> component used,
            // # v-model of this lego-segment-button is ignored and v-model of lego-segment-wrapper is used instead.
            // # Boolean and String type is only used in single segment-button use-case. Array type has to be set when using multiple select use-case.
            checked: {
                type: [Boolean, String, Array],
            },
            // $ver: v0.1.0
            // 선택되었을 때 v-model의 값으로 설정되는 목표값입니다.
            // # If component is checked, v-model is set as this value.
            // $default: true
            value: {
                type: [String, Boolean, Number, Array, Object],
                default: true
            },
            // $ver: v0.1.2
            // <em>lego-checkbox-wrapper</em>와 함께 사용할 때 wrapper 하위에 위치하는 모든 체크박스가 아닌
            // 특정 체크박스에만 validate를 적용하고 싶을 경우 group이름을 지정하여 분리할 수 있습니다.
            // #When used with <em>lego-checkbox-wrapper</em>, you can separate it by specifying the group name 
            // #if you want to apply validate only to a specific checkbox rather than to all the checkboxes under the wrapper.
            group: {
                type: String,
                default: 'default'
            },
            // $ver: v0.1.2
            // 상호작용 불가능한 상태를 만듭니다.
            // #Set a non-interactive state.
            // $default: false
            disabled: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // 선택된 <em>lego-segment-button</em>의 색상을 Primary 색상으로 정의합니다.
            // #Defines the color of the selected <em>lego-segment-button</em> as the primary color.
            primary: {
                type: Boolean,
            },
            // $ver: v0.1.2
            // $abbr: primary
            prim: {
                type: Boolean,
            },
            // $ver: v0.1.2
            // 선택된 <em>lego-segment-button</em>의 색상을 Point 색상으로 정의합니다.
            // #Defines the color of the selected <em>lego-segment-button</em> as the Point color.
            point: {
                type: Boolean,
            },
            // $ver: v0.1.2
            // $abbr: point
            pnt: {
                type: Boolean,
            },
            // $ver: v0.1.2
            // 모양새를 solid-button 스타일로 정의합니다.
            // #Define the appearance in solid-button style.
            // $default: false
            solid: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: solid
            sol: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 모양새를 border-button 스타일로 정의합니다.
            // #Define the appearance in the border-button style.
            // $default: false
            border: {
                type: Boolean,
                default: false
            },
            // $ver: v0.1.2
            // $abbr: border
            bor: {
                type:Boolean,
                default: false,
            },
            // $ver: v0.1.2
            // 크기를 medium으로 정의합니다. 기본크기입니다.
            // #Define the size as medium. The default size.
            // $default: false
            medium: {
                type: Boolean,
                default: false
            },
            // $abbr: medium
            md: {type:Boolean},
            // $ver: v0.1.2
            // 크기를 small로 정의합니다.
            // #Define the size as small.
            // $default: false
            small: {
                type: Boolean,
                default: false
            },
            // $abbr: small
            sm: {type:Boolean},
        },

        data() {
            return {
                default : {
                    size: 'medium',
                    style: 'border',
                    color: 'default'
                }
            };
        },
        computed: {
            $_legoSegmentWrapper() {
                return this.legoSegmentWrapper && this.legoSegmentWrapper[this.group];
            },
            $_style() {
                if(this.border || this.bor) {return 'border'}
                if(this.solid || this.sol) {return 'solid'}
                if(this.$_legoSegmentWrapper && this.$_legoSegmentWrapper.style) {return this.$_legoSegmentWrapper.style;}
                return this.default.style;
            },
            $_color() {
                if(this.primary || this.prim) {return 'primary'}
                if(this.point || this.pnt) {return 'point'}
                if(this.$_legoSegmentWrapper && this.$_legoSegmentWrapper.color) {return this.$_legoSegmentWrapper.color;}
                return this.default.color;
            },
            $_size() {
                if(this.medium || this.md) {return 'medium'}
                if(this.small || this.sm) {return 'small'}
                if(this.legoInput) {return this.legoInput.size;}
                return this.default.size;
            },
            actualVModel() {
                if(this.$_legoSegmentWrapper) {
                    if(this.checked){
                        console.warn('[LEGO-SEGMENT-BUTTON] if you use lego-segment-wrapper, v-model(=checked props) of lego-segment-button itself is being ignored.');
                    }
                    return this.$_legoSegmentWrapper.checked;
                }
                return this.checked;
            },
            clicked() {
                if (typeof(this.value) == 'boolean') {
                    // Boolean
                    if(this.actualVModel==='Y') return true;
                    if(this.actualVModel==='N') return false;
                    return this.actualVModel;
                }
                else {
                    if (Array.isArray(this.actualVModel)) {
                        // Array
                        return (this.actualVModel.indexOf(this.value) >= 0);
                    }
                    else {
                        // String
                        return this.actualVModel === this.value;
                    }
                }
            },
            segmentButtonClass() {
                let clazz = [];
                if (this.disabled || (this.$_legoSegmentWrapper && this.$_legoSegmentWrapper.disabled)) {
                    clazz.push('lego-segment-button--disabled');
                }
                clazz.push('lego-segment-button--'+this.$_color);
                clazz.push('lego-segment-button--'+this.$_style);
                clazz.push('lego-segment-button--'+this.$_size);
                if(this.clicked) {
                    clazz.push('lego-segment-button--checked');
                }
                if(this.$_legoSegmentWrapper && this.$_legoSegmentWrapper.hasError) {
                    clazz.push('lego-validator--error')
                }
                return clazz;
            }
        },
        methods: {
            onClick(e) {
                // $ver: v0.1.2
                // $arg: click event
                // click 시 이벤트를 호출합니다.
                // # Call event on click.
                this.$emit('click',e);
                if(this.$_legoSegmentWrapper) {this.$_legoSegmentWrapper.click(e);}

                if (typeof(this.value) === 'boolean') {
                    if(this.actualVModel==='Y') {this.emit('N');}
                    else if(this.actualVModel==='N'){this.emit('Y');}
                    else {
                        this.emit(!this.actualVModel);
                    }
                } else {
                    if (Array.isArray(this.actualVModel)) {
                        if (this.actualVModel.indexOf(this.value) >= 0) {
                            // if exist, remove it
                            this.emit(this.actualVModel.filter(item => item !== this.value));
                        }
                        else {
                            // if not exist, append it
                            this.emit(this.actualVModel.concat(this.value));
                        }
                    }
                    else {
                        // String type v-model
                        if(this.$_legoSegmentWrapper&&this.$_legoSegmentWrapper.clearable) {
                            this.emit(this.actualVModel===this.value ? '' : this.value);
                        } else {
                            this.emit(this.value);
                        }
                    }
                }
            },
            emit(val) {
                if(this.$_legoSegmentWrapper) {
                    this.$_legoSegmentWrapper.emit(val);
                } else {
                    // $ver: v0.1.2
                    // $arg: updated v-model value
                    // v-model에 설정된값(checked)을 업데이트합니다.
                    // # update v-model value(checked props).
                    this.$emit('input', val);
                }
            }
        }
    };

</script>
