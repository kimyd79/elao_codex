import legoValidateWatcher from "./legoValidateWatcher.vue";
export default {
    install(Vue){
        Vue.component(legoValidateWatcher.name, legoValidateWatcher);
    }
};