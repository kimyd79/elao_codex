<script>
import legoValidator from '../../../mixins/legoValidator/legoValidator.js';

export default {
    name: 'lego-validate-watcher',
    props: {
        additionalObjs: Array
    },
    data() {return {
        watchObjs: [],
        validateResult: undefined
    }},
    computed: {
        hasErrorWatcher() {
            let rtn = [];
            this.watchObjs.forEach(target => {
                rtn.push(target.hasError);
            });
            return rtn;
        }
    },
    watch: {
        hasErrorWatcher(hasErrArray) {
            // CHECKME: is watching executed well? even if deep watch is not applied.
            if(hasErrArray.indexOf(true) === -1) {
                // all descendants valid or not validated yet
                this.validateResult = true;
                this.$emit('validated', this.validateResult);
            } else {
                // one or more of validatable descendant has error
                let rtn = [];
                for (let index = 0; index < hasErrArray.length; index++) {
                    if(hasErrArray[index] === true) {
                        rtn.push(this.watchObjs[index].errorMessage);
                    }
                }
                // return array of all error messages from descendant
                this.validateResult = rtn;
                this.$emit('validated', this.validateResult);
            }
        }
    },
    mounted() {
        this.searchValidatableObjs();
    },
    methods: {
        validate() {
            this.searchValidatableObjs();
            return legoValidator.validate(this.watchObjs);
        },
        isValid() {
            this.searchValidatableObjs();
            return legoValidator.isValid(this.watchObjs);
        },
        clearValidation() {
            this.searchValidatableObjs();
            legoValidator.clearValidation(this.watchObjs);
        },
        searchValidatableObjs() {
            this.watchObjs = legoValidator.searchValidatableObjs(this);
            if(this.additionalObjs) {this.watchObjs = this.watchObjs.concat(this.additionalObjs)}
        },
    },
    render() {
        return this.$scopedSlots.default({
            validateResult: this.validateResult,
            validate: this.validate,
            isValid: this.isValid,
            clearValidation: this.clearValidation
        });
    }
}
</script>