<template>
    <div class="lego-counter lego-input" :class="inputClass">
        <lego-icon-button class="lego-counter__button lego-button--minus" 
                v-if="isButton" key="first" v-bind="buttonSize" 
                :disabled="disabled || readonly || !decreasable"
                @click="decreaseNum">remove</lego-icon-button>
        <input class="lego-counter__input"
               type="number"
               ref="input"
               :min="$_min"
               :max="$_max"
               :step="step"
               v-model="currentValue"
               :placeholder="placeholder"
               :disabled="disabled || (!decreasable && !increasable)"
               :readonly="readonly || !editable"
               autocomplete="off"
               @input="input"
               @blur="blur"
               @change="change"
               @keyup.enter="enterHandler"/>
        <lego-icon-button class="lego-counter__button lego-button--plus" v-if="isButton"
            key="second" v-bind="buttonSize" :disabled="disabled || readonly || !increasable"
            @click="increaseNum">add</lego-icon-button>
        <div class="lego-counter__updown-wrapper" v-if="isUpDown" >
            <div class="lego-counter__updown-upper" key="second" borderless :disabled="disabled || readonly || !increasable" @click="increaseNum"/>
            <hr  class="lego-counter__updown-divider">
            <div class="lego-counter__updown-lower" key="first" borderless :disabled="disabled || readonly || !decreasable" @click="decreaseNum"/>
        </div>
    </div>
</template>

<script>
    const isNaN = Number.isNaN || window.isNaN;
    const REGEXP_NUMBER = /^-?(?:\d+|\d+\.\d+|\.\d+)(?:[eE][-+]?\d+)?$/;
    const REGEXP_DECIMALS = /\.\d*(?:0|9){10}\d*$/;
    const normalizeDecimalNumber = (value, times = 100000000000) => (
        REGEXP_DECIMALS.test(value) ? (Math.round(value * times) / times) : value
    );

    export default {
        name: 'lego-counter',
        model: {
            event: 'change',
        },
        inject: {
            legoInput: {from:'legoInput', default: () => undefined}
        },
        props: {
            // $ver: v0.1.0
            // 가질 수 있는 최소값 입니다.
            // #The minimum value you can have.
            min      : {type: [String,Number],default: -Infinity},

            // $ver: v0.1.0
            // 가질 수 있는 최대값 입니다.
            // #The maximum value you can have.
            max      : {type: [String,Number],default: Infinity},

            // $ver: v0.1.0
            // 증가 혹은 감소 버튼을 클릭했을 때 변경되는 값의 크기입니다.
            // #The size of the value that changes when the increase or decrease button is clicked.
            step     : {type: Number,default: 1,},

            // $ver: v0.1.0
            // $v-model
            // v-model로 바인딩 되는 값으로, 현재 컴포넌트의 값 입니다.
            // #The value to be bound to the v-model, the value of the current component.
            value    : {type: [Number, String],default: NaN,},

            // $ver: v0.1.0
            // 비활성화 여부입니다.
            // #Whether to disable
            // $default: false
            disabled : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 읽기전용 여부입니다.
            // #Whether to read only
            // $default: false
            readonly : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 값이 비어있을 경우 입력칸에 표시할 텍스트 입니다.
            // #The text to display in the input field if the value is empty.
            placeholder: {type: String,default: undefined},
            
            // $ver: v0.1.0
            // 입력 칸 Key-in 수정가능 여부입니다.
            // #Input field Key-in can be modified.
            // $default: true
            editable : {type: Boolean,default: true},

            // $ver: v0.1.0
            // 증가 혹은 감소 버튼의 숨김처리 여부입니다.
            // #Whether the increase or decrease button is hidden
            // $default: false
            noControl: {type: Boolean,default: false},

            // $ver: v0.1.0
            // 증가/감소 버튼을 상하로 표현합니다.
            // #Increase / decrease button up and down.
            // $default: false
            updown   : {type: Boolean,default : false},
            
            // $ver: v0.1.0
            // 입력 칸의 값을 좌측 정렬 합니다.
            // #Left-justify the value in the input field.
            // $default: false
            left     : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 입력 칸의 값을 중앙 정렬 합니다.
            // #Center the values ​​in the input fields.
            // $default: false
            center   : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 입력 칸의 값을 우측 정렬 합니다.
            // #Right-justify the value in the input field.
            // $default: false
            right    : {type: Boolean,default: false},

            // $ver: v0.1.0
            // 컨트롤의 크기입니다. 'large','medium','small'의 값을 입력할 수 있습니다.
            // #The size of the control. You can enter values ​​for 'large', 'medium', 'small'.
            // $deprecated
            size     : {type: String},

            // $ver: v0.1.2
            // 컨트롤의 크기를 Large 사이즈로 조정합니다.
            // #Resize the control to Large size.
            // $default: false
            large: {type:Boolean, default: false},
            // $abbr: large
            lg: {type:Boolean, default: false},
            // $ver: v0.1.2
            // 컨트롤의 크기를 Medium 사이즈로 조정합니다.
            // #Resize the control to Medium size.
            // $default: false
            medium: {type:Boolean, default: false},
            // $abbr: medium
            md: {type:Boolean, default: false},
            // $ver: v0.1.2
            // 컨트롤의 크기를 Small 사이즈로 조정합니다.
            // #Resize the control to Small size.
            // $default: false
            small: {type:Boolean, default: false},
            // $abbr: small
            sm: {type:Boolean, default: false},
        },
        data: function () {
            return {
                default: {
                    size: 'medium',
                    align: 'center'
                },
                currentValue: NaN,
            }
        },
        computed: {
            $_min() {return this.min===-Infinity?this.min:parseInt(this.min);},
            $_max() {return this.max===Infinity?this.max:parseInt(this.max);},
            isButton() {return !this.noControl && !this.updown},
            isUpDown() {return !this.noControl && this.updown},
            lowerButtonStyle(){
                return "lego-counter__button lego-button--lower ";
            },
            upperButtonStyle(){
                return "lego-counter__button lego-button--upper"
            },
            increasable() {
                const num = this.currentValue;
                return isNaN(num) || num < this.$_max;
            },
            decreasable() {
                const num = this.currentValue;
                return isNaN(num) || num > this.$_min;
            },
            cSize() {
                if(this.size) {
                    console.warn("[LEGO-COUNTER] props:size was deprecated from v0.1.2. use large, medium or small flag props.");
                    return this.size;
                }
                if(this.large || this.lg) return 'large';
                if(this.medium || this.md) return 'medium';
                if(this.small || this.sm) return 'small';
                if(this.legoInput) return this.legoInput.size;
                return this.default.size;
            },
            inputClass() {
                let clazz = [];
                clazz.push('lego-counter--'+this.cSize);

                if (this.left) {
                    clazz.push("lego-counter--left");
                } else if (this.right) {
                    clazz.push("lego-counter--right");
                } else if (this.center){
                    clazz.push("lego-counter--center");
                } else {
                    clazz.push('lego-counter--'+this.default.align)
                }
                if (this.disabled) {
                    clazz.push("lego-counter--disabled");
                } else if (this.readonly) {
                    clazz.push("lego-counter--readonly");
                }
                if (!this.editable) {
                    clazz.push('lego-counter--not-editable');
                }
                return clazz;
            },
            buttonSize() {
                let buttonSize = {};
                buttonSize[this.cSize] = true;
                return buttonSize;
            },
        },
        watch: {
            value: {
                immediate: true,
                handler(newValue, oldValue) {
                    if (
                        // Avoid triggering change event when created
                        !(isNaN(newValue) && typeof oldValue === 'undefined')
                        // Avoid infinite loop
                        && newValue !== this.currentValue
                    ) {
                        this.setValue(newValue);
                    }
                },
            },
        },
        methods: {
            input(e) {
                // $ver: v0.1.0
                // $return: value
                // 입력 칸에 직접 입력할 때, 현재 값을 반환하며 이벤트를 발생시킵니다.
                // #When typing directly into the input field, returns the current value and fires an event.
                this.$emit('input',this.currentValue);
            },
            blur(e) {
                // $ver: v0.1.2
                // $return: $event
                // 입력칸에서 focus out될 때 이벤트를 발생시킵니다
                // #Raises an event when it's focused out of the input field
                this.$emit('blur',e);
            },
            change(event) {
                this.setValue(Math.min(this.$_max, Math.max(this.$_min, event.target.value)));
            },

            // @vuese
            // $ver: v0.1.0
            // $return: N/A
            // 값을 한 단계 증가시킵니다. 
            // #Increment the value by one step.
            increaseNum() {
                if (!this.readonly && !this.disabled) {
                    if (this.increasable) {
                        let { currentValue } = this;
                        if (isNaN(currentValue)) {
                            currentValue = 0;
                        }
                        this.setValue(Math.min(this.$_max, Math.max(
                            this.$_min,
                            normalizeDecimalNumber(currentValue + this.step),
                        )));
                    }
                }
            },

            // @vuese
            // $ver: v0.1.0
            // $return: N/A
            // 값을 한 단계 감소시킵니다. 
            // #Decreases the value by one step.
            decreaseNum() {
                if (!this.readonly && !this.disabled) {
                    if (this.decreasable) {
                        let { currentValue } = this;
                        if (isNaN(currentValue)) {
                            currentValue = 0;
                        }
                        this.setValue(Math.min(this.$_max, Math.max(
                            this.$_min,
                            normalizeDecimalNumber(currentValue - this.step),
                        )));
                    }
                }
            },

            // @vuese
            // $ver: v0.1.0
            // $arg: Number
            // $return: N/A
            // 입력된 값으로 변경합니다.
            // #Change to the entered value.
            setValue(value) {
                const oldValue = this.currentValue;
                if (this.$_min <= this.$_max) {
                    value = Math.min(this.$_max, Math.max(this.$_min, value));
                }
                this.currentValue = parseInt(value);
                if (value === oldValue) {
                    // Force to override the number in the input box (#13).
                    this.$refs.input.value = value;
                }
                // $ver: v0.1.0
                // $return: 현재 값, 기존 값
                // 값이 변경될 때 이벤트를 발생시킵니다.
                // #Raises an event when the value changes.
                this.$emit('change', value, oldValue);
            },
            enterHandler() {
                this.setValue(this.currentValue);
                // $ver: v0.1.0
                // $return: 현재 값
                // 입력 칸에서 엔터키 누를 시 이벤트를 발생시킵니다.
                // #Fires an event when the Enter key is pressed in the input box.
                this.$emit('enter', this.currentValue);
            },
        }
    };

</script>