import legoCounter from "./legoCounter.vue";
export default {
    install(Vue){
        Vue.component(legoCounter.name, legoCounter);
    }
};