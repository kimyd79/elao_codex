<template>
    <div class="lego-text-field lego-input" :class="textfieldClass">
        <textarea v-if="textarea"
                  ref="input"
                  v-model="txtField"
                  class="lego-text-field__textarea"
                  :rows="$_rows"
                  :placeholder="placeholder"
                  :disabled="disabled"
                  :readonly="readonly"
                  :onfocus="readonly&&'this.blur();'"
                  :style="{resize: resize}"
                  :tabindex="tabindex"
                  v-on="listenersWithoutInput"
                  @keyup.enter="enterHandler"
                  @blur="validateOnEvent"></textarea>
        <input v-else
               ref="input"
               v-model="txtField"
               :type="inputType"
               :class="inputClass"
               :placeholder="placeholder"
               :disabled="disabled"
               :readonly="readonly"
               :onfocus="readonly&&'this.blur();'"
               :tabindex="tabindex"
               v-on="listenersWithoutInput"
               @keyup.enter="enterHandler"
               @blur="validateOnEvent"/>
        <div class="lego-text-field__icon-wrap" v-show="withIcon">
            <lego-icon class="lego-text-field__icon-wrap__icon" @click="toggleIcon">{{icon}}</lego-icon>
        </div>
        <div v-if="messageShow || counter"
             class="lego-text-field__message lego-validator__message"
             :class="messageClass"><!--glue
        -->{{messageShow}}<!--glue
        --><div v-if="counter" class="lego-text-field__counter"><!--glue
            -->{{typeof(txtField) === 'string'?txtField.length:0}}/{{counter}}<!--glue
        --></div><!--glue
    --></div>
    </div>
</template>

<script>
import legoValidatorMixin from '../../../mixins/legoValidator/legoValidatorMixin.vue';

export default {
    name: 'lego-text-field',
    mixins: [legoValidatorMixin],
    inject: {
        legoInput: {from:'legoInput', default: () => undefined}
    },
    props: 
    /* [FROM VALIDATOR] */
    // rules
    // disabled
    // lazy
    // noShake
    /********************/
    {
        // $ver: v0.1.0
        // $v-model
        // v-model로 바인딩되는 값으로, 텍스트필드의 값과 연계됩니다.
        // #The value bound to v-model, associated with the value of the textfield.
        value: [String,Number],

        // $ver: v0.1.0
        // 텍스트 필드가 빈 값일 때 표시할 문자열 입니다.
        // #The string to display when the text field is empty.
        placeholder: {type: String},

        // $ver: v0.1.0
        // Guide 메시지로 표시할 문자열 입니다.
        // #The string to display as the guide message.
        guideMessage: {type: String, default: undefined},
        
        // $ver: v0.1.0
        // Success 메시지로 표시할 문자열 입니다.
        // #The string to display as a Success message.
        successMessage: {type: String, default: undefined},


        // $ver: v0.1.0
        // 다중라인 텍스트필드 형태로 전환합니다.
        // #Convert to a multiline text field.
        // $default: false
        textarea: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 다중라인 텍스트필드일 때 표시될 행의 숫자 입니다.
        // #The number of lines to display when in a multiline text field.
        rows: {type: [String, Number], default: 3},

        // $ver: v0.1.0
        // 다중라인 텍스트필드일 때 리사이즈 기능 동작 여부입니다. 우측하단을 선택/드래그 하여 리사이즈를 할 수 있습니다.
        // #Whether the resize function works for multiline text fields. You can resize by selecting and dragging the lower right corner.
        resize: {type: String, default: 'none'},

        // $ver: v0.1.0
        // 컴포넌트를 Border 형태로 표현합니다.
        // #Represents a component in the form of a Border.
        // $default: false
        border: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 컴포넌트를 Underline 형태로 표현합니다.
        // #Represents a component in underline form.
        // $default: false
        underline: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 가이드, 성공, 안내메시지 표현 형태 속성입니다. 'heavy', 'light' 속성을 지정할 수 있습니다.
        // #Guide, Success, Announcement appearance attributes. You can specify the 'heavy' and 'light' attributes.
        messageStyle: {
            type: String,
            validator: function(value) {
                return ['heavy', 'light'].indexOf(value) !== -1;
            },
            default: 'heavy'
        },


        // $ver: v0.1.0
        // 텍스트필드 초기화 기능 사용 여부입니다. 지정 시 초기화 아이콘이 나타나며, 클릭 시 현재 입력된 값을 초기화 할 수 있습니다.
        // #Whether to use the text field initialization function. Initialization icon appears when it is designated and can be initialized when clicked.
        // $default: false
        clearable: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 비밀번호 입력형태로 표현합니다. 숨김 값으로 입력되며, 우측 아이콘을 클릭하여 입력 값을 볼 수 있습니다.
        // #Expressed in password input form. It is entered as hidden value and you can see the input value by clicking the icon on the right.
        // $default: false
        password: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 비활성화 상태로 전환합니다.
        // #Switch to inactive state.
        // $default: false
        disabled: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 읽기전용 상태로 전환합니다. 비활성화와는 다르게 커서를 위치시킬 수 있으며, 드래그로 문자열을 선택할 수 있습니다.
        // #Switch to read-only state. Unlike deactivation, you can position the cursor and drag to select a string.
        // $default: false
        readonly: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 우측에 검색 아이콘을 표현합니다. 아이콘 클릭 시 'click-icon' 이벤트를 발생 시킵니다.
        // #The search icon is displayed on the right side. Raises 'click-icon' event when clicking icon.
        // $default: false
        searchable : {type: Boolean, default: false},

        // $ver: v0.1.0
        // Mask 표현식 입니다. #(숫자), A(대문자), a(소문자), N(숫자/대문자), n(숫자/소문자)와 특수기호의 조합으로 표현합니다.
        // #Mask expression. Expressed as a combination of # (number), A (uppercase), a (lowercase), N (number / uppercase), n (number / lowercase), and special symbols.
        // $default: null
        mask: {type: String, default: null},

        // $ver: v0.1.0
        // 입력될 문자열의 최대 길이 값을 지정합니다. legoValidator 연계로 실제 값 유효성 검사를 수행해야 합니다. 이 속성이 입력되면 우측 하단에 입력된 문자열의 길이를 표시합니다.
        // #Specifies the maximum length value of the string to be entered. You must perform actual value validation with the legoValidator linkage. 
        // #When this property is entered, it displays the length of the entered text in the lower right corner.

        counter: {type: [String, Number], default: undefined},
        
        // $ver: v0.1.0
        // 컴포넌트를 Large 크기로 조정합니다.
        // #Resize the component to large size.
        // $default: false
        large: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 컴포넌트를 Medium 크기로 조정합니다.
        // #Resize the component to medium size.
        // $default: false
        medium: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 컴포넌트를 Small 크기로 조정합니다.
        // #Resize the component to Small.
        // $default: false
        small: {type: Boolean, default: false},

        // $ver: v0.1.2
        // tabindex를 설정합니다.
        // #Set tabindex.
        tabindex: {type:[Number,String]},
        
        // $ver: v0.1.0
        // large 속성의 약어입니다.
        // $abbr: large
        lg: {type: Boolean, default: false}, // large

        // $ver: v0.1.0
        // medium 속성의 약어입니다.
        // $abbr: medium
        md: {type: Boolean, default: false}, // medium

        // $ver: v0.1.0
        // small 속성의 약어입니다.
        // $abbr: small
        sm: {type: Boolean, default: false}, // small

        // $ver: v0.1.0
        // password 속성의 약어입니다.
        // $abbr: password
        pw: {type: Boolean, default: false}, // password

        // $ver: v0.1.0
        // readonly 속성의 약어입니다.
        // $abbr: readonly
        ro: {type: Boolean, default: false}, // readonly

        // $ver: v0.1.0
        // textarea 속성의 약어입니다.
        // $abbr: textarea
        ta: {type: Boolean, default: false}, // textarea

        // $ver: v0.1.0
        // border 속성의 약어입니다.
        // $abbr: border
        bor: {type: Boolean, default: false}, // border

        // $ver: v0.1.0
        // underline 속성의 약어입니다.
        // $abbr: underline
        ul: {type: Boolean, default: false}, // underline
    },
    data: function () {
        return {
            /* [FROM VALIDATOR] */
            // hasError
            // errorMessage
            // showValid
            // shake
            /********************/
            default: {
                size: 'medium',
                style: 'border'
            },
            txtField: '', // shown in <input/> tag
            realText: '', // emitted data to parent component. if you use mask props, realText may differ from txt Field
            visible: false,
            predefinedMasks: {
                'phone': '### - ### - ####', /* phone : ### - ### - #### or #### - #### - #### */
                'credit-card': '#### - #### - #### - ####',
                'date': '##/##/####',
                'date-with-time': '##/##/#### ##:##',
                'social': '###-##-####',
                'time': '##:##',
                'time-with-seconds': '##:##:##'
            },
            allowedMasks: {
                '#': {
                    test: char => char.match(/[0-9]/),
                    convert: char => char
                },
                'A': {
                    test: char => char.match(/[A-Z]/i),
                    convert: char => char.toUpperCase()
                },
                'a': {
                    test: char => char.match(/[a-z]/i),
                    convert: char => char.toLowerCase()
                },
                'N': {
                    test: char => char.match(/[0-9A-Z]/i),
                    convert: char => char.toUpperCase()
                },
                'n': {
                    test: char => char.match(/[0-9a-z]/i),
                    convert: char => char.toLowerCase()
                }
            }
        };
    },
    computed: {
        /* [FROM VALIDATOR] */
        // isValidatable
        // el
        validateTarget() {return this.value;}, // validation setting
        /********************/

        $_size() {
            if(this.large || this.lg) {return 'large'}
            if(this.medium || this.md) {return 'medium'}
            if(this.small || this.sm) {return 'small'}
            if(this.legoInput) {return this.legoInput.size}
            return this.default.size;
        },
        $_style() {
            if(this.border || this.bor) {return 'border'}
            if(this.underline || this.ul) {return 'underline'}
            return this.default.style;
        },
        $_rows() {return parseInt(this.rows);},
        inputType() {
            if ((this.password||this.pw) && !this.visible) {return 'password';}
            return 'text';
        },
        withIcon() {
            if(this.textarea) {return false;}
            if ((this.password || this.pw) || (this.clearable && this.txtField)) {return true;}
            if (this.searchable) {return true;}
            return false;
        },
        icon() {
            if (this.password||this.pw) {return this.visible ? 'hide_password' : 'display_password';}
            if (this.clearable) {return 'close';}
            if (this.searchable) {return 'search';}
            return '';
        },
        textfieldClass() {
            let clazz = [];
            clazz.push('lego-text-field--'+this.$_size);
            clazz.push('lego-text-field--'+this.$_style);

            if(this.errorMessage) {clazz.push('lego-text-field--has-message')}
            if(this.hasError === true) {clazz.push('lego-validator--error')}
            if(this.showValid && this.hasError === false) {clazz.push('lego-validator--valid')}
            if(this.shake) {clazz.push('lego-validator--shake')}
            return clazz;
        },
        withPwd(){
            if(this.password || this.pw) {return true;}
            return false;
        },
        inputClass() {
            return {
                'lego-text-field__input': true,
                'lego-text-field__input--with-icon': this.withIcon,
                'lego-text-filed__input--only-eng': this.withPwd
            };
        },
        listenersWithoutInput() {
            delete this.$listeners.input;
            return this.$listeners;
        },
        messageShow() {
            if(this.hasError === undefined) {
                return this.guideMessage;
            }
            if (this.hasError === true) {
                return this.errorMessage;
            }
            if (this.hasError === false) {
                return this.successMessage || this.guideMessage;
            }
            return undefined;
        },
        messageClass() {
            return ['lego-text-field__message--'+this.messageStyle];
        },

    },
    watch: {
        successMessage: {
            immediate: true,
            handler(val) {
                this.showValid = !!val;
            }
        },

        txtField(newText, oldText) {
            if (newText === oldText) {
                return;
            }
            if (this.mask == null) {
                this.realText = newText;
                // $ver: v0.1.0
                // $arg: updated value
                // 입력 값이 변경될 때, 변경된 값을 파라미터로 이벤트를 발생시킵니다.
                // #When the input value is changed, an event is triggered with the changed value as a parameter.
                this.$emit('input', newText);
                return;
            } else {
                if (this.mask === 'phone') {
                    newText = this.onlyNums(newText);
                    if (newText.length < 11) {
                        this.predefinedMasks['phone'] = '### - ### - ####';
                    } else {
                        this.predefinedMasks['phone'] = '### - #### - ####';
                    }
                }
                this.txtField = this.applyMask(newText, this.mask);
                this.$emit('input', String(this.realText));
                return;
            }
        },
        value: {
            immediate: true,
            handler(val) {
                if (this.mask === 'phone') {
                    if (val.length < 11) {
                        this.predefinedMasks['phone'] = '### - ### - ####';
                    } else {
                        this.predefinedMasks['phone'] = '### - #### - ####';
                    }
                }
                if (this.mask) {
                    this.txtField = this.applyMask(val, this.mask);
                } else {
                    this.txtField = val;
                }
            }
        }
    },
    methods: {
        /* [FROM VALIDATOR] */
        // validate()        --+
        // isValid()         --+-- exposed methods for manual validate control
        // clearValidation() --+
        // vavlidateOnEvent() -> should be set by each component which uses legoValidatorMixin
        /********************/

        onlyNums(text) {
            let ret = '';
            for (var i = 0; i < text.length; i++) {
                if (this.allowedMasks['#'].test(text[i])) {
                    ret += text[i];
                }
            }
            return ret;
        },
        applyMask(text, mask) {
            const predefined = this.predefinedMasks[mask];
            const masks = predefined || mask;
            const masked = masks.split('');
            let textIdx = 0;
            let maskIdx = 0;
            let maskedText = '';
            this.realText = '';
            while (maskIdx < masked.length && textIdx < text.length) {
                let m = masked[maskIdx];
                let c = text[textIdx];
                if (this.isMask(m)) {
                    if (this.allowedMasks[m].test(c)) {
                        textIdx++;
                        maskIdx++;
                        this.realText += c;
                        maskedText += this.allowedMasks[m].convert(c);
                    } else {
                        return maskedText;
                    }
                } else {
                    if (m === '%') {
                        maskIdx++;
                        if(masked.length === maskIdx) {
                            console.warn('[LEGO-TEXT-FIELD] % is escape character in mask. If you want to show % character, use %% instead.');
                        } else {
                            m = masked[maskIdx];
                        }
                    }
                    if (c === m) {
                        textIdx++;
                    }
                    maskIdx++;
                    maskedText += m;
                }
            }
            return maskedText;
        },
        isMask: function (mask) {
            return this.allowedMasks.hasOwnProperty(mask);
        },
        toggleIcon: function () {
            if (this.password) {
                this.visible = !this.visible;
            } else if (this.clearable) {
                this.txtField = '';
                this.$emit('input', '');
            } else if (this.searchable){
                // $ver: v0.1.0
                // $arg: value
                // searchable 속성으로 표시된 검색아이콘을 클릭할 때, 현재 값을 파라미터로 이벤트를 발생시킵니다.
                // #When clicking on the search icon marked with the searchable property, an event is triggered with the current value as a parameter.
                this.$emit('click-icon', this.txtField);
            }
        },
        enterHandler: function () {
            // $ver: v0.1.0
            // $arg: value
            // 엔터 키 입력 시, 현재 값을 파라미터로 이벤트를 발생시킵니다.
            // #When enter key is pressed, an event is triggered with the current value as a parameter.
            this.$emit('enter', this.txtField);
        },
        focus() {this.$refs.input.focus();},
        blur() {this.$refs.input.blur();}
    },
};
</script>