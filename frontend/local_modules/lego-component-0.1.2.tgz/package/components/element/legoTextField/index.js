import legoTextField from "./legoTextField.vue";
export default {
    install(Vue){
        Vue.component(legoTextField.name, legoTextField);
    }
};