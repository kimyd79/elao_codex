import legoCard from './legoCard.vue';

export default {
    install(Vue) {
        Vue.component(legoCard.name, legoCard);
    }
};