<template>
    <div class="lego-card" :style="cardStyle">
        <!--
            $ver: v0.1.0
            카드 내부 영역입니다. 예제에서 사용된 class를 활용하여 카드 내부를 표현할 수 있습니다.
            #Area inside the card. The class used in the example can be used to express the inside of the card.
        -->
        <slot></slot>
    </div>
</template>

<script>
    export default {
        name: 'legoCard',
        props: {
            // $ver: v0.1.0
            // 카드의 폭을 지정합니다. 단위는 px 입니다.
            // #Specify the width of the card. The unit is px.
            width : { type: Number, default: 0 },

            // $ver: v0.1.0
            // 카드의 높이를 지정합니다. 단위는 px 입니다.
            // #Specify the height of the card. The unit is px.
            height: { type: Number, default: 0 }
        },
        data() {return {}},
        computed: {
            cardStyle() {
                let cardStyle = {};
                if(this.height) cardStyle['height'] = this.height + 'px';
                if(this.width ) cardStyle['width']  = this.width + 'px';
                return cardStyle;
            }
        }
    };


</script>