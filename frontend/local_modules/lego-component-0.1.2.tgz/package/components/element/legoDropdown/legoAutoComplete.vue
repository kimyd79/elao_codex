<template>
    <div class="lego-dropdown" :class="dropdownClass" :style="[dropdownWidth, dropdownHeight]">
        <div class="lego-dropdown__title" ref="ddddd" v-dropdown-click-outside="toggleItemOuter" @click.stop="toggleItem">
            <input v-if="autocomplete" class="lego-dropdown__autocomplete" type="text" :placeholder="placeholder"
                :value="inputValue" @input="onChangeInput" @keydown.tab.prevent="complete(0)" :style="dropdownTitleStyle" >
            <div v-else class="lego-dropdown__selected" :style="dropdownTitleStyle" :title="selectedTitle">{{ selectedTitle }}</div>
            <lego-icon class="lego-dropdown__icon" icon="expand_menu" iconSize="8px" :style="caretStyle"/>
        </div>
        <div class="lego-dropdown__items" v-show="isItemShowing" :style="[dropdownWidth, dropdownItemsMarginTop]">
            <div class="lego-dropdown__item" v-for="(item, idx) in items" @click.stop="clickItem(item, idx)" :key="idx"
                :class="{'lego-dropdown__selected': isSelectedItem(idx) }">
                <span>{{getText(item)}}</span>
            </div>
        </div>
    </div>
</template>

<script>
import arrUtil from "@/util/static/arrayUtil";

const UNSELECT_DROPDOWN_TITLE = "Select";
const DEFAULT_PLACEHOLDER = "Input value";
const DEFAULT_ITEM_TEXT  = "text";
const DEFAULT_ITEM_VALUE = "value";

const NOT_SELECTED = -1;
const NEED_CHECK   = -2;

export default {
    name :"lego-dropdown",
    props: {
        items: [Array, Object],
        value: [Object,String,Number], /*value for v-model */
        placeholder  : {type: String , default: DEFAULT_PLACEHOLDER},
        autocomplete : {type: Boolean, default: false},
        itemText     : {type: String , default: DEFAULT_ITEM_TEXT},
        itemValue    : {type: String , default: DEFAULT_ITEM_VALUE},
        width        : {type: [Number, String],default: 70}, /*px*/
        height       : {type: [Number, String],default: 32}, /*px*/
        disabled     : {type: Boolean, default: false},
    },
    data(){return {
        inputValue     : '',
        isItemShowing  : false,
        itemsMarginTop : 0,
        //currentItemIdx : NOT_SELECTED,
    }},
    computed: {
        selectedTitle () {
            if(this.currentItemIdx === NOT_SELECTED) return UNSELECT_DROPDOWN_TITLE;
            let val = this.items[this.currentItemIdx];
            return this.getText(val);
        },
        currentItemIdx() {
            return this.items.findIndex(it => this.getValue(it) === this.value);
        },
        dropdownWidth() { return {'width'  : this.getNumber(this.width)+'px'}; },
        dropdownHeight(){ return {'height' : this.getNumber(this.height)+'px'}; },
        dropdownClass() { return {'lego-dropdown__disabled':this.disabled} },
        caretStyle() {
            let style = {};
            if (this.isItemShowing) {
                style['transform'] = 'rotate(-180deg)';
            }
            style['transition-duration'] = '0.3s';
            return style;
        },
        dropdownItemsMarginTop(){return {}},
        dropdownTitleStyle() {
            let height = this.getNumber(this.height) - 2; /* minus 2px for border */
            return {"height":height+"px","line-height":height+"px"};
        },
    },
    created() {},
    methods: {
        getText(item)  {
            if(item[this.itemText] === undefined || item[this.itemText] === null) { return item; }
            else { return item[this.itemText]; }
        },
        getValue(item) {
            if(item[this.itemValue] === undefined || item[this.itemValue] === null) { return item; }
            else { return item[this.itemValue]; }
        },
        getNumber(str) {
            let v = str;
            if(isNaN(v)) {
                v = v.replace(/[^0-9]/g,"");
            }
            return parseInt(v);
        },
        clickItem(item, idx){
            this.$emit('input', this.getValue(item));
            if(this.autocomplete){
                this.inputValue = this.getText(this.items[idx])
            }
            this.toggleItem();
            // CAUTION!! go to COMPUTED :: currentItemIdx, selectedTitle
        },
        toggleItem (event) {
            // 1. onOpen item?
            if(!this.isItemShowing){ /* no op? */
                this.itemsMarginTop = (event.target.parentElement.offsetHeight - 1);
            }
            // 2. toggle flag
            this.isItemShowing = !this.isItemShowing
        },
        toggleItemOuter () {
            this.isItemShowing = false
        },
        onChangeInput(e){
            this.inputValue = e.target.value;
            if(this.inputDelay){
                this.inputDelay = false;
                setTimeout(() => {
                    this.$emit('changeInput',this.inputValue)
                    this.inputDelay = true;
                }, 500);/* Delay 0.5s */
            }
        },
        complete(i) {
            this.inputValue = this.getText(this.items[i]);
        },
        isSelectedItem (idx) {
            return idx === Number(this.currentItemIdx)
        },
    },
    directives: {
        'dropdown-click-outside': {
            bind: function(el, binding) {
                // Define Handler and cache it on the element
                const handler = (e) => {
                    if ((!el.contains(e.target) && el !== e.target)) {
                        binding.value(e)
                    }
                }
                el.__vueClickOutside__ = handler
                // add Event Listeners
                document.addEventListener('click', handler)
            },
            unbind: function(el, binding) {
                // Remove Event Listeners
                document.removeEventListener('click', el.__vueClickOutside__)
                el.__vueClickOutside__ = null
            }
        }
    }
}

</script>
