<template>
    <div class="lego-drop-holder lego-input" :class="dropdownClass">
        <div class="lego-drop-holder__holder" v-dropdown-click-outside="toggleItemOuter" @click="toggleItem">
            <slot/>
        </div>
        <div class="lego-dropdown__items" v-show="isItemShowing" :class="itemsClass" :style="itemsWidth">
            <div class="lego-dropdown__item" v-for="(item, idx) in items" @click.stop="clickItem(item)" :key="idx">
                <div class="lego-dropdown__label" :class="{'lego-dropdown__selected': isSelectedItem(item) }">
                    <span>{{getText(item)}}</span>
                    <lego-icon v-if="item.childItems" class="lego-dropdown__label-caret" size="8px">expand_menu</lego-icon>
                </div>
                
                <div class="lego-dropdown__child-items" v-if="item.childItems">
                    <div class="lego-dropdown__child-item lego-dropdown__label"
                        v-for="(child, childIdx) in item.childItems" :class="{'lego-dropdown__selected': isSelectedItem(child) }" :key="idx + '.' + childIdx"
                        @click.stop="clickItem(child)" :style="itemsWidth">
                        <span>{{getText(child)}}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
const UNSELECT_DROPDOWN_TITLE = "Select";
const DEFAULT_PLACEHOLDER = "Input value";
const DEFAULT_ITEM_TEXT  = "text";
const DEFAULT_ITEM_VALUE = "value";

const NOT_SELECTED = -1;
const NEED_CHECK   = -2;

import legoDropdown from './legoDropdown';

export default {
    name :"lego-drop-holder",
    extends: legoDropdown,
    props: {
        rightAlign  : {type: Boolean, default: false},
        labelNoWrap : {type: Boolean, default: false},
    },
    computed: {
        itemsClass() {
            let clazz = [];
            if(this.hasChildItems) {clazz.push("lego-drop-holder__items--has-child-items");}
            if(this.rightAlign)    {clazz.push("lego-drop-holder__items--right-align");}
            if(this.labelNoWrap)   {clazz.push("lego-drop-holder__items--label-no-wrap");}
            return clazz;
        },
        dropdownClass() {
            return {
                'lego-drop-holder--disabled': this.disabled,
                'lego-drop-holder--medium': this.$_size === 'medium',
                'lego-drop-holder--small': this.$_size === 'small',
                'lego-validator--error': this.hasError === true,
                'lego-validator--valid': this.showValid && this.hasError === false,
                'lego-validator--shake': this.shake
            }
        },
    },
}

</script>