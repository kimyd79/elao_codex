<template>
    <div class="lego-dropdown lego-input" :class="dropdownClass" :style="[dropdownWidth, dropdownHeight]">
        <div class="lego-dropdown__title" v-dropdown-click-outside="toggleItemOuter" @click="toggleItem">
            <div class="lego-dropdown__selected" :style="dropdownTitleStyle" :title="getText(selItem)">
                <span><!-- 
                    $ver: v0.1.2
                    드랍다운 항목 내부에 위치하는 영역 입니다.
                    #This area is located inside the dropdown item.
                --><slot name="itemText" :item="selItem" :getText="getText">{{getText(selItem)}}</slot>
                </span>
            </div>
            <lego-icon-wrapper class="lego-dropdown__title-icon">
                <lego-icon class="lego-dropdown__icon" icon="expand_menu" size="10px" :style="caretStyle"/>
            </lego-icon-wrapper>
        </div>
        <div class="lego-dropdown__items" v-show="isItemShowing" :class="itemsClass" :style="itemsWidth">
            <div class="lego-dropdown__item" v-for="(item, idx) in items" @click.stop="clickItem(item)" :key="idx">
                <div class="lego-dropdown__label" :class="{'lego-dropdown__selected': isSelectedItem(item) }">
                    <span><slot name="itemText" :item="item" :getText="getText">{{getText(item)}}</slot></span>
                    <lego-icon-wrapper v-if="item.childItems" style="width:16px;margin-left:12px;">
                        <lego-icon class="lego-dropdown__label-caret" size="10px">expand_menu</lego-icon>
                    </lego-icon-wrapper>
                </div>
                
                <div class="lego-dropdown__child-items" v-if="item.childItems" :style="itemsWidth">
                    <div class="lego-dropdown__item lego-dropdown__child-item" v-for="(child, childIndex) in item.childItems" :key="idx + '.' + childIndex"
                         @click.stop="clickItem(child)">
                        <div class="lego-dropdown__label"  :class="{'lego-dropdown__selected': isSelectedItem(child) }">
                            <span><slot name="itemText" :item="child" :getText="getText">{{getText(child)}}</slot></span>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div v-if="messageShow"
             class="lego-dropdown__message lego-validator__message"
             :class="messageClass"><!--glue
        -->{{messageShow}}<!--glue
    --></div>
    </div>
</template>

<script>
import legoValidatorMixin from '../../../mixins/legoValidator/legoValidatorMixin.vue';

const UNSELECT_DROPDOWN_TITLE = "Select";
const DEFAULT_PLACEHOLDER = "Input value";
const DEFAULT_ITEM_TEXT  = "text";
const DEFAULT_ITEM_VALUE = "value";

const NOT_SELECTED = -1;
const NEED_CHECK   = -2;

export default {
    name :"lego-dropdown",
    mixins: [legoValidatorMixin],
    inject: {
        legoInput: {from:'legoInput', default: () => undefined}
    },
    props: {
        // $ver: v0.1.0
        // 선택가능 목록에 대한 data입니다.
        // Array type으로 전달될 경우 각각의 element는 이름과 값을 가지는 Object형태를 가져야합니다.
        // item-text, item-value의 기본값이 'text', 'value'이므로 {text: 'label', value: 'value'} 형태를 사용할 수 있습니다.
        // #The data for the selectable list.
        // #When passed as an array type, each element must have an Object type with a name and a value.
        // #You can use the form {text: 'label', value: 'value'} because the item-text and item-value defaults to 'text' and 'value'.
        items: {
            type:[Array, Object]
        },
        // $ver: v0.1.0
        // $v-model
        // 드랍다운 리스트의 선택된 값 입니다.
        // #The selected value in the drop-down list.
        value: {
            type:[Object,String,Number]
        },
        // $ver: v0.1.0
        // $default: 'Input value'
        // 아무런 data도 선택되지 않았을 때 기본적으로 출력되는 메시지입니다.
        // #This message is displayed by default when no data is selected.
        placeholder : {type: String },
        // $ver: v0.1.0
        // width값을 지정할 수있습니다. 단위는 px입니다
        // #You can specify a width value. Unit is px
        width       : {type: [Number, String] /*px*/},
        // $ver: v0.1.0
        // height값을 지정할 수있습니다. 단위는 px입니다
        // #You can specify a height value. Unit is px
        height      : {type: [Number, String] /*px*/},
        // $ver: v0.1.2
        // $default: 'text'
        // items에 전달된 데이터 Object에서 리스트에 출력될 값을 선택하는 key값입니다.
        // 혹은 함수형태로 전달하여 text build를 수행할 수 있습니다.(v0.1.2 추가됨)
        // #The key value that selects the value to be displayed in the list from the data object passed to items.
        // #Alternatively, you can perform a text build by passing it as a function (Added to v0.1.2).
        itemText    : {
            type: [String, Function],
            default: DEFAULT_ITEM_TEXT
        },
        // $ver: v0.1.0
        // $default: 'value'
        // items에 전달된 데이터 Object에서 item선택시 v-model에 전달될 값을 선택하는 key값입니다.
        // #The key value that selects the value to be passed to the v-model when selecting an item from the data object passed to the items.
        itemValue   : {type: String , default: DEFAULT_ITEM_VALUE},
        // $ver: v0.1.0
        // <em>lego-dropdown</em>컴포넌트가 펼쳐졌을 때 나오는 item리스트의 width를 지정할 수 있습니다. 단위는 px입니다.
        // #You can specify the width of the item list that appears when the <em>lego-dropdown</em> component is expanded. The unit is px.
        itemWidth   : {type: [Number, String] /*px*/},
        // $ver: v0.1.0
        // 상호작용 불가능한 상태를 만듭니다.
        // #Create a non-interactive state.
        disabled    : {type: Boolean, default: false},
        // $ver: v0.1.1
        // 하단에 표시되는 가이드 메시지입니다. 별도의 설정이 없다면 출력되지 않습니다.
        // <em>lego-dropdown</em>은 메시지 출력을 위한 공간을 별도로 점유하지않습니다.
        // 메시지 출력을 원할 경우 공간확보가 필요합니다.
        // #The guide message that appears at the bottom. If there is no setting, no output.
        // #<em>lego-dropdown</em> does not occupy space for message output.
        // #If you want to print the message, you need to make space.
        guideMessage: {type: String, default: undefined},
        // $ver: v0.1.1
        // validate를 통과한 경우 출력되는 메시지입니다.
        // 별도설정이 없다면 가이드 메시지가 출력되거나 아무런 메시지도 출력되지 않습니다.
        // <em>lego-dropdown</em>은 메시지 출력을 위한 공간을 별도로 점유하지않습니다.
        // 메시지 출력을 원할 경우 공간확보가 필요합니다.
        // #The message that is output if validate passes.
        // #If there is no setting, guide message or no message is printed.
        // #<em>lego-dropdown</em> does not occupy space for message output.
        // #If you want to print the message, you need to make space.
        successMessage: {type: String, default: undefined},
        // $ver: v0.1.1
        // 가이드 메시지, 에러메시지, 성공메시지의 스타일을 'heavy', 'light' 두가지 스타일 중 선택할 수 있습니다.
        // #You can select the style of guide message, error message or success message from 'heavy' and 'light'.
        messageStyle: {
            type: String,
            validator: function(value) {
                return ['heavy', 'light'].indexOf(value) !== -1;
            },
            default: 'heavy'
        },
        // $ver: v0.1.2
        // 기본사이즈의 dropdown 컴포넌트를 사용합니다.
        // #Use the default size dropdown component.
        medium: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // $abbr: medium
        md: {
            type:Boolean,
            default: false,
        },
        // $ver: v0.1.2
        // 기본보다 작은 사이즈의 dropdown 컴포넌트를 사용합니다.
        // #Use a smaller dropdown component than the default.
        small: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // $abbr: small
        sm: {
            type:Boolean,
            default: false,
        },
        /* [FROM VALIDATOR] */
        // rules
        // disabled
        // lazy
        // noShake
        /********************/
    },
    data(){return {
        default: {
            size: 'medium',
            placeholder: UNSELECT_DROPDOWN_TITLE
        },
        /* [FROM VALIDATOR] */
        // hasError
        // errorMessage
        // showValid
        // shake
        /********************/

        isItemShowing  : false,
    }},
    computed: {
        /* [FROM VALIDATOR] */
        // isValidatable
        // el
        validateTarget() {return this.value;}, // validation setting
        /********************/

        $_size() {
            if(this.medium || this.md) {return 'medium'}
            if(this.small || this.sm) {return 'small'}
            if(this.legoInput) {return this.legoInput.size}
            return this.default.size;
        },
        messageShow() {
            if(this.hasError === undefined) {
                return this.guideMessage;
            }
            if (this.hasError === true) {
                return this.errorMessage;
            }
            if (this.hasError === false) {
                return this.successMessage || this.guideMessage;
            }
            return undefined;
        },
        messageClass() {
            return ['lego-dropdown__message--'+this.messageStyle];
        },

        itemsMap() {
            let map = new Map(), me = this;
            buildMap(this.items);
            return map;
            function buildMap(arr) {
                arr.forEach(item => {
                    map.set(me.getValue(item),item);
                    if(item.childItems) {buildMap(item.childItems);}
                });
            }
        },
        selItem() {
            return this.itemsMap.get(this.value);
        },
        hasChildItems() {
            let flag = false;
            this.items.forEach(item => {
                flag = flag || !!item.childItems;
            });
            return flag;
        },
        itemsClass() {
            let clazz = [];
            if(this.hasChildItems) clazz.push("lego-dropdown__items--has-child-items");
            return clazz;
        },
        dropdownWidth() {
            if(!this.width) {return null;}
            return {'width'  : this.getNumber(this.width)+'px'}; 
        },
        itemsWidth() {
            let iWidth = this.itemWidth || this.width;
            if(!iWidth) return null;
            return {'width' : this.getNumber(iWidth)+'px'};
        },
        dropdownHeight(){
            if(!this.height) {return null;}
            return {'height' : this.getNumber(this.height)+'px'}; 
        },
        dropdownClass() {
            return {
                'lego-dropdown--disabled': this.disabled,
                'lego-dropdown--medium': this.$_size === 'medium',
                'lego-dropdown--small': this.$_size === 'small',
                'lego-validator--error': this.hasError === true,
                'lego-validator--valid': this.showValid && this.hasError === false,
                'lego-validator--shake': this.shake
            }
        },
        caretStyle() {
            let style = {};
            if (this.isItemShowing) {
                style['transform'] = 'rotate(-180deg)';
            }
            style['transition-duration'] = '0.3s';
            return style;
        },
        dropdownTitleStyle() {
            if(!this.height) return {};
            let height = this.getNumber(this.height) - 2; /* minus 2px for border */
            return {"height":height+"px","line-height":height+"px"};
        },
    },
    watch: {
        validateTarget(val) {
            this.validateOnEvent(); // whenever checked value changes, execute validate() if lazy is false
        },
        successMessage: {
            immediate: true,
            handler(val) {
                this.showValid = !!val;
            }
        }
    },
    methods: {
        /* [FROM VALIDATOR] */
        // validate()        --+
        // isValid()         --+-- exposed methods for manual validate control
        // clearValidation() --+
        // validateOnEvent() -> should be set by each component which uses legoValidatorMixin
        /********************/

        getText(item)  {
            if(!item) return this.placeholder || this.default.placeholder;
            let itemText = '';
            if(typeof(this.itemText) ==='function') {
                itemText = this.itemText(item);
            } else {
                itemText = item[this.itemText];
            }
            if(itemText === undefined || itemText === null) { return item; }
            else { return itemText; }
        },
        getValue(item) {
            if(!item) return null;
            let itemValue = item[this.itemValue];
            if(itemValue === undefined || itemValue === null) { return item; }
            else { return itemValue; }
        },
        getNumber(str) {
            let v = str;
            if(isNaN(v)) {
                v = v.replace(/[^0-9]/g,"");
            }
            return parseInt(v);
        },
        clickItem(item){
            // $ver: v0.1.0
            // $arg: updated v-model value
            // v-model에 설정된값(value)을 업데이트합니다.
            // item-value props의 설정값에 따라 선택된 항목의 item-value key값을 가져옵니다.
            // # update v-model value(checked props).
            this.$emit('input', this.getValue(item));
            this.toggleItem();
        },
        toggleItem (event) {
            this.isItemShowing = !this.isItemShowing
        },
        toggleItemOuter () {
            this.isItemShowing = false
        },
        isSelectedItem (item) {
            return this.selItem === item;
        },
    },
    directives: {
        'dropdown-click-outside': {
            bind: function(el, binding) {
                // Define Handler and cache it on the element
                const handler = (e) => {
                    if (!(el.contains(e.target) || el === e.target)) {
                        binding.value(e)
                    }
                }
                el.__vueClickOutside__ = handler
                // add Event Listeners
                document.addEventListener('click', handler)
            },
            unbind: function(el, binding) {
                // Remove Event Listeners
                document.removeEventListener('click', el.__vueClickOutside__)
                el.__vueClickOutside__ = null
            }
        }
    }
}

</script>
