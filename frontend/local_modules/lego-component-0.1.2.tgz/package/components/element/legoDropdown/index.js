import legoDropdown from "./legoDropdown.vue";
import legoDropHolder from "./legoDropHolder.vue";
export default {
    install(Vue){
        Vue.component(legoDropdown.name, legoDropdown);
        Vue.component(legoDropHolder.name, legoDropHolder);
    }
};