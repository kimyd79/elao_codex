import * as components from './exportAll'
export default function install(Vue){
    Object.values(components).forEach(function(component) {
        Vue.use(component);
    })
};