<template>
    <div class="lego-grid-item" :style="itemStyle" :class="itemClazz" @click="onClick" @mousedown="onMouseDown">
        <slot/>
    </div>
</template>


<script>
export default {
    name:'legoGridItem',
    props: {
        x      : {default:0},
        y      : {default:0},
        w      : {default:1},
        h      : {default:1},
        vsize  : {default:null},
        zidx   : null,
        gap    : Number,
        col    : [Number,String],
        row    : [Number,String],
        clazz  : String,
        valign : Boolean
    },
    computed: {
        _col() {return parseInt(this.col)||3;},
        _row() {return parseInt(this.row)||3;},
        itemClazz() {
            let clazz = [];
            clazz.push(this.clazz);
            if(this.valign) {clazz.push("lego-grid-item--align-center");}
            return clazz;
        },
        itemStyle() {
            // 1. prepare variable
            var x = this.x, y = this.y,
                w = this.w, h = this.h,
                col  = this._col,
                row  = this._row,
                gap  = this.gap,
                vsize= this.vsize;
            var thGap = gap * (col-1),
                tvGap = gap * (row-1),
                hGap = gap * (w-1),
                vGap = gap * (h-1);
            let style = {};
            
            
            style['width']  = 'calc(((100% - '+thGap+'px) / '+col+') * '+w+' + '+hGap+'px)';
            if(row === 1 && vsize) {
                style['height'] = ((vsize+gap)*h-gap)+'px';
            }else {
                style['height'] = 'calc(((100% - '+tvGap+'px) / '+row+') * '+h+' + '+(vGap-1)+'px)';
            }
            style['left']   = 'calc((100% - '+thGap+'px)'+' * '+x+' / '+col+' + '+(gap*x)+'px)';
            if(row === 1 && vsize) {
                style['top'] = ((vsize+gap)*y)+'px';
            } else {
                style['top'] = 'calc((100% - '+tvGap+'px)'+' * '+y+' / '+row+' + '+(gap*y)+'px)';
            }
            if(this.zidx) {
                style["z-index"] = this.zidx||10;
            }
            return style;
        }
    },
    methods: {
        onClick(e) { this.$emit("click",e); },
        onMouseDown(e) {this.$emit("mousedown",e)}
    }
}
</script>
