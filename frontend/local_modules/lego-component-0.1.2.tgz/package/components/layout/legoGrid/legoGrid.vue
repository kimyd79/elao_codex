<script>
import legoGridItem from './legoGridItem';
import devMode from "./legoGridDevMode";


export default {
    name : 'legoGrid',
    components : {devMode},
    props : {
        col: {default:3},
        row: {default:3},
        gap: {default:10},
        vsize : null,
        dev : Boolean
    },
    data : function() {return {
        
    }},
    methods: {
        genItems: function() {
            let items = [];
            // 1. append guide line
            if(this.dev) {
                this.appendGuideLine(items);
            }
            // 2. slots..
            const slots = this.$slots.default || [];
            for (var i = 0, ii = slots.length; i < ii ; i++) {
                let vnode = slots[i];
                // 1. check
                // 1.1 It.. it something wired... -s-)a
                if( !vnode.componentOptions ) {items.push(vnode);continue;}
                // 1.2 is not a "LEGO-Grid-Item"
                //if( vnode.componentOptions.Ctor.options.name !== 'legoGridItem') {continue;}
                
                // 2. calc and append to items
                var nodeProps = vnode.componentOptions.propsData;
                // 2.0 modify props... (Can I?)
                nodeProps.gap = parseInt(this.gap);
                nodeProps.col = parseInt(this.col);
                nodeProps.row = parseInt(this.row);
                nodeProps.vsize = parseInt(this.vsize);
                items.push(vnode);
            }
            
            return items;
        },
        appendGuideLine(arr) {
            let h = this.$createElement;
            let gap = parseInt(this.gap)
              , col = parseInt(this.col)
              , row = parseInt(this.row);
            let arg = {
                    props:{row,col,gap},
                    on:{"evtReleaseMouse":this.evtReleaseMouse,
                        "evtMoveMouse":this.evtMoveMouse,
                        "evtHoldMouse":this.evtHoldMouse,
                        "click":e=>{this.$emit("click",e)}}
            };
            arr.push(h("devMode",arg))
        },
        
        /* event bypass */
        evtReleaseMouse(_arg) { this.$emit("evtReleaseMouse",_arg); },
        evtMoveMouse(_arg)    { this.$emit("evtMoveMouse",_arg); },
        evtHoldMouse(_arg)    { this.$emit("evtHoldMouse",_arg); }
    },
    render: function(h) {
        var args = {};
        args.staticClass = 'lego-grid';
        if(this.dev) {args.staticClass += ' lego-grid--dev';}
        return h("div", args , this.genItems());
    }
}
</script>