<template>
    <div class="lego-grid__dev" style="text-align: bottom" ref="devRoot" @click="evtClick"
            @mousemove="evtMoveMouse" @mouseout="hideShadow" @mouseup="evtReleaseMouse"
            @mousedown="evtHoldMouse">
        <div v-for="i in (row-1)" :style="rowGlStyle(i)" class="lego-grid__dev-gl" :key="i"/>
        <div v-for="i in (col-1)" :style="colGlStyle(i)" class="lego-grid__dev-gl" :key="i"/>
        <div :style="shadowStyle" class="lego-grid__dev-shadow" @click="evtClick"/>
    </div>
</template>

<script>
import num from "../../../utils/static/numberUtil";

export default {
    name : "legoGridDevMode",
    data : function() {return {
        shx : 0, shy : 0, shadowOn : false
    }},
    props : {
        row : Number,
        col : Number,
        gap : Number,
    },
    computed : {
        shadowStyle() {
            if(!this.shadowOn) {return {opacity:0.1};}
            let pad = 1;
            let gap = this.gap, col = this.col, row = this.row;
            let x = this.shx, y = this.shy;
            let wDif = (!x||x===col-1?0.5-pad:1-pad)*gap, wOff = (x?(x-.5+pad/2):pad/2)*gap;
            let hDif = (!y||y===row-1?0.5-pad:1-pad)*gap, hOff = (y?(y-.5+pad/2):pad/2)*gap;
            let style = {
                    width  : "calc((100% - "+(gap*(col-1))+"px ) / "+col+" + "+wDif+"px)",
                    height : "calc((100% - "+(gap*(row-1))+"px ) / "+row+" + "+hDif+"px)",
                    left   : "calc((100% - "+(gap*(col-1))+"px ) / "+col+" * "+x+" + "+wOff+"px)",
                    top    : "calc((100% - "+(gap*(row-1))+"px ) / "+row+" * "+y+" + "+hOff+"px)",
            };
            return style;
        }
    },
    methods: {
        rowGlStyle (i) {
            let gap = this.gap, row = this.row;
            return { left:0, right:0, height:"1px",
                top : "calc((100% - "+(gap*(row-1))+"px ) / "+row+" * "+i+" + "+((i-0.5)*gap)+"px )"
            }
        },
        colGlStyle (i) {
            let gap = this.gap, col = this.col;
            return { top:0, bottom:0, width:"1px",
                left : "calc((100% - "+(gap*(col-1))+"px ) / "+col+" * "+i+" + "+((i-0.5)*gap)+"px )"
            }
        },
        moveShadow(e) {
            if( !e.target.classList.contains("lego-grid__dev") ) {return;}
            let $root = this.$refs.devRoot,
                w = $root.clientWidth,
                h = $root.clientHeight;
            let col = this.col, row = this.row;
            //let x = e.layerX, y = e.layerY;
            let x = e.offsetX, y = e.offsetY;
            
            if( x >= w || y >= h ) {return;}
            let rx = parseInt(x/w*col), ry=parseInt(y/h*row);
            this.shx = rx;
            this.shy = ry;
            this.shadowOn = true;
        },
        hideShadow(e) {
            let tg = e.toElement;
            if(!tg ) {return;}
            if( tg.classList.contains("lego-grid__dev") ) {return;}
            if( tg.classList.contains("lego-grid__dev-shadow") ) {return;}
            if( tg.classList.contains("lego-grid__dev-gl") ) {return;}
            this.shadowOn = false;
        },
        evtReleaseMouse(e) { this.$emit("evtReleaseMouse",this.getPosArg(e)); },
        evtHoldMouse(e)    { this.$emit("evtHoldMouse"   ,this.getPosArg(e)); },
        evtClick(e) {
            this.$emit("click",e);
        },
        evtMoveMouse(e) {
            this.moveShadow(e);
            this.$emit("evtMoveMouse",this.getPosArg(e));
        },
        getPosArg(e) {
            return {x:this.shx,y:this.shy,e};
        }
    }
}

</script>