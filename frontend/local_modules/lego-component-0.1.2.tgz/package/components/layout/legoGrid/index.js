import compo from "./legoGrid"
import cItem from "./legoGridItem"

export default {
    install(Vue) {
        Vue.component(compo.name, compo);
        Vue.component(cItem.name, cItem);
    }
};