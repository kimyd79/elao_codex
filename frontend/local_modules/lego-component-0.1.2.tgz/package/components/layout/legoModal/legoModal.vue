 <template>
    <div ref="anchor" class="lego-modal lego-scroll" :style="anchorStyle" v-show="isOpen" @mouseup="mUp" @mousemove="mMove" @click="onClick"
            @keydown.esc="keyClose" @keydown.8="keyBackspace">
        <div class="lego-modal__blocker" ref="blocker"/>
        <div class="lego-modal__container--wrapper lego-scroll__content">
            <div class="lego-modal__container" ref="modal" :style="modalStyle" :class="modalClass">
                <div class="lego-modal__head" :class="headClass" @mousedown="mDown">
                    <span class="lego-modal__title">{{title}}</span>
                </div>
                <lego-icon class="lego-modal__close" @click.stop="close">close</lego-icon>
                <div class="lego-modal__body">
                    <!--
                    $ver: v0.1.0
                    팝업의 컨텐츠 영역입니다.
                    #The content area of ​​the popup.
                    -->
                    <slot ref="slot"/>
                </div>
                <div class="lego-modal__foot">
                    <!--
                        $ver: v0.1.0
                        팝업의 하단 영역입니다.
                        #The bottom area of ​​the popup.
                    -->
                    <slot class="lego-modal__action" name="action" :close="close"/>
                </div>
                <div class="lego-modal__ghost" v-show="mMoving" :style="ghostStyle"></div>
            </div>
        </div>
    </div>
</template>

<script>
const TYPES = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
/* randomKey */
function getKey() {
    let x = 0xffffff, n = 0x100000,
        r = parseInt(Math.random() * (x-n) + n)
    return r.toString(16);
}
let ZIDX = 3000;
const ZIDX_MAP = new Map();
/* modal open -> get zidx */
function modalPush(key) {
    let zidx = (++ZIDX);
    ZIDX_MAP.set(key,zidx);
    return zidx;
}
/* modal close,destroy -> pop to map */
function modalPop(key) {
    // 1. check map exist
    if(!ZIDX_MAP.has(key)) return -1; // 아무의미 없음. 안쓰임. code smell 회피
    // 2. get his/her zidx
    let zidx = ZIDX_MAP.get(key);
    // 3. delete from map
    ZIDX_MAP.delete(key);
    // 4. set ZIDX
    //    조심! 모달 열리는 순서 꼬이는경우
    //    조심! blocker 안하는 경우, 아무렇게나 모달을 열었을때
    //        -> 그때는 focus 기반으로 active 배열을 얹어야 할지도.. 문제는 속도지 뭐
    ZIDX = zidx-1;
    return 0;
}
export default {
    name: "legoModal",
    props :{
        // $ver: v0.1.0
        // 상단에 표시될 타이틀 문자열 입니다.
        // #Title string to be displayed at the top.
        title: {type: String, default: ''},

        // $ver: v0.1.0
        // 팝업이 표시되는 애플리케이션 최상단 컴포넌트의 ID 입니다.
        // #The ID of the topmost component of the application where the popup is displayed.
        rootId : {type:String, default: 'app'},

        // $ver: v0.1.0
        // 드래그 & 드랍으로 팝업의 위치를 옮길 수 있습니다.
        // #You can move the position of the popup by dragging and dropping.
        // $default: false
        dragable: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Small 크기로 팝업을 보여줍니다.
        // #Show popup in small size.
        // $default: false
        small: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Medium 크기로 팝업을 보여줍니다.
        // #Show popup in medium size.
        // $default: false
        medium: {type: Boolean, default: false},

        // $ver: v0.1.0
        // Large 크기로 팝업을 보여줍니다.
        // #Show popup in large size.
        // $default: false
        large: {type: Boolean, default: false},

        // $ver: v0.1.0
        // XLarge 크기로 팝업을 보여줍니다.
        // #Show popups in XLarge size.
        // $default: false
        xlarge: {type: Boolean, default: false},

        // $ver: v0.1.0
        // XXLarge 크기로 팝업을 보여줍니다.
        // #Show popups in XXLarge size.
        // $default: false
        xxlarge: {type: Boolean, default: false},

        // $ver: v0.1.0
        // 크기를 문자열로도 지정할 수 있습니다. 'small', 'medium', 'large', 'xlarge', 'xxlarge' 중 하나의 값을 가집니다.
        // #You can also specify the size as a string. It has one of the following values: "small", "medium", "large", "xlarge", "xxlarge".
        size: {
            type: String,
            default: '',
            validator: (val) => {
                if(!isNaN(parseFloat(val))) return true;
                if(val == null || val === '') {
                    val = 'small';
                }
                let lowerVal = val.toLowerCase();
                return ['small', 'medium', 'large', 'xlarge', 'xxlarge'].indexOf(lowerVal) !== -1;
            }
        }
    },
    data : function() {return {
        /* [DATA] for Open/Close modal */
        isOpen : false,
        /* [DATA] for Positioning*/
        posx:0, posy:0,zidx:0,
        /* [DATA] for Modal moving */
        mMoving:false,
        mxStart:0, myStart:0,
        mxEnd  :0, myEnd  :0,
        /* [DATA] Temp data */
        tempKey:""
    }},
    computed: {
        /* [COMPUTED] for Anchor */
        anchorStyle() {
            let arrStyle={};
            // 1. z-index
            if(this.zidx) {
                arrStyle["z-index"] = this.zidx;
            }
            // 2. cursor grabbing
            if( this.mMoving ) {arrStyle["cursor"] = "grabbing";}
            return arrStyle;
        },
        /* [COMPUTED] for Modal container */
        modalStyle() {
            let arrStyle = {};
            // 1. position
            if(this.posy || this.posx) {
                //arrStyle["left"] = parseInt(this.posx)+"px";
                //arrStyle["top"]  = parseInt(this.posy)+"px";
                arrStyle['transform'] = `translate(${parseInt(this.posx)}px,${parseInt(this.posy)}px)`;
            }
            // 2. if moving :: opacity
            if( this.mMoving ) {
                arrStyle["opacity"] = 0.4;
            }
            arrStyle["width"] = this.modalWidth+"px";
            return arrStyle;
        },
        modalClass() {
            let clazz = [];
            if(this.small  ||this.sm) {clazz.push("lego-modal__container--small")}
            if(this.medium ||this.md) {clazz.push("lego-modal__container--medium")}
            if(this.large  ||this.lg) {clazz.push("lego-modal__container--large")}
            if(this.xlarge ||this.xl) {clazz.push("lego-modal__container--xlarge")}
            if(this.xxlarge||this.xxl) {clazz.push("lego-modal__container--xxlarge")}
            return clazz;
        },
        /* [COMPUTED] for Modal ghost */
        headClass() {
            let clazz = [];
            // 1. dragable cursor
            if( this.dragable ) {
                clazz.push("lego-modal__head--dragable");
            }
            if(!this.title) {
                clazz.push("lego-modal__head--no-title");
            }
            return clazz;
        },
        /* [COMPUTED] for Modal ghost */
        ghostStyle() {
            let arrStyle={};
            // 1. if moving :: ghost size, position
            if( this.mMoving ) {
                let modal = this.$refs["modal"];
                let cx = /*parseInt(this.posx) +*/ parseInt(this.mxEnd) - parseInt(this.mxStart)
                let cy = /*parseInt(this.posy) +*/ parseInt(this.myEnd) - parseInt(this.myStart)
                arrStyle['transform'] = `translate(${cx}px,${cy}px)`
                //arrStyle["left"] = (this.posx + this.mxEnd - this.mxStart)+"px";
                //arrStyle["top"]  = (this.posy + this.myEnd - this.myStart)+"px";
                arrStyle["height"] = modal.clientHeight + "px";
                arrStyle["width"]  = modal.clientWidth + "px";
            }
            return arrStyle;
        },
        modalWidth(){
            switch(this.size){
                case 'small'    : return 464;
                case 'medium'   : return 704;
                case 'large'    : return 944;
                case 'xlarge'   : return 1184;
                case 'xxlarge'  : return 1521;
            }
            return this.isNumber(this.size) ? this.size : 464;
        },
    },
    created() {
        // 1. set Modal Index // TODO Move to vuex
        //let st = Z_IDX_STACK;
        //let max = st.length?st[st.length-1]:Z_IDX;
        //let myIdx = max+1;
        //Z_IDX_STACK.push(myIdx);
        //this.zidx = Z_IDX;
        this.tempKey = getKey();
        
        // 2. set position
        //this.posx = window.innerWidth  / 2;
        //this.posy = window.innerHeight / 2;
    },
    mounted() {
        this.$refs.blocker.setAttribute('tabindex',-1);
        this.appendAnchor();
    },
    beforeDestroy() {
        modalPop(this.tempKey);
        let el = this.$refs.anchor;
        el.parentNode.removeChild(el);
    },
    methods: {
        keyClose() {
            this.close();
        },
        keyBackspace(e) {
            // TODO need throttle?
            let doPrevent = true;
            
            let d = e.srcElement || e.target;
            let disabled = d.readonly || d.disabled;
            if (d && !disabled) {
                if (d.isContentEditable) {
                    doPrevent = false;
                } else if (d.tagName && d.tagName.toLocaleLowerCase() === "input") {
                    let type = d.type;
                    if (type) {
                        type = type.toLowerCase();
                    }
                    if (TYPES.indexOf(type) > -1) {
                        doPrevent = false;
                    }
                } else if (d.tagName && d.tagName.toLocaleLowerCase() === "textarea") {
                    doPrevent = false;
                }
            }
            if (doPrevent) {
                e.preventDefault();
            }
        },
        appendAnchor() {
            let me = this;
            this.$nextTick(function() {
                let anchor = me.$refs.anchor;
                if(!anchor) {
                    console.warn("[LEGO-MODAL] Detect hot reloaded, Please refresh browser.");
                    return;
                }//
                anchor.setAttribute("key",me.tempKey);
                let root = document.getElementById(me.rootId);
                root = root || me.$root.$el;
                root.appendChild(anchor);
                
            });
        },
        // @vuese
        // $ver: v0.1.0
        // $(arg): event
        // $return: N/A
        // 팝업을 오픈 합니다.
        // #Open the popup.
        open(e) {
            document.activeElement.blur();
            // 1. set focus
            this.isOpen = true;
            this.$nextTick(()=>{
                let anchor = this.$refs.blocker;
                anchor.setAttribute('tabindex',-1);
                anchor.focus();
            });
            // 2. set zidx
            this.zidx = modalPush(this.tempKey);
            
            
            //this.posx = window.innerWidth  / 2;
            //this.posy = window.innerHeight / 2;

            // $ver: v0.1.0
            // $return: event
            // 팝업이 열릴 때, 이벤트를 발생시킵니다.
            this.$emit("opened",e);

            this.$scopedSlots.default().forEach(slot => {
                if(!slot.componentInstance) {return;}
                let fn = slot.componentInstance.onLoadModal;
                if( fn && typeof fn === "function") {fn();}
            });
            this.$scopedSlots.action && this.$scopedSlots.action().forEach(slot => {
                if(!slot.componentInstance) {return;}
                let fn = slot.componentInstance.onLoadModal;
                if( fn && typeof fn === "function") {fn();}
            });


            this.$nextTick(()=>{
                this.moveModal(0,0);
            })
        },
        // @vuese
        // $ver: v0.1.0
        // $(arg): event
        // $return: N/A
        // 팝업을 닫습니다.
        // #Close the popup.
        close(e) {
            if(this.$listeners['beforeClose']) {
                // $ver: v0.1.2
                // $arg: function close()
                // beforeClose라는 event에 callback method가 설정되어있다면 modal을 닫기 전에
                // 해당 callback을 실행합니다. 첫번 째 인자로 modal을 닫는 function이 전달됩니다.
                // #If the callback method is set in the beforeClose event, the callback is executed before closing the modal. 
                // #The first argument is passed a function that closes the modal.
                this.$emit('beforeClose',()=>{
                    this.isOpen = false;
                    this.$emit("closed",e);
                })
            } else {
                this.isOpen = false;

                // $ver: v0.1.0
                // $arg: event
                // 팝업이 닫힐 때, 이벤트를 발생시킵니다.
                // #Raises an event when the popup closes.
                this.$emit("closed",e);
            }
            this.zidx = modalPop(this.tempKey);
        },
        /* [DRAGABLE] mouse down event */
        mDown(e) {
            if(!this.dragable) {return false;}
            // 1. start to modal move
            this.mMoving = true;
            // 2. set initial position
            this.mxEnd = this.mxStart = e.pageX;
            this.myEnd = this.myStart = e.pageY;
            //sonarqube 190826
            return false;
        },
        /* [DRAGABLE] mouse up event */
        mUp(e) {
            if( !this.mMoving ) {return;}
            // 1. set pos
            this.moveModal(this.mxEnd - this.mxStart, this.myEnd - this.myStart);
            // 2. reset mouse position
            this.mMoving = false;
        },
        /* [DRAGABLE] mouse move event */
        mMove(e) {
            if( !this.mMoving ) {return;}
            // 1. movin.
            this.mxEnd = e.pageX;
            this.myEnd = e.pageY;
        },
        /* [DRAGABLE] set modal position */
        moveModal(difx, dify){
            // 1. set x/y
            let nx = this.posx + (difx || 0);
            let ny = this.posy + (dify || 0);
            // 2. check position
            let rect = this.$refs.modal.getBoundingClientRect();
            let wx = window.innerWidth, wy = window.innerHeight;
            // 2.1 가로 맞추기 : 오른쪽 일단 한번 보는데, 왼쪽도 그러면 왼쪽
            if((wx+rect.width)/2 + nx >= wx) {nx =  (wx-rect.width)/2}
            if((wx-rect.width)/2 + nx <= 0 ) {nx = -(wx-rect.width)/2}
            // 2.2 세로 맞추기 : 거꾸로 바닥보고, 위에 보기
            if((wy+rect.height)/2 + ny >= wy) {ny =  (wy-rect.height)/2}
            if((wy-rect.height)/2 + ny <= 0 ) {ny = -(wy-rect.height)/2}
            //if(rect.right + difx > wx) {nx =  (wx-rect.width)/2}
            //if(rect.left  + difx < 0 ) {}
            //if(rect.top    + dify < 0 ) {ny = -(wy-rect.height)/2}
            //else if(rect.bottom + dify > wy) {ny =  (wy-rect.height)/2}
            // 3. set to this
            this.posx = nx;
            this.posy = ny;
        },
        isNumber(n) {
            return !isNaN(parseFloat(n)) && isFinite(n)
        },
        onClick() {
            // $ver: v0.1.0
            // 팝업이 클릭될 때, 이벤트를 발생시킵니다.
            // #Raises an event when the popup is clicked.
            this.$emit('click');
        }
    }
}
</script>
