import legoModal from "./legoModal.vue";
export default {
    install(Vue){
        Vue.component(legoModal.name, legoModal);
    }
};