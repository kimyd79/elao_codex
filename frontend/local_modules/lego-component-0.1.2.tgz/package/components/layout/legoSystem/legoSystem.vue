<template>
    <div class="lego-system">
        <!-- 
            $ver: v0.1.0
            <em>lego-system</em>은 기본적으로 주어진 컨텐츠를 그대로 랜더링합니다.
            #<em>lego-system</em> renders content as it is by default.
        -->
        <slot></slot>
        <lego-toast/>
    </div>
</template>

<script>
// lego-system은 Vue Instance의 root element역할을 하며 .lego-system이라는 class name을
// 전역에 부여하여 css override를 돕고 특정 component(lego-tooltip 등)의 위치를 지정할 때 boundary 역할을 하기도 합니다.
// #The lego-system acts as the root element of the Vue Instance, giving it a global class name of .lego-system to aid css overrides, 
// #and also acts as a boundary when locating specific components (such as lego-tooltips).
export default {
    name: 'LegoSystem'
}
</script>