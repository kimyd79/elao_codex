import legoSystem from "./legoSystem.vue";
export default {
    install(Vue){
        Vue.component(legoSystem.name, legoSystem);
    }
};