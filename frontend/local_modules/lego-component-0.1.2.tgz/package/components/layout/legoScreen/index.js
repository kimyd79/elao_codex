import legoScreen from "./legoScreen.vue";
export default {
    install(Vue){
        Vue.component(legoScreen.name, legoScreen);
    }
};