<template>
    <div class="lego-screen">
        <!-- 
            $ver: v0.1.0
            lego-screen은 기본적으로 주어진 컨텐츠를 그대로 랜더링합니다.
            #lego-screen renders content as it is by default.
        -->
        <slot></slot>
    </div>
</template>

<script>
// lego-screen은 구축하려는 시스템의 레이아웃 화면단위를 구분하기위한 논리단위로 사용할 수 있습니다.
// vue-router의 1-depth router-view 역할에 알맞습니다.
// 특정 component(lego-tooltip 등)의 위치를 지정할때 anchor역할을 하기도 합니다.
// #lego-screen can be used as a logical unit to separate the layout screen units of the system you are building.
// #Suitable for 1-depth router-view role of vue-router.
// #It also serves as an anchor when positioning certain components (eg lego-tooltips).
export default {
    name: 'LegoScreen'
}
</script>