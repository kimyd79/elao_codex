<template>
    <!-- .lego-page-wrapper :: router-view area -->
    <div class="lego-page-wrapper">
        <div class="lego-page-scroller" @scroll="wrapperScroll"
             :class="fixedHeight?'':'lego-scroll'">
            <!-- .lego-page :: Background color & visible container -->
            <div class="lego-page" :class="pageClass">
                <!-- .lego-page__title-wrapper :: static title & bread crumb -->
                <div class="lego-page__title-wrapper">
                    <div ref="title" class="lego-page__title">
                        <!--
                        $ver: v0.1.0
                        title 영역 입니다. 기본적으로 title 속성으로 전달된 문자열을 출력합니다.
                        #title area. By default, the string passed to the title attribute is output.
                        -->
                        <slot name="title">{{title}}</slot>
                        <div class="lego-page__title__bread-crumb">
                            <!--
                            $ver: v0.1.0
                            breadcrumb 설정을 할 수 있는 영역으로 title영역의 우측상단에 위치합니다.
                            #The breadcrumb setting area is located at the top right of the title area.
                            -->
                            <slot name="breadcrumb"/>
                        </div>
                    </div>
                </div>
                <!-- .lego-page__sticky-area :: sticky title & bread crumb -->
                <div v-show="isSticky" class="lego-page__sticky-area">
                    <div class="lego-page__title-wrapper">
                        <div class="lego-page__title">
                            <!--$hide-->
                            <slot name="title">{{title}}</slot>
                            <div class="lego-page__title__bread-crumb">
                                <!--$hide-->
                                <slot name="breadcrumb"/>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- .lego-page__contents-wrapper :: content area -->
                <div class="lego-page__contents-wrapper" ref="contWrapper"  @scroll="contentScroll"
                     :class="fixedHeight?'lego-scroll':'lego-scroll__content'">
                    <div class="lego-page__contents"
                         :class="fixedHeight?'lego-scroll__content':''">
                        <!--
                        $ver: v0.1.0
                        lego-page의 content 영역 입니다.
                        #The content area of ​​the lego-page.
                        -->
                        <slot/>
                    </div>
                </div>
                <!-- .lego-page__remain :: when using fixed height page, notify contents remain below -->
                <div v-if="fixedHeight&&isRemain" class="lego-page__remain">
                    <div class="lego-page__remain__shadow"></div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "legoPage",
    props : {
        // $ver: v0.1.0
        // title 영역에 임의의 문자열을 넣을 수 있습니다.
        // #You can put any string in the title area.
        title : String,
        // $ver: v0.1.2
        // token 설정에 따라 주어진 window width 구간에 맞추어 page content 영역이 고정값을 갖도록 합니다.
        // 기본값 false로 설정된 상태에서는 window width 변화에 따라 page content 영역도 연속적으로 변화합니다.
        // #Depending on the token setting, the page content area should have a fixed value for the given window width.
        // #If the default value is set to false, the page content area changes continuously as the window width changes.
        // $default: false
        fixedWidth: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // 스크롤을 내렸을 때 title 영역이 상단에 고정되도록 만드는 설정입니다.
        // stickyTitle이 true로 설정되면 scroll 이벤트 발생시마다 <em>wrapperScroll</em>이라는 이름의
        // 내부 method에 따라 sticky header가 보여질지 말지 연산을 하게됩니다.
        // 성능문제가 걱정된다면 해당 method를 override하여 throttle 적용이 필요할수도 있습니다.
        // #This setting makes the title area dock at the top when scrolling down.
        // #When stickyTitle is set to true, each time the scroll event occurs, 
        // #the sticky header is displayed whether or not the sticky header is displayed according to an internal method named <em>wrapperScroll</em>.
        // #If you are concerned about performance issues, you may need to override the method and apply throttle.
        // $default: false
        stickyTitle: {
            type: Boolean,
            default: false
        },
        // $ver: v0.1.2
        // 스크롤바 생성을 content영역 안쪽으로 옮기고 lego-page의 영역을 고정합니다.
        // #Move the scrollbar creation inside the content area and fix the area of ​​the lego-page.
        // $default: false
        fixedHeight: {
            type: Boolean,
            default: false
        }
    },
    data() { return {
        isSticky: false,
        isRemain: false,
    }},
    computed: {
        pageClass() {
            return {
                'lego-page--fixed-width': this.fixedWidth,
                'lego-page--fixed-height': this.fixedHeight,
                'lego-page--sticky-title': this.isSticky
            }
        },
    },
    mounted() {
        this.contentScroll({target:this.$refs.contWrapper})
    },
    methods: {
        wrapperScroll(e) {
            if(this.stickyTitle) {
                this.isSticky = (e.target.getBoundingClientRect().top > this.$refs.title.getBoundingClientRect().top);
            } else {
                this.isSticky = false;
            }
            // $ver: v0.1.1
            // $arg: native event object
            // fixed-height props가 false인 경우 외부에 생기는 scroll event
            // #External scroll event when fixed-height props is false
            this.$emit('scroll', e);
        },
        contentScroll(e) {
            if(this.fixedHeight) {
                this.isRemain = (e.target.scrollTop + e.target.offsetHeight < e.target.scrollHeight);
            }
            // $ver: v0.1.1
            // $arg: native event object
            // fixed-height props가 true 경우 내부에 생기는 scroll event
            // #Internal scroll event when fixed-height props is true
            this.$emit('contents-scroll',e);
        }
    }
}
</script>