<template>
    <div class="lego-page__title-wrapper">
        <div class="lego-page__title">{{currTitle}}</div>
        <div class="lego-page__bread-crumb"><slot/></div>
    </div>
</template>

<script>
export default {
    name: "lego-page-title",
    inject:['screen'],
    props: {
        title:String
    },
    computed: {
        NO_TITLE() {return "No title"}, // use i18n
        currTitle() {return this.title || this.NO_TITLE }
    }
}
</script>