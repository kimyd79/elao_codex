import legoPage from "./legoPage.vue";
export default {
    install(Vue){
        Vue.component(legoPage.name, legoPage);
    }
};