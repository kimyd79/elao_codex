import legoBox from "./legoBox.vue";
export default {
    install(Vue){
        Vue.component(legoBox.name, legoBox);
    }
};