<template>
    <div class="lego-box" @click="onClick" :class="boxClass">
        <div class="lego-box__title" v-if="title||$scopedSlots['title-zone']" @click="toggleSlot" :class="titleClass">
            <label class="lego-box__title__text" v-if="title">{{title}}</label>
            <!--
            $ver: v0.1.0
            title 영역에 추가적인 content를 삽입하고 싶을 때 사용합니다.
            기본위치는 title text의 우측으로 잡히지만, CSS로 위치를 재설정할 수 있습니다.
            #Used when you want to insert additional content in the title area.
            #The default position is to the right of the title text, but you can reset the position with CSS.
            -->
            <slot name="title-zone"/>
        </div>
        <div v-show="isShow" class="lego-box__contents">
            <!--
            $ver: v0.1.0
            content가 들어오는 default slot입니다.
            #The default slot where content comes in.
            -->
            <slot/>
        </div>
    </div>
</template>


<script>
// lego-box는 각종 searchBox, formBox 등의 모태가 되는 컴포넌트로,
// content 공간을 감싸면서 설정에 따라 title을 표시하거나 내부 content를 펼치고 접는 등의 역할을 수행할 수 있습니다.
// #lego-box is a component of various searchBox, formBox, etc. 
// #It can wrap the content space and display title or expand and collapse the internal content according to the setting.
export default {
    name: 'legoBox',
    data() {return {
        isShow:true
    }},
    props: {
        // $ver: v0.1.0
        // title을 문자열로 입력할 수 있습니다.
        // #You can enter title as a string.
        // $default: null
        title: {
            type: String,
            default: null,
        },
        // $ver: v0.1.0
        // title 영역을 클릭시 box를 접었다 펼칠 수 있습니다.
        // #You can collapse and expand the box by clicking on the title area.
        // $default: false
        toggleable : {
            type: Boolean,
            default:false
        },
        // $ver: v0.1.0
        // box가 접힌 상태로 생성됩니다.
        // #The box is created collapsed.
        // $default: false
        initHide : {type:Boolean,default:false},/*Only for dev*/
        // $ver: v0.1.0
        // box안에 box가 들어가는 경우 depth를 명시해주어 구분감을 줄 수 있습니다.
        // #If the box is inside the box, you can specify the depth to give a sense of distinction.
        depth : {type: [Number,String]}
    },
    
    computed: {
        boxClass() {
            let clazz = [];
            if(this.depth) {
                let dp = parseInt(this.depth);
                clazz.push('lego-box--depth-'+dp);
            }
            if(this.title || (this.$scopedSlots['title-zone'] && this.$scopedSlots['title-zone']())) {
                clazz.push('lego-box--with-title');
            }
            return clazz;
        },
        titleClass() {
            let clazz = [];
            if(this.toggleable) clazz.push('lego-box__title--toggleable');
            if(!this.isShow) clazz.push('lego-box__title--collapsed');
            return clazz;
        }
    },
    created(){
        this.isShow = !this.initHide;
    },
    methods : {
        onClick() {
            this.$emit('click');
        },
        toggleSlot() {
            if(this.toggleable){this.isShow = !this.isShow;}
        }
    }
};
</script>