import legoSection from "./legoSection.vue";
export default {
    install(Vue){
        Vue.component(legoSection.name, legoSection);
    }
};