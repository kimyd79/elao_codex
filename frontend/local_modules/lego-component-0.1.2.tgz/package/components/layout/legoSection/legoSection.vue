<template>
    <div class="lego-section">
        <div class="lego-section__title" v-if="title">
            {{title}} <slot name="title-zone"/>
        </div>
        <slot/>
    </div>
</template>



<script>
export default {
    name : "legoSection",
    props:{
        title:String
    }
}
</script>