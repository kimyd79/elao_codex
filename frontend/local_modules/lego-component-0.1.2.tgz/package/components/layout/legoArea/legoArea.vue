<template>
    <div class="lego-area" :class="areaClass" :style="areaStyle">
        <!--
        $ver: v0.1.0
        content가 들어오는 default slot입니다.
        #The default slot where content comes in.
        -->
        <slot></slot>
    </div>
</template>

<script>
    // 기본적으로 공간을 나누기 위해 상단, 좌측을 기준으로 공간을 설정합니다.
    // top, bottom, left, right 어떤 props도 설정되지 않으면 width 100%를 점유하고
    // lego-area내부 content에 따라 높이를 점유합니다.
    // #Basically, the space is set based on the top and left side to divide the space.
    // #top, bottom, left, right If no props are set, it will occupy 100% width and the height according to the content inside the lego-area.
    export default {
        name: "legoArea",
        props:{
            // $ver: v0.1.0
            // 상단으로부터 어느정도의 공간을 점유할지 설정할 수 있습니다.
            // 입력된 값이 height가 됩니다.
            // #You can set how much space to occupy from the top.
            // #The entered value will be height.
            'top'     : [String, Boolean],
            // $ver: v0.1.0
            // 하단으로부터 어느정도의 간격을 가질지 설정할 수 있습니다.
            // 고정높이 wrapper의 안쪽에서 하단 설정된 높이만큼의 공간을 남기고 나머지 공간을 점유할때 쓰입니다.
            // #You can set the amount of space from the bottom.
            // #It is used to occupy the rest of the space while leaving the same height as the bottom set height inside the fixed height wrapper.
            'bottom'  : [String, Boolean],
            // $ver: v0.1.0
            // 좌측으로부터 어느정도의 너비를 점유할지 설정할 수 있습니다.
            // 입력된 값이 width가 됩니다.
            // #You can set how much width to occupy from the left.
            // #The entered value will be width.
            'left'    : [String, Boolean],
            // $ver: v0.1.0
            // Boolean값으로, 남은 width의 오른쪽 나머지 공간을 점유합니다.
            // #Boolean value, occupying the remaining space to the right of the remaining width.
            'right'   : Boolean,
            // $ver: v0.1.0
            // 브라우저 사이즈를 기준으로 page가 가득차도록 공간을 점유합니다.
            // 100%의 width와 calc(100vh - 326px)의 height를 가집니다.
            // 적절한 height값은 css override를 통해 따로 설정하길 권장합니다.
            // GNB, Footer, page의 title영역 및 margin, padding등 간격을 고려하여 계산합니다.
            // #It takes up space to fill the page based on browser size.
            // #It has a width of 100% and a height of calc (100vh-326px).
            // #It is recommended to set the appropriate height separately through css override.
            // #Calculate considering GNB, Footer, page title area, margin, padding, etc.
            'fullPage': Boolean,
            // $ver: v0.1.0
            // default style의 border를 표시합니다.
            // #Show the border of the default style.
            'bordered': Boolean,
            // $ver: v0.1.0
            // 개발과정에서 lego-area가 차지하는 공간을 확인하기 위해 임시 border를 표시합니다.
            // #A temporary border is displayed to check the space occupied by lego-area during development.
            'dev'     : Boolean
        },
        computed: {
            areaClass() {
                let clazz = [];

                // 1. Layout setting
                // 1.1 Append vertical flag
                if( this.top )         {clazz.push('lego-area--top')}
                else if( this.middle ) {clazz.push('lego-area--middle')}
                else if( this.bottom ) {clazz.push('lego-area--bottom')}
                // 1.2 Append horizontal flag
                if( this.left )       {clazz.push('lego-area--left')}
                else if( this.right ) {clazz.push('lego-area--right')}
                // 1.3 has no class
                if( this.fullPage ) {clazz.push('lego-area--full-page')}
                // 1.4 dev mode
                if( this.dev) clazz.push('lego-area--dev');
                
                // 2. We need border
                if( this.bordered ) {
                    clazz.push('lego-area--bordered');
                }

                return clazz.join(' ');
            },
            areaStyle() {
                let style = {};
                // 1. [TOP/BOTTOM] height
                if( this.top && typeof this.top === 'string') {
                    style['height'] = this.top;
                } else if (this.bottom && typeof this.bottom === 'string') {
                    style['height'] = 'calc(100% - '+ this.bottom +')';
                }

                // 2. [LEFT/RIGHT] width? display?
                if (this.left && typeof this.left === 'string') {
                    style['flex'] = '0 0 '+this.left;
                    style['width'] = ''+this.left;
                } else if (this.right === true) {
                    style['flex'] = '1 1 0px';
                    style['width'] = '0px';
                } else {
                    style['flex'] = '1 1 100%';
                    style['width'] = '100%';
                }

                return style
            }
        }
    }
</script>