<template>
    <div class="lego-area lego-grid-area" :class="areaClass" :style="areaStyle" @click="onClick">
        <lego-grid :row="_row" :col="_col" :gap="_gap" :dev="dev" 
                @evtReleaseMouse="evtReleaseHolder" @evtMoveMouse="evtMoveMouse" @evtHoldMouse="evtHoldMouse">
            <slot/>
        </lego-grid>
    </div>
</template>

<script>
import area from "./legoArea";
export default {
    name: "legoGridArea",
    extends:area,
    props:{
        'row':[Number,String],
        'col':[Number,String],
        'gap':[Number,String],
    },
    computed: {
        _row() {return this.row || 3;},
        _col() {return this.col || 3;},
        _gap() {return this.gap || 10;}
    },
    methods : {
        evtReleaseHolder(_arg) { this.$emit("evtReleaseHolder",this.appendArgInfo(_arg)) },
        evtMoveMouse(_arg)     { this.$emit("evtMoveMouse"    ,this.appendArgInfo(_arg)); },
        evtHoldMouse(_arg)     { this.$emit("evtHoldMouse"    ,this.appendArgInfo(_arg)); },
        appendArgInfo(_arg) {
            return Object.assign({},_arg , {row:this.row, col:this.col});
        },
        onClick(e) { /* event bypass */
            this.$emit("click",e);
        }
    }
}
</script>
