import legoArea from "./legoArea.vue";
import legoGridArea from "./legoGridArea";
export default {
    install(Vue){
        Vue.component(legoArea.name, legoArea);
        Vue.component(legoGridArea.name, legoGridArea);
    }
};