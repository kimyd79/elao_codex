<template>
    <lego-box :title="title" :toggleable="toggleable" :class="'lego-form-box-wrapper lego-form-box-wrapper--'+$_size">
        <template v-slot:title-zone>
            <!--
            $ver: v0.1.0
            <em>lego-box</em>와 동일하게 title-zone을 사용할 수 있습니다.
            자세한 내용은 <em>lego-box</em>를 참고하시길 바랍니다.
            #You can use title-zone just like <em> lego-box </em>.
            #Please see <em> lego-box </em> for more information.
            -->
            <slot name="title-zone"/>
        </template>
        <div class="lego-form-box" :class="formBoxClass" @click="onClick">
            <div class="lego-form-box__contents">
                <!--
                $ver: v0.1.0
                <em>lego-form-row</em>, <em>lego-form-item</em>등이 들어올 수 있는 default slot입니다.
                &lt;hr>태그도 사용할 수 있습니다.
                #This is the default slot for <em> lego-form-row </em>, <em> lego-form-item </em>, etc.
                -->
                <slot/>
                <hr v-if="isExpanded"/>
                <div v-show="isExpanded" class="lego-form-box__contents">
                    <!--
                    $ver: v0.1.2
                    In addition to the content that should be shown as required, you can fold and expand the optional elements separately.
                    #
                    -->
                    <slot name="expandable-zone"/>
                </div>
                <div v-if="$scopedSlots.bottomActionBar"
                     :class="'lego-form-box__action-grp lego-form-box__action-grp--bottom lego-form-box__action-grp--'+$_size">
                    <!--
                    $ver: v0.1.1
                    이 slot에는 <em>lego-action-bar</em>를 활용해야 정상적으로 사용할 수 있습니다.
                    action button들을 <em>lego-form-box</em>내부 하단영역에 위치시킵니다.
                    #This slot requires <em> lego-action-bar </em> for normal use.
                    #Place the action buttons inside the <em> lego-form-box </em> bottom area.
                    -->
                    <slot name="bottomActionBar"></slot>
                    <!--TODO: slot명칭을 camelCase를 쓸지 kebab-case를 쓸지 통일이 필요해보임. LEGO-Component 전체적으로-->
                </div>
            </div>
            <div v-if="$scopedSlots.rightActionBar"
                 :class="'lego-form-box__action-grp lego-form-box__action-grp--right lego-form-box__action-grp--'+$_size">
                <lego-form-item no-label>
                    <!--
                    $ver: v0.1.1
                    이 slot에는 <em>lego-action-bar</em>를 활용해야 정상적으로 사용할 수 있습니다.
                    action button들을 <em>lego-form-box</em>내부 우측영역에 위치시킵니다.
                    여러 row를 사용한다면 마지막 row의 우측에 위치하게됩니다.
                    #This slot requires <em> lego-action-bar </em> for normal use.
                    #Place the action buttons inside the <em> lego-form-box </em> right area.
                    #If you use multiple rows, they will be located to the right of the last row.
                    -->
                    <slot name="rightActionBar"/>
                </lego-form-item>
            </div>

            <!-- 확장영역 라인부분 -->
            <div v-if="$scopedSlots['expandable-zone']" class="lego-form-box__exp-bottom">
                <div class="lego-form-box__exp-bottom__line"></div>
                <div class="lego-form-box__exp-bottom__toggle" @click="expandToggle">
                    <lego-icon-wrapper>
                        <lego-icon :icon="expandIcon"/>
                    </lego-icon-wrapper>
                    {{expandMessage}}
                </div>
                <div class="lego-form-box__exp-bottom__line"></div>
            </div>
        </div>
        <div v-if="$scopedSlots.outerActionBar"
             :class="'lego-form-box__action-grp lego-form-box__action-grp--outer lego-form-box__action-grp--'+$_size">
            <!--
            $ver: v0.1.1
            이 slot에는 <em>lego-action-bar</em>를 활용해야 정상적으로 사용할 수 있습니다.
            action button들을 <em>lego-form-box</em>외부 바로 아래에 위치시킵니다.
            #This slot requires <em> lego-action-bar </em> for normal use.
            #Place the action buttons just outside the <em> lego-form-box </em>.
            -->
            <slot name="outerActionBar"></slot>
        </div>
    </lego-box>
</template>


<script>
const TAG_ITEM = "legoFormItem";

export default {
    name: "legoFormBox",
    props: {
        // $ver: v0.1.0
        // $default: 2
        // <em>lego-form-box</em>안쪽으로 column을 몇개로 나누어 관리할지 설정합니다.
        // props자체에 기본값은 없지만 data영역에 기본값이 2로 정의되어있습니다.
        // #Sets how many columns to manage inside <em> lego-form-box </em>.
        // #There is no default value for props itself, but the default value is defined as 2 in the data area.
        column     : [String, Number],
        // $ver: v0.1.0
        // $abbr: column
        col        : [String, Number], /* abbr */
        // $ver: v0.1.0
        // <em>lego-form-box</em>안쪽에서 쓰이는 <em>lego-form-item</em>각각이 가지는 label-size를 설정합니다.
        // <em>lego-form-item</em>에서 label-size가 따로 설정된다면 그 값을 우선합니다.
        // #Set the label-size that each <em> lego-form-item </em> used inside of <em> lego-form-box </em>.
        // #If label-size is set separately in <le> lego-form-item </em>, it takes precedence.
        labelSize  : String,
        // $ver: v0.1.0
        // $default: inline
        // 'inline' 혹은 'block'의 값을 줄 수 있으며 기본값은 'inline'입니다.
        // label과 content가 inline으로 왼쪽-오른쪽에 위치할지 block형태로 아래-위로 위치할지 선택합니다.
        // #You can give the value 'inline' or 'block', and the default is 'inline'.
        // #Choose whether the label and content are left-right inline or down-up in block form.
        labelDisplay : {
            type:String,
            validator: (val) => {
                let lowerVal = val.toLowerCase();
                return ['inline', 'block'].indexOf(lowerVal) !== -1;
            }
        },
        // $ver: v0.1.0
        // $default: left
        // 'left' 혹은 'right'의 값을 줄 수 있으며 기본값은 'left'입니다.
        // <em>lego-form-item</em>의 label영역 안에서 좌-우 정렬을 선택할 수 있습니다.
        // #You can give a value of 'left' or 'right'. The default value is 'left'.
        // #You can select left-right alignment within the label area of ​​<em> lego-form-item </em>.
        labelAlign : {
            type:String,
            validator: (val) => {
                let lowerVal = val.toLowerCase();
                return ['left', 'right'].indexOf(lowerVal) !== -1;
            }
        },
        // $ver: v0.1.0
        // <em>lego-form-item</em>의 toggle slot을 사용하는 경우 default slot을 보여줄지 toggle slot을 보여줄 지
        // 선택할 수 있습니다. 주로 수정요건이 필요한경우 사용합니다.
        // #If you use toggle slot of <em> lego-form-item </em>, you can choose whether to show default slot or toggle slot. 
        // #It is mainly used when modification requirements are needed.
        toggle     : Boolean,
        // $ver: v0.1.2
        // expandable-zone slot을 사용하는 경우 해당 slot의 content를 보여줄지 여부를 선택할 수 있습니다.
        // 주로 첫 접근시 초기값으로 펼쳐져있을지 접혀져있을지 여부를 컨트롤 하기 위해 사용됩니다.
        // expandable-zone을 펼치고 접는 아이콘이 따로 있어 펼쳐짐 여부는 컴포넌트 내부에서 관리되기 때문에
        // 따로 props설정은 필요없지만, 펼쳐짐 여부에 따라 외부에서 동작이 달라져야할 경우
        // :expanded.sync="variable"의 형태로 2way-binding을 사용할 수 있습니다.
        // #If you use an expandable-zone slot, you can choose whether to show the contents of that slot.
        // #This is used to control whether it is expanded or collapsed to its initial value on first access.
        // #There is a separate expandable-zone icon for expanding and collapsing.
        // #You don't need to configure props, but you can use 2way-binding in the form of
        // # :expanded.sync = "variable" if you need to change the behavior externally depending on whether it is expanded.
        expanded: {
            type:Boolean,
            default: false
        },
        // $ver: v0.1.2
        // expandable-zone slot을 사용하는 경우 펼치고 접는 부분을 컨트롤 하기 위한 아이콘 옆에
        // 문자열 형태로 메시지를 할당해줄 수 있습니다.
        // 펼치다, 접다 등 상황에 따라 다른 메시지를 보여줘야 한다면 expanded props값에 따라 expandMessage 또한
        // 달라져야 할 것입니다.
        // #If you use an expandable-zone slot, you can assign a message in the form of a string next to the icon to control the expansion and collapse.
        // #If you need to display different messages in different situations, such as expand or collapse, expandMessage will also need to change depending on the value of the expanded props.
        expandMessage: {
            type: String,
            default: ''
        },

        // $ver: v0.1.0
        // <em>lego-box</em>와 마찬가지로 필요하다면 title을 활용할 수 있습니다.
        // #As with <em> lego-box </em>, you can use title if you need to.
        title      : String,
        // $ver: v0.1.0
        // <em>lego-box</em>와 마찬가지로 필요하다면 <em>lego-form-box</em>영역 전체를 접었다 펼칠 수 있습니다.
        // #As with <em> lego-box </em>, you can collapse and expand the entire <em> lego-form-box </em> area if necessary.
        toggleable : Boolean,
        // $ver: v0.1.0
        // <em>lego-form-box</em> 전체적으로 small크기를 사용합니다.
        // <em>lego-form-item</em> 및 그 아래쪽에 속한 <em>lego-input</em>계열 모든 컴포넌트 크기에 영향을 줍니다.
        // 해당 컴포넌트들이 각각의 크기설정을 가진 경우 그 값을 우선으로 합니다.
        // #<em> lego-form-box </em> Use small size throughout.
        // #Affects the size of all <em> lego-form-item </em> and the <em> lego-input </em> series below it.
        // #If each component has its own size setting, the value takes precedence.
        small      : Boolean,
        // $ver: v0.1.0
        // $abbr: small
        sm         : Boolean,
        // $ver: v0.1.0
        // <em>lego-form-box</em> 전체적으로 medium크기를 사용합니다.
        // 크기설정이 따로 없다면 medium을 기본값으로 하며, 기본값 설정은 data에 선언되어있습니다.
        // <em>lego-form-item</em> 및 그 아래쪽에 속한 <em>lego-input</em>계열 모든 컴포넌트 크기에 영향을 줍니다.
        // 해당 컴포넌트들이 각각의 크기설정을 가진 경우 그 값을 우선으로 합니다.
        // #<em> lego-form-box </em> Use medium size throughout.
        // #If no size is specified, medium is the default and the default is declared in data.
        // #Affects the size of all <em> lego-form-item </em> and the <em> lego-input </em> series below it.
        // #If each component has its own size setting, the value takes precedence.
        medium     : Boolean,
        // $ver: v0.1.0
        // $abbr: medium
        md         : Boolean,
    },
    data() {return {
        default:{
            labelDisplay: 'inline',
            labelAlign: 'left',
            size:'medium',
            column: 2
        },
        isExpanded: false
    }},
    computed : {
        $_col() {return parseInt(this.column) || parseInt(this.col)  || this.default.column;},
        $_size() {
            if(this.small || this.sm) {return 'small';}
            if(this.medium || this.md) {return 'medium';}
            return this.default.size;
        },
        formBoxClass() {
            let rtn = [];
            if(!!this.$scopedSlots['expandable-zone']) rtn.push('lego-form-box--expandable');
            rtn.push('lego-form-box--'+this.$_size);
            return rtn;
        },
        expandIcon() {
            return this.isExpanded ? 'collapse_menu': 'expand_menu';
        },
        sharedData() {
            let rtn = {}, odf = Object.defineProperty;
            odf(rtn, "col"         , {get:()=>this.$_col});
            odf(rtn, "labelSize"   , {get:()=>this.labelSize});
            odf(rtn, "labelDisplay", {get:()=>this.labelDisplay || this.default.labelDisplay});
            odf(rtn, "labelAlign"  , {get:()=>this.labelAlign || this.default.labelAlign});
            odf(rtn, "toggle"      , {get:()=>this.toggle});
            odf(rtn, "size"        , {get:()=>this.$_size});
            return rtn;
        }
    },
    watch: {
        expanded:{
            immediate: true,
            handler(val) {
                if (val !== this.isExpanded) {
                    this.isExpanded = val;
                }
            }
        }
    },
    methods: {
        onClick(e) {
            // $ver: v0.1.0
            // $arg: native event object
            // lego-form-box내부에서 발생한 click이벤트 중 stopPropagation에 의해 막히지 않고 전파된 click이벤트가 있다면
            // 해당 이벤트를 전달합니다.
            // #If there is a click event propagated without being blocked by stopPropagation among the click events
            // # occurred in lego-form-box, the relevant event is delivered.
            this.$emit('click',e);
        },
        expandToggle() {
            this.isExpanded = !this.isExpanded;
            // $ver: v0.1.2
            // $arg: updated expanded value
            // expandable-zone slot을 사용할 때 expand 토글아이콘에 의해 expanded값이 변경되는 경우
            // expanded값의 업데이트를 위해 이벤트가 발생됩니다. :expanded.sync 를 사용하여 2way-binding이
            // 활성화 된 경우 이 이벤트에 의해 업데이트 됩니다.
            // #When using the expandable-zone slot, if the expanded value is changed by the expand toggle icon, an event is raised to update the expanded value.
            // #Updated by this event when 2way-binding is enabled using :expanded.sync.
            this.$emit('update:expanded', this.isExpanded);
            // $ver: v0.1.2
            // $arg: updated expanded value
            // expanded.sync를 활용하지 않으면서 expanded값의 변화를 감지하고 싶다면
            // expandToggle이벤트를 활용할 수 있습니다.
            // #If you do not want to use expanded.sync and want to detect changes in the expanded value, you can use the expandToggle event.
            this.$emit('expandToggle', this.isExpanded);
        }
    },
    provide(){
        return {boxInfo:this.sharedData};
    }
}
</script>
