<template>
    <div class="lego-form-item" :class="itemClass" :style="itemStyle">
        <div class="lego-form-item__label ellipsis" :class="labelClass" :style="labelStyle">
            <!--
            $ver: v0.1.0
            label은 props를 통해 문자열을 넣을수도 있지만 label slot을 활용하여 더 자유도 높은 구현을 할 수 있습니다.
            #Labels can be stringed via props, but label slots allow for more freedom of implementation.
            -->
            <slot name="label">{{label}}</slot>
        </div>
        <div v-if="!boxInfo.toggle" class="lego-form-item__compo" :class="noFlex?'lego-form-item__compo--no-flex':''" >
            <!--
            $ver: v0.1.0
            content영역을 채우는 default slot입니다.
            #The default slot that fills the content area.
            -->
            <slot/>
        </div>
        <div v-else class="lego-form-item__compo" :class="noFlex?'lego-form-item__compo--no-flex':''" >
            <!--
            $ver: v0.1.0
            <em>lego-form-box</em>의 toggle props값이 true인 경우 toggle slot에 설정된 content가 표시됩니다.
            toggle slot을 설정하지 않았다면 default slot의 내용이 그대로 표시됩니다.
            #If the toggle props value of <em> lego-form-box </ em> is true, the content set in the toggle slot is displayed.
            #If the toggle slot is not set, the contents of the default slot are displayed as is.
            -->
            <slot name="toggle">
                <slot/>
            </slot>
        </div>
    </div>
</template>

<script>
export default {
    name: "legoFormItem",
    inject : ["boxInfo"],
    props: {
        // $ver: v0.1.0
        // label영역에 표시될 문자열을 설정합니다.
        // #Set the text to be displayed in the label area.
        "label"   : String,
        // $ver: v0.1.0
        // 필수 입력영역이라는 것을 표기하기 위하여 빨간색 * 표시를 label에 부여합니다.
        // left 정렬인 경우 label의 오른쪽에, right 정렬인 경우 label의 왼쪽에 표시됩니다.
        // #Label the red * to indicate that it is a required field.
        // #If it is a left alignment, it is displayed to the right of the label; if it is a right alignment, it is displayed to the left of the label.
        "required": Boolean,
        // $ver: v0.1.0
        // label없이 content영역만 사용합니다.
        // #Use only content area without label.
        "noLabel" : Boolean,
        // $ver: v0.1.0
        // label영역의 좌-우 정렬을 설정합니다.
        // 'left', 'right' 값을 사용할 수 있습니다.
        // #Set left and right alignment of label area.
        // #You can use the values ​​'left' and 'right'.
        "labelAlign": {
            type:String,
            validator: (val) => {
                let lowerVal = val.toLowerCase();
                return ['left', 'right'].indexOf(lowerVal) !== -1;
            }
        },
        // $ver: v0.1.0
        // <em>lego-form-box</em>에서 설정한 column 값 중 몇개의 column을 점유할지 설정합니다.
        // #How many columns to occupy among the column values ​​set in <em> lego-form-box </ em>
        "colSpan" : [Number,String],
        // $ver: v0.1.0
        // $abbr: colSpan
        "span"    : [Number,String], /* abbr */
        // $ver: v0.1.0
        // 높이제한을 해제합니다. 주로 textarea나 큰 높이값을 가지는 content를 사용할 때 쓰입니다.
        // #Turn off the height limit. It is mainly used when using textarea or content with large height.
        "noHeight" : Boolean,
        // $ver: v0.1.0
        // small크기의 <em>lego-form-item</em>을 사용합니다.
        // content영역에 오는 <em>lego-input</em>계열 모든 컴포넌트 크기에도 영향을 줍니다.
        // 해당 컴포넌트들이 각각의 크기설정을 가진 경우 그 값을 우선으로 합니다.
        // #Use small <em> lego-form-item </ em>.
        // #This also affects the size of all components in the <em> lego-input </ em> series that come into the content area.
        // #If each component has its own size setting, the value takes precedence.
        "small"   : Boolean,
        // $ver: v0.1.0
        // $abbr: small
        "sm"      : Boolean,
        // $ver: v0.1.0
        // medium크기의 <em>lego-form-item</em>을 사용합니다.
        // content영역에 오는 <em>lego-input</em>계열 모든 컴포넌트 크기에도 영향을 줍니다.
        // 해당 컴포넌트들이 각각의 크기설정을 가진 경우 그 값을 우선으로 합니다.
        // #Use medium size <em> lego-form-item </ em>.
        // #This also affects the size of all components in the <em> lego-input </ em> series that come into the content area.
        // #If each component has its own size setting, the value takes precedence.
        "medium"  : Boolean,
        // $ver: v0.1.0
        // $abbr: medium
        "md"      : Boolean,
        // $ver: v0.1.2
        // <em>lego-form-item</em>의 content영역인 default slot 및 toggle slot은 내부 세로정렬을 위하여 display:flex가
        // 적용되어 있습니다. 해당 설정은 단순한 세로 정렬을 맞추는데 유용하지만 떄로는 원치않는 동작을 유발하기도 합니다.
        // no-flex 옵션을 통해 display:flex 설정을 없앨 수 있습니다.
        // #The default and toggle slots in the content area of ​​the <le> form-item </ em> have display: flex for internal vertical alignment.
        // #This setting is useful for simple vertical alignment, but it can also cause unwanted behavior.
        // #The no-flex option can be used to eliminate the display: flex setting.
        "noFlex"  : Boolean
    },
    data(){return {
        default:{
            size:'medium',
            labelAlign: 'left'
        }
    }},
    computed:{
        $_size() {
            if( this.small || this.sm ) return 'small';
            if( this.medium || this.md ) return 'medium';
            if( this.boxInfo && this.boxInfo.size) return this.boxInfo.size;
            return this.default.size;
        },
        $_span() {
            return parseInt(this.colSpan) || parseInt(this.span) ||  1;
        },
        itemFlex() {
            const itemWidth = 100 / this.boxInfo.col * this.$_span;
            return "0 0 "+itemWidth+"%";
        },
        itemStyle() {
            let style = {};
            style["flex"] = this.itemFlex;
            if( this.noHeight ){
                style["height"] = "auto";
            }
            return style;
        },
        itemClass() {
            let clazz = [];
            clazz.push("lego-form-item--"+this.boxInfo.labelDisplay);
            if( this.noLabel  ) clazz.push("lego-form-item--no-label");
            if( this.noHeight ) clazz.push("lego-form-item--no-height");
            if( this.required ) clazz.push("lego-form-item--required");
            clazz.push('lego-form-item--'+this.$_size);
            return clazz.join(' ');
        },
        labelStyle() {
            let style = {};
            if(this.boxInfo.labelSize) {style["flex"] = "0 0 "+this.boxInfo.labelSize;}
            return style;
        },
        labelClass() {
            let clazz = [];
            if(this.labelAlign) {
                clazz.push("lego-form-item__label--"+this.labelAlign);
            } else if(this.boxInfo.labelDisplay === 'block') {
                clazz.push("lego-form-item__label--left");
            } else if(this.boxInfo.labelAlign) {
                // this is default align which is set by lego-form-box
                // if you want to edit default label align, change default value of labelAlign props of lego-form-box
                clazz.push("lego-form-item__label--"+this.boxInfo.labelAlign);
            } else  {
                // actually, this is bad case :: lego-form-item is not located under lego-form-box
                clazz.push("lego-form-item__label--"+this.default.labelAlign);
            }
            return clazz.join(' ');
        }
    },
    provide() {
        let rtn = {};
        let odf = Object.defineProperty;
        let legoInput = {};
        odf(legoInput, 'size', {get: ()=>this.$_size});
        rtn['legoInput'] = legoInput;
        return rtn;
    },
}
</script>
