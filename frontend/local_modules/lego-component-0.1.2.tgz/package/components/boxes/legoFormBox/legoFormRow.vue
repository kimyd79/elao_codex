<template>
    <div class="lego-form-row">
        <!--
        $ver: v0.1.2
        <em>lego-form-row</em>는 자체로 별다른 역할을 하지 않습니다.
        default slot으로 들어오는 content를 그대로 출력해줍니다.
        table의 &lt;tr>역할을 합니다.
        디자인 토큰 중 $lego-form-box__h-divider, $lego-form-row__v-divider값의 변경을 통해
        <em>lego-form-box</em>내부 구분선을 넣고 싶다면 <em>lego-form-row</em>를 적극적으로 활용해야합니다.
        #<em>lego-form-row</em> does not play a role by itself.
        #Print the content coming into the default slot.
        #It acts as & lt;tr> of the table.
        #By changing the value of $lego-form-box__h-divider and $lego-form-row__v-divider among design tokens
        #If you want to put an <em>lego-form-box</em> inner dividing line, you should actively use <em>lego-form-row</em>.
        -->
        <slot/>
    </div>
</template>

<script>
    export default {
        name: "legoFormRow"
    }
</script>
