import legoFormBox from "./legoFormBox.vue";
import legoFormItem from "./legoFormItem.vue"
import legoFormRow from "./legoFormRow.vue"
export default {
    install(Vue){
        Vue.component(legoFormBox.name, legoFormBox);
        Vue.component(legoFormItem.name, legoFormItem);
        Vue.component(legoFormRow.name, legoFormRow);
    }
};