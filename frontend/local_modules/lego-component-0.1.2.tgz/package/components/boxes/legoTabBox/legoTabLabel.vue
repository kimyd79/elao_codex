<template>
    <button v-if="type=='label'" class="lego-tab__label" :class="labelClass" @click="activeIdx">
        <lego-icon v-if="icon" :icon="icon"></lego-icon>
        <slot/>
    </button>
    <button v-else-if="type=='left'" class="lego-tab__label" :class="labelClass" @click="move()">
        <lego-icon v-if="icon" :icon="icon"></lego-icon>
        <slot/>
    </button>
    <button v-else-if="type=='right'" class="lego-tab__label" :class="labelClass" @click="move()">
        <lego-icon v-if="icon" :icon="icon"></lego-icon>
        <slot/>
    </button>
</template>

<script>
export default {
    name:"legoTabLabel",
    inject:['tabBox'],
    props:{
        idx:[String,Number],
        mini:Boolean,
        icon: {type: String, default: ''},
        iconPos: {type: String, default: ''},
        type: {type: String, default: ''}
    },
    computed: {
        currIdx() {
            return this.$parent.currIdx;
        },
        isActive() {
            return this.idx === this.currIdx;
        },
        labelClass() {
            let clazz = [];
            if(this.tabBox.underline){
                clazz.push("lego-tab__label-underline");
            }
            if(this.isActive) {
                clazz.push("lego-tab__label--active");
                if(this.tabBox.underline) {
                    clazz.push("lego-tab__label-underline--active")
                }
            }
            if(this.mini) {
                clazz.push("lego-tab__label--mini");
            }
            return clazz;
        },
    },
    methods: {
        activeIdx () {
            this.$emit("activeIdx",this.idx);
        },
        move() {
            this.$nextTick(function() {
                this.$emit("move", this.type);
            });
        }
    }
}
</script>