import legoTabBox from "./legoTabBox.vue";
import legoTabLabel from "./legoTabLabel.vue";
import legoTabContent from "./legoTabContent.vue";
export default {
    install(Vue){
        Vue.component(legoTabBox.name, legoTabBox);
        Vue.component(legoTabLabel.name, legoTabLabel);
        Vue.component(legoTabContent.name, legoTabContent);
    }
};