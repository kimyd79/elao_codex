<template>
    <div class="lego-tab__content" :class="contentClass">
        <slot/>
    </div>
</template>

<script>
export default {
    name:'legoTabContent',
    props:{
        idx:[String,Number]
    },
    computed: {
        currIdx() {
            return this.$parent.currIdx;
        },
        isActive() {
            return this.idx === this.currIdx;
        },
        contentClass() {
            let clazz = [];
            if(this.isActive) {
                clazz.push("lego-tab__content--active");
            }
            
            return clazz;
        }
    }
}

</script>