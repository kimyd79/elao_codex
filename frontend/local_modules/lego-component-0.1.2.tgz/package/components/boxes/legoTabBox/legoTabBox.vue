<script>
const TAG_LABEL = "legoTabLabel";
const TAG_CONTS = "legoTabContent";
const TYPE_LABEL = "label";
const TYPE_LEFT = "left";
const TYPE_RIGHT = "right";

export default {
    name:"legoTabBox",
    data:function() {return {
        currIdx:"3",
        leftIcon: "chevron-left",
        rightIcon: "chevron-right",
        titleObj: {},
        offset: 0,
        tabNaviLabelStyle: 'none',
        tabNaviClass: 'lego-tab__navi',
    }},
    props:{
        mini:Boolean,
        defaultIdx: [String, Number],
        underline: {type:Boolean, default: false},
    },
    created() {
        // 1. Check default index
        if( this.defaultIdx ) {
            this.currIdx = this.defaultIdx;
            return;
        }
        // 2. Make first tab to current tab
        let slots = this.$slots.default, idxs=[];
        slots.forEach(vNode=> {
            if(!vNode.componentOptions){ return; }
            let nodeName = vNode.componentOptions.Ctor.options.name;
            if( TAG_LABEL === nodeName ) {
                idxs.push(vNode.componentOptions.propsData.idx);
            }
        });
        this.currIdx = idxs[0];
    },
    mounted: function() {
        this.$nextTick(function() {
            if(this.$el.children[0].children[0].className === "lego-tab__title") {
                //let scrollWidth = this.$el.children[0].children[0].scrollWidth;
                //let clientWidth = this.$el.children[0].children[0].clientWidth;
                // if(scrollWidth >= clientWidth) {
                //     this.tabNaviLabelStyle = "inline-block";
                // } else {
                //     this.tabNaviLabelStyle = "none"
                // }
                this.tabNaviLabelStyle = "none";
                //this.tabNaviLabelStyle = "flex";
            }
        });
    },
    render(h) {
        let slots = this.$slots.default;
        let labels = [],conts = [],navi = [];
        let idxs = [];
        // 1. classify nodes
        slots.forEach(vNode=> {
            if(!vNode.componentOptions){ return; }
            let nodeName = vNode.componentOptions.Ctor.options.name;
            switch(nodeName) {
            case TAG_LABEL:
                labels.push(vNode);
                let propsData = vNode.componentOptions.propsData;
                vNode.componentOptions.propsData = Object.assign({},propsData,{mini:this.mini,type:TYPE_LABEL})
                vNode.componentOptions.listeners = {"activeIdx":this.setIdx}
                break;
            case TAG_CONTS:
                conts.push(vNode);
                break;
            }
        });
        // 2. tab navi
        if(this.mini){
            this.tabNaviClass = "lego-tab__navi--mini";
        }
        // 2.1. left tab
        let leftTabNavi = h("lego-tab-label");
        let leftTabNaviPropsData = leftTabNavi.componentOptions.propsData;
        leftTabNavi.componentOptions.propsData = Object.assign({},leftTabNaviPropsData,{mini:this.mini,icon:this.leftIcon,type:TYPE_LEFT});
        leftTabNavi.componentOptions.listeners = {"move":this.move};
        navi.push(leftTabNavi);
        // 2.2. right tab
        let rightTabNavi = h("lego-tab-label");
        let rightTabNaviPropsData = rightTabNavi.componentOptions.propsData;
        rightTabNavi.componentOptions.propsData = Object.assign({},rightTabNaviPropsData,{mini:this.mini,icon:this.rightIcon,type:TYPE_RIGHT});
        rightTabNavi.componentOptions.listeners = {"move":this.move};
        navi.push(rightTabNavi);

        return h("div",{"class":"lego-tab-box"},
                [
                    h("div",{"class":"lego-tab__label-window"},[
                        h("div",{"class":"lego-tab__label-wrapper", "style":"margin-left:" + this.offset + "px"}, labels),
                        h("div", {"class":"lego-tab__navi", "style":"display:" + this.tabNaviLabelStyle}, navi)
                    ])
                    ,h("div",{"class":"lego-tab__content-wrapper"},conts)
                ]);
    },
    methods : {
        setIdx(idx) {
            this.currIdx = idx;
            this.$emit("tab-change",idx);
        },
        move(direction) {
            if(this.$el.children[0].children[0].className === "lego-tab__title") {
                let scrollWidth = this.$el.children[0].children[0].scrollWidth;
                let clientWidth = this.$el.children[0].children[0].clientWidth;

                if (direction === 'left') {
                    if (this.offset < 0) {
                        if (this.offset >= -200) {
                            this.offset = 0;
                        } else {
                            this.offset += 200;
                        }
                    }
                } else if (direction === 'right') {
                    let var1 = clientWidth - scrollWidth;
                    if (this.offset <= 0 && var1 < 0) {
                        if (var1 >= -200) {
                            this.offset += var1;
                        } else {
                            this.offset -= 200;
                        }
                    }
                }
            }
        },
    },
    provide(){
        return {
            tabBox:{
                underline: this.underline
            }
        }
    }

}
</script>
