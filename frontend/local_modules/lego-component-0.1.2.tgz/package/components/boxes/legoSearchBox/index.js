import legoSearchBox from "./legoSearchBox.vue";
import legoSearchRow from './legoSearchRow.vue';
import legoSearchItem from './legoSearchItem.vue';
export default {
    install(Vue){
        Vue.component(legoSearchBox.name, legoSearchBox);
        Vue.component(legoSearchRow.name, legoSearchRow);
        Vue.component(legoSearchItem.name, legoSearchItem);
    }
};