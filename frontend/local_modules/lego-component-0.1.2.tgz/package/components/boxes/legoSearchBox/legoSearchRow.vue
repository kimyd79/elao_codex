<template>
    <div class="lego-search-row">
        <slot/>
    </div>
</template>

<script>
export default {
    name: "legoSearchRow"
}
</script>
