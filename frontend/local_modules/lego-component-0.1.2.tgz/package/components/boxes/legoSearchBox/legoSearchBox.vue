<template>
    <lego-box :title="title" :toggleable="toggleable" :class="'lego-search-box-wrapper lego-search-box-wrapper--'+$_size">
        <template v-slot:title-zone>
            <slot name="title-zone"/>
        </template>
        <div class="lego-search-box" :class="searchBoxClass" @click="onClick">
            <div class="lego-search-box__contents">
                <slot/>
                <hr v-if="isExpanded"/>
                <div v-show="isExpanded" class="lego-search-box__contents">
                    <slot name="expandable-zone"/>
                </div>
                <div v-if="$scopedSlots.bottomActionBar"
                     :class="'lego-search-box__action-grp lego-search-box__action-grp--bottom lego-search-box__action-grp--'+$_size">
                    <slot name="bottomActionBar"></slot>
                </div>
            </div>
            <div v-if="$scopedSlots.rightActionBar"
                 :class="'lego-search-box__action-grp lego-search-box__action-grp--right lego-search-box__action-grp--'+$_size">
                <lego-search-item no-label>
                    <slot name="rightActionBar"/>
                </lego-search-item>
            </div>

            <!-- 확장영역 라인부분 -->
            <div v-if="$scopedSlots['expandable-zone']" class="lego-search-box__exp-bottom">
                <div class="lego-search-box__exp-bottom__line"></div>
                <div class="lego-search-box__exp-bottom__toggle" @click="expandToggle">
                    <lego-icon-wrapper>
                        <lego-icon :icon="expandIcon"/>
                    </lego-icon-wrapper>
                    {{expandMessage}}
                </div>
                <div class="lego-search-box__exp-bottom__line"></div>
            </div>
        </div>
        <div v-if="!$scopedSlots.rightActionBar && !$scopedSlots.bottomActionBar"
             :class="'lego-search-box__action-grp lego-search-box__action-grp--outer lego-search-box__action-grp--'+$_size">
            <slot name="outerActionBar">
                <lego-action-bar>
                    <lego-button main @click="searchAction">{{searchLabel}}</lego-button>
                </lego-action-bar>
            </slot>
        </div>
    </lego-box>
</template>

<script>
    const TAG_ITEM = "legoFormItem";

    export default {
        name: "legoSearchBox",
        props: {
            column     : [String, Number],
            col        : [String, Number], /* abbr */
            labelSize  : String,
            labelDisplay : {
                type:String,
                validator: (val) => {
                    let lowerVal = val.toLowerCase();
                    return ['inline', 'block'].indexOf(lowerVal) !== -1;
                }
            },
            labelAlign : {
                type:String,
                validator: (val) => {
                    let lowerVal = val.toLowerCase();
                    return ['left', 'right'].indexOf(lowerVal) !== -1;
                }
            },
            toggle     : Boolean,
            // $v0.1.2
            expanded: {
                type:Boolean,
                default: false
            },
            // $v0.1.2
            expandMessage: {
                type: String,
                default: ''
            },
            searchLabel: {
                type: String,
                default: 'Search'
            },

            /*[PROP] for LEGO-BOX*/
            title      : String,
            toggleable : Boolean,

            small      : Boolean,
            sm         : Boolean, /* abbr */
            medium     : Boolean,
            md         : Boolean, /* abbr */
        },
        data() {return {
            default: {
                labelDisplay: 'inline',
                labelAlign: 'left',
                size: 'medium',
                column: 2
            },
            isExpanded: false
        }},
        computed : {
            $_col() {return parseInt(this.column) || parseInt(this.col)  || this.default.column;},
            $_size() {
                if(this.small || this.sm) {return 'small';}
                if(this.medium || this.md) {return 'medium';}
                return this.default.size;
            },
            searchBoxClass() {
                let rtn = [];
                if(!!this.$scopedSlots['expandable-zone']) rtn.push('lego-search-box--expandable');
                rtn.push('lego-search-box--'+this.$_size);
                return rtn;
            },
            expandIcon() {
                return this.isExpanded ? 'collapse_menu': 'expand_menu';
            },
            sharedData() {
                let rtn = {}, odf = Object.defineProperty;
                odf(rtn, "col"         , {get:()=>this.$_col});
                odf(rtn, "labelSize"   , {get:()=>this.labelSize});
                odf(rtn, "labelDisplay", {get:()=>this.labelDisplay||this.default.labelDisplay});
                odf(rtn, "labelAlign"  , {get:()=>this.labelAlign||this.default.labelAlign});
                odf(rtn, "toggle"      , {get:()=>this.toggle});
                odf(rtn, "size"        , {get:()=>this.$_size});
                return rtn;
            }
        },
        watch: {
            expanded:{
                immediate: true,
                handler(val) {
                    if (val !== this.isExpanded) {
                        this.isExpanded = val;
                    }
                }
            }
        },
        methods: {
            onClick() {
                this.$emit('click');
            },
            expandToggle() {
                this.isExpanded = !this.isExpanded;
                this.$emit('update:expanded', this.isExpanded);
                this.$emit('expandToggle', this.isExpanded);
            },
            searchAction() {
                this.$emit('search');
            }
        },
        provide(){
            return {boxInfo:this.sharedData};
        }
    }



</script>
