<template>
    <div class="lego-search-item" :class="itemClass" :style="itemStyle">
        <div class="lego-search-item__label ellipsis" :class="labelClass" :style="labelStyle">
            <slot name="label">{{label}}</slot>
        </div>
        <div v-if="!boxInfo.toggle" class="lego-search-item__compo" :class="noFlex?'lego-search-item__compo--no-flex':''" >
            <slot/>
        </div>
        <div v-else class="lego-search-item__compo" :class="noFlex?'lego-search-item__compo--no-flex':''">
            <slot name="toggle">
                <slot/>
            </slot>
        </div>
    </div>

</template>

<script>
    export default {
        name: "legoSearchItem",
        inject : ["boxInfo"],
        props: {
            /* for ME */
            "label"   : String,
            "required": Boolean,
            "noLabel" : Boolean,
            "labelAlign": {
                type:String,
                validator: (val) => {
                    let lowerVal = val.toLowerCase();
                    return ['left', 'right'].indexOf(lowerVal) !== -1;
                }
            },
            "colSpan" : [Number,String],
            "span"    : [Number,String], /* abbr */
            "noHeight" : Boolean,
            "small"   : Boolean,
            "sm"      : Boolean, /* abbr */
            "medium"  : Boolean,
            "md"      : Boolean, /* abbr */
            "noFlex"  : Boolean
        },
        data() {return {
            default:{
                size:'medium',
                labelAlign: 'left'
            }
        }},
        computed:{
            $_size() {
                if(this.small || this.sm) {return 'small'}
                if(this.medium || this.md) {return 'medium'}
                if(this.boxInfo && this.boxInfo.size) {return this.boxInfo.size}
                return this.default.size;
            },
            $_span() {
                return parseInt(this.colSpan) || parseInt(this.span) ||  1;
            },
            itemFlex() {
                const itemWidth = 100 / this.boxInfo.col * this.$_span;
                return "0 0 "+itemWidth+"%";
            },
            itemStyle() {
                let style = {};
                style["flex"] = this.itemFlex;
                if( this.noHeight ){
                    style["height"] = "auto";
                }
                return style;
            },
            itemClass() {
                let clazz = [];
                clazz.push("lego-search-item--"+this.boxInfo.labelDisplay);
                if( this.noLabel  ) clazz.push("lego-search-item--no-label");
                if( this.noHeight  ) clazz.push("lego-search-item--no-height");
                if( this.required ) clazz.push("lego-search-item--required");
                clazz.push("lego-search-item--"+this.$_size);
                return clazz.join(' ');
            },
            labelStyle() {
                let style = {};
                if(this.boxInfo.labelSize) {style["flex"] = "0 0 "+this.boxInfo.labelSize;}
                return style;
            },
            labelClass() {
                let clazz = [];
                if(this.labelAlign) {
                    clazz.push("lego-search-item__label--"+this.labelAlign);
                } else if(this.boxInfo.labelDisplay === 'block') {
                    clazz.push("lego-search-item__label--left");
                } else if(this.boxInfo.labelAlign) {
                    // this is default align which is set by lego-search-box
                    // if you want to edit default label align, change default value of labelAlign props of lego-search-box
                    clazz.push("lego-search-item__label--"+this.boxInfo.labelAlign);
                } else  {
                    // actually, this is bad case :: lego-search-item is not located under lego-search-box
                    clazz.push("lego-search-item__label--"+this.default.labelAlign);
                }
                return clazz.join(' ');
            }
        },
        provide() {
            let rtn = {};
            let odf = Object.defineProperty;
            let legoInput = {};
            odf(legoInput, 'size', {get: ()=>this.$_size});
            rtn['legoInput'] = legoInput;
            return rtn;
        },

    }
</script>
