<script>
import arrUtil from "../../../utils/static/arrayUtil";
const TAG_ITEM = "legoStepItem";

export default {
    name : "legoStepBox",
    data () {return {
        stateList : [], /*state : "D"one,"I"ng,"R"eady */ /* NOT_YET : "F"ail */
        currIdx : 0
    }},
    props : {
        steps : Array,
        stepWidth : {type:[String,Number],default:160},
        fullHeight : Boolean,
        actionLabel : [String,Number]
    },
    computed : {
        stepBroken() { return arrUtil.isEmpty(this.steps); },
        $_stepWidth() { return parseInt(this["step-width"]); }
    },
    created() {
        this.init();
    },
    methods : {
        init() {
            if( this.stepBroken ) return;
            // 1. build stat list
            this.stateList = this.steps.map(st => "R");
            // 2. set init idx
            this.currIdx = 0;
            this.stateList[this.currIdx] = "I";
        },
        setIdx(idx) {


            // 1. check valid
            let ci = this.currIdx;
            if( idx > ci ) { // move to forward
                // 1.1 current step
                let cstep = this.steps[ci];
                if( typeof cstep === "object" && !cstep.valid ) {
                    this.$notify({text:"Check step valid condition.",type:'warn'});
                    return;
                }

                let fn = () => true;
                if( cstep && cstep.check && typeof cstep.check === 'function' ) fn = cstep.check;
                if( fn() !== true ) return;
                
                // 1.2 iter step
                for(let i = ci+1, ii = this.steps.length; i<ii && i<idx ; i++ ) {
                    let step = this.steps[i];
                    if( typeof step === "object" && !step.valid ) {
                        this.$notify({text:"Check step valid condition in step "+(i+1)+".",type:'warn'});
                        idx=i;
                        break;
                    }
                }
            }
            // 2. set value
            // 2.1 set State List
            for(let i=0,ii=this.stateList.length; i<ii ; i++ ) {
                this.stateList[i] = i<idx?"D":"R";
            }
            this.stateList[idx] = "I";
            // 2.2 set Current Index
            this.currIdx = idx;
            // 3. re-draw
            this.$forceUpdate();
            this.$emit("moveStep",idx);
        },
        buildStepper() {
            let $ce = this.$createElement;
            let opt = {}, chs = [];
            // 0. check something
            if(this.stepBroken) {return this.buildEmptyStepper();}
            // 1. opt
            opt["class"] = "lego-step-box__stepper";
            opt["style"] = {"width":this.$_stepWidth+"px"};
            // 2. chs
            let steps = this.steps;
            for(let i=0,ii=steps.length; i<ii; i++) {
                if( i!==0 ) {
                    chs.push(this.buildStepperSpacing());
                }
                chs.push(this.buildStepperItem(i));
            }

            return $ce('div',opt,chs)
        },
        buildStepperSpacing() {
            let $ce = this.$createElement;
            return $ce('div',{"class":"lego-step-box__stepper__spacing"},"...");
        },
        buildStepperItem(idx) {
            // 0. prepare
            let $ce = this.$createElement, itemChs = [];
            let childOn = {"click":(e) => {
                this.setIdx(idx);
            }};
            // 1. item option
            let itemClazz = "lego-step-box__stepper__item "+itemClassByState(this.stateList[idx]);
            // 2. item stat(bubble)
            let statCont = null;
            switch(this.stateList[idx]) {
            case "D": statCont = $ce("lego-icon",{},["check"]);break;
            case "F": statCont = $ce("lego-icon",{},["close"]);break;
            default : statCont = $ce("span",{},[idx+1]);}
            itemChs.push($ce("div",{"class":"lego-step-box__stepper__item__stat","on":childOn}, [statCont]))
            // 3. stat label
            let step = this.steps[idx];
            let label = typeof step === "object" ? step.name : step;
            itemChs.push($ce("div",{"class":"lego-step-box__stepper__item__label","on":childOn}, [label]))
            // x. return "STEPPER ITEM"
            
            return $ce("div",{"class":itemClazz},itemChs);
            // -. local function
            function itemClassByState(stat) {
                switch(stat) {
                    case "D":
                        return "lego-step-box__stepper__item--done";
                    case "F":
                        return "lego-step-box__stepper__item--fail";
                    case "I":
                        return "lego-step-box__stepper__item--ing";
                    case "R":
                        return "lego-step-box__stepper__item--ready";
                    default:
                        return "lego-step-box__stepper__item--fail";
                }
            }
        },
        buildEmptyStepper() {
            let $ce = this.$createElement;
            let EMPTY_MESSAGE = "Steps is not defined. Empty broken";
            let clazz = "lego-step-box__stepper lego-step-box__stepper--empty"
            return $ce('div',{"class":clazz},[EMPTY_MESSAGE])
        },
        buildContent() {
            // 0. prepare
            let defaultSlot = this.$slots["default"];
            let contents = [], idx = 0;
            // 1. Classify
            defaultSlot.forEach(vNode => {
                if(!vNode.componentOptions){ return; }
                let nodeName = vNode.componentOptions.Ctor.options.name;
                if( TAG_ITEM === nodeName ) {
                    contents.push(vNode);
                    let nodeFlag = idx===this.currIdx;
                    // set elm
                    this.$nextTick(()=>{
                        let $el = vNode.elm;
                        if(!$el) return;
                        $el.style.display = nodeFlag?"block":"none";
                    })
                    idx++;
                }
            })
            return contents;
        },
        buildActions(){
            let $ce = this.$createElement;
            let ci = this.currIdx,step = this.steps[ci];
            let valid = typeof step === "object" ? step.valid : true;
            let chs = [];
            // 1. add button
            // 1.1 previous step
            if(ci > 0 ) {
                let opt = {};
                opt.on = {"click":()=>{this.setIdx(ci-1);}};
                chs.push($ce("lego-button",opt,["Previous"]));
            }
            // 1.2 Next step
            if(ci < this.steps.length-1 ) {
                let opt = {};
                opt.on = {"click":()=>{this.setIdx(ci+1);}};
                opt.props = {"disabled":!valid}
                chs.push($ce("lego-button",opt,["Next"]));
            }
            // 1.3 last action
            if(ci === this.steps.length-1 ) {
                let opt = {};
                opt.props = {"primary":true,"solid":true};
                opt.on    = {click:()=>{this.$emit("action");}};
                chs.push($ce("lego-button",opt,this.actionLabel || "Action"));
            }
            return $ce("lego-action-bar",{},chs);
        }
    },
    render($ce) {
        // 1. opt
        let clazz = ["lego-step-box"];
        if(this.fullHeight) clazz.push("lego-step-box--full-height");
        
        // 2. chs
        let stepper = this.buildStepper();
        let content = this.buildContent();
        let actions = this.buildActions();
        let chs = [stepper].concat(content).concat(actions);
        
        return $ce('div',{"class":clazz},chs);
    }
}
</script>