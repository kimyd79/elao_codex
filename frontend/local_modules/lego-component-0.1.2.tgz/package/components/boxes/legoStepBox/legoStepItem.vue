<template>
    <div class="lego-step-item" v-show="true">
        <slot/>
    </div>
</template>

<script>
export default {
    name : "legoStepItem"
}
</script>
