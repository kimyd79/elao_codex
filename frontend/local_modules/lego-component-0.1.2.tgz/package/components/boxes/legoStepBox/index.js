import box  from "./legoStepBox";
import item from "./legoStepItem";
export default {
    install(Vue){
        Vue.component(box.name,  box);
        Vue.component(item.name, item);
    }
};