
import {comma, round, numOrZero} from './legoDigitFilter'
import {byteFilter} from './legoByteFilter'

export default {
    install(Vue) {
        // 1. digit filter
        Vue.filter(comma.name, comma);
        Vue.filter(round.name, round);
        Vue.filter(numOrZero.name, numOrZero);

        // 2. byte filter
        Vue.filter(byteFilter.name, byteFilter);
    }
}