function byteFilter(value, K = 1024, CUT = 100, PREC = 10) {
    let v = value;
    K = K || 1024;
    CUT = CUT || 100;
    PREC = PREC || 10;
    if ('number' !== typeof v) {return '0';}
    if (v === 1) { return v + ' b'; }
    if (v < CUT) { return v + ' b'; }
    v /= K;
    if (v < CUT) { return conv(v, PREC) + ' KB'; }
    v /= K;
    if (v < CUT) { return conv(v, PREC) + ' MB'; }
    v /= K;
    return conv(v, PREC) + ' GB';

    function conv(vv, cc) { return Math.round(vv * cc) / cc; }
}

export {byteFilter};

