import fCapitalize from "./legoCapitalize.js";
import fFormattedDate from "./legoFormattedDate";

export default {
    install(Vue) {
        Vue.filter(fCapitalize.name   , fCapitalize);
        Vue.filter(fFormattedDate.name, fFormattedDate);
    }
};