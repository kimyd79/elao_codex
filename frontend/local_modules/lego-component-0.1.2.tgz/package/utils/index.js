import arrayUtil  from './static/arrayUtil.js'
import dateUtil   from './static/dateUtil.js'
import numberUtil from './static/numberUtil.js'
import objectUtil from './static/objectUtil.js'

export default {arrayUtil,dateUtil,numberUtil,objectUtil};
