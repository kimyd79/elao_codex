import objUtil from "./objectUtil";

export default {
    /**
     * 배열인지 여부를 확인합니다.
     */
    isArray(arr) {
        return (arr && Array.isArray(arr));
    },
    /**
     * 배열이 비어있는지 확인합니다.
     * 입력값이 배열이 아닌경우 true(비어있음)을 반환합니다.
     */
    isEmpty(arr) {
        if( !this.isArray(arr) ) return true;
        return !arr.length;
    },
    /**
     * 배열을 복사합니다.
     * 반만 deep copy
     */
    copyArray(arr) { // little bit shallow
        if(!this.isArray(arr)) return [];
        let rtn = [];
        arr.forEach(o => {
            rtn.push(objUtil.copy(o));
        });
        return rtn;
    },
    copy(arr) {
        // alias
        return this.copyArray(arr);
    },
    
    /**
     * 임의의 Data List를 LEGO-DROPDOWN의 items 형태로 전환합니다.
     * usage : arrUtil.listToDropdownItems(res.data,'domainName','domainId');
     */
    listToDropdownItems(arr, textKey, valueKey) {
        if(this.isEmpty(arr)) {
            return [];
        }
        if( valueKey && textKey ) {
            return arr.map((item)=> {return {text:item[textKey],value:item[valueKey]};});
        } else if(!valueKey && textKey){
            return arr.map((item)=> item[textKey]);
        }
        return [];
    }
}