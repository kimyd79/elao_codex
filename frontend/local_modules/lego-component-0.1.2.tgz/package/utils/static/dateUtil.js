import moment from 'moment';
export default {
    /**
     * 날짜를 YYYY-MM-DD 형식으로 파싱한다.
     */
    parseDate(date) {
        if (!date) { return ""; }
        return moment(date).format('YYYY-MM-DD');
    }
}

function lpad2(num) {
    return num < 10 ? '0'+num : num;
}