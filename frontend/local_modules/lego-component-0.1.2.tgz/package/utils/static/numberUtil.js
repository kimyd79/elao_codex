const PREC = 2;

export default {
    pFloor(x, p) { // presicion floor
        if( isNaN(p) || p<0 ){return x;}
        let d = 1;while(p--) { d*= 10;}
        return Math.floor(x*d)/d;
    },
    getKey() { /* randomKey */
        let x = 0xffffff, n = 0x100000,
            r = parseInt(Math.random() * (x-n) + n)
        return r.toString(16);
    },
    isNum(n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    }
}