export default {
    copy(src) {
        // TODO slow!!!!
        return JSON.parse(JSON.stringify(src));
    }
}