<script type="text/javascript">
import Vue from 'vue';

let legoEventBus = new Vue();
export default legoEventBus;
</script>