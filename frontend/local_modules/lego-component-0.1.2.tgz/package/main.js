/* UI-Dev libraries */
if (!global._babelPolyfill) {
    require('babel-polyfill');
}
import compo  from './components'
import direc  from './directives'
import filter from './filters'

import VueNoti from 'vue-notification';

export default function install(Vue){
    Vue.use(VueNoti);
    Vue.use(compo);
    Vue.use(direc);
    Vue.use(filter);
};

import validator from './mixins/legoValidator/legoValidator.js'

export {validator}