let path = require('path');
let webpack = require('webpack');
const UglifyJSPlugin = require('uglifyjs-webpack-plugin');

var commonConfig = {
    entry: {
        main: resolve("/main.js"),
    },
    resolve : {
        extensions : ['.js','.vue'],
        alias : {
            'vue$'    : 'vue/dist/vue.esm.js',
            '~'       : resolve(''),
        }
    },
    module : {
        rules : [
            {test : /\.scss$/, loaders: ['style-loader','css-loader', 'sass-loader']},
            {test : /\.css$/ , loaders: ['vue-style-loader', 'css-loader']},
            {test : /\.js$/,loader: 'babel-loader',query: {
                    presets: ['@babel/preset-env'],
                    include: [
                        resolve('/node_modules/detect-indent'), // highlight
                        resolve('/node_modules/vue-highlight.js') // highlight
                    ]
                }},
            {test : /\.vue$/, loader : 'vue-loader',options: {
                    loaders: {
                        js: {
                            loader: 'babel-loader',
                            options: {
                                presets: ['@babel/preset-env']
                            }
                        }
                    }
                }},
            {test : /\.(png|jpg|jpeg|gif|svg|mp4)$/,loader : 'file-loader',
                options : {name : 'asset/media/[name].[ext]'}
            },
            {test: /\.(woff2?|eot|ttf|otf)?$/,loader: 'file-loader',
                options : {name : 'asset/fonts/[name].[ext]'}
            }
        ]
    }/*,
    externals:{
        '@toast-ui/vue-editor': '@toast-ui/vue-editor',
    }*/
};

module.exports = [
    // directly use @ browser via CDN (minify & uglify + babel applied)
    Object.assign({},commonConfig, {
        output: {
            path : resolve("/dist"),
            filename: 'legoComponent.min.js',
            libraryTarget: 'window',
            library: 'uidev'
        },
        plugins: [
            new UglifyJSPlugin({
                sourceMap : false,
                uglifyOptions: {
                    mangle: true,
                    compress: {warnings:false},
                }
            })
        ]
    }),/**/

    // after npm install, import @ project source code. babel applied
    Object.assign({},commonConfig, {
        output: {
            path : resolve("/dist"),
            filename: 'legoComponent.js',
            libraryTarget: 'umd',
            library: 'uidev',
            umdNamedDefine: true
        }
    })
];

/* Local function */
function resolve(dir) {return path.join(__dirname, '.', dir);}
