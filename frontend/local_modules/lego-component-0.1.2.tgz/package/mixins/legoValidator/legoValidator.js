/* legoValidator = {
 *      validatableObject: const Object,
 *      makeValidatableObj: f(),
 *      validate: f(),
 *      isValid: f(),
 *      clearValidation: f(),
 *      searchValidatableObjs: f(),
 *      validateChildren: f()
 * }
 */
const validatableObject = {
    isValidatable: true,
    validateTarget: undefined,
    rules: [],
    disabled: false,
    el: undefined,
    lazy: false,
    hasError: undefined, // undefined= not yet validated, true= invalid, false= valid
    errorMessage: '',
    noShake: false,
    showValid: false
};
let legoValidator = new function() {
    this.validatableObject = validatableObject;
    this.makeValidatableObj = function(inputObj) {
        return Object.assign({}, validatableObject, inputObj);
    };
    this.validate = function(target, rules=[], el=undefined) {
        /* 1. Target check*/
        if(target === undefined) {
            console.error('[LEGO-VALIDATOR] Validate target does not exist.');
            return undefined;
        }
        if(target instanceof Element) { // when this.$ref mistake
            console.error('[LEGO-VALIDATOR] Validate target should be value or VueComponent.');
            return undefined;
        }

        /* 2. Multiple targets */
        if(Array.isArray(target)) {
            if(target.map(item => (item?item.isValidatable:undefined)).indexOf(undefined) === -1) {
                let rtn = target.map(item => {return this.validate(item);});
                for(let i = 0 ; i < rtn.length ; i++) {
                    if(rtn[i] !== true) {
                        let el = target[i].$el;
                        if(el) {
                            // only for page scroller
                            // 74px = sticky header(64px) + some padding(10px)
                            el.style.transform = "translateY(-74px)"; // sticky header(64px) + some padding(10px)
                            el.scrollIntoView(true);
                            el.style.transform = "";
                            let chel = el.querySelector(".lego-text-field__input") ||
                                    el.querySelector(".lego-text-field__textarea") // focus할께 또 있나?
                            if(chel) chel.focus();
                        }
                        return rtn[i];
                    }
                }
                return true;
            } else {
                console.error('[LEGO-VALIDATOR] Validate target should be validatableObject or VueComponent.');
                return undefined;
            }
        }

        /* 3. validatable target */
        /* When target is validatable */
        if(target.isValidatable===false || (target.$attrs && target.$attrs.hasOwnProperty('no-validate'))) {return true;} // VueComponent which has no validation settings is treated as valid status
        if(target.isValidatable===true) {
            if(Array.isArray(target.rules)) {
                let rtn = undefined;
                for(let i = 0; i < target.rules.length ; i++) {
                    rtn = target.rules[i](target.validateTarget);
                    if(rtn !== true) {
                        /* ERROR OCCURS */
                        target.hasError = true;
                        target.errorMessage = rtn;
                        if(target.el instanceof Element) {
                            target.el.classList.remove('lego-validator--valid');
                            target.el.classList.add('lego-validator--error');
                            if(!target.noShake){
                                target.el.classList.add('lego-validator--shake');
                                setTimeout(()=>target.el.classList.remove('lego-validator--shake'), 500);
                            }
                        } else if (target.el && target.el._isVue) {
                            if(!target.noShake) {
                                target.shake = true;
                                setTimeout(()=>target.shake=false, 500);
                            }
                            // if(target.el.$vnode.data["staticClass"]) {
                            //     target.el.$vnode.data["staticClass"] = target.el.$vnode.data["staticClass"].replace(/lego-validator--valid/g,'');
                            //     target.el.$vnode.data["staticClass"] += ' lego-validator--error';
                            // } else {
                            //     target.el.$vnode.data["staticClass"] = 'lego-validator--error';
                            // }
                            // if(!target.noShake) {
                            //     target.el.$vnode.data["staticClass"] += ' lego-validator--shake';
                            //     setTimeout(()=>target.el.$el.classList.remove('lego-validator--shake'), 500);
                            // }
                        }
                        return rtn;
                    }
                }
                /* VALIDATE SUCCESS */
                target.hasError = false;
                target.errorMessage = '';
                if(target.el instanceof Element) {
                    if(target.showValid) {
                        target.el.classList.add('lego-validator--valid');
                    }
                    target.el.classList.remove('lego-validator--error');
                } else if (target.el && target.el._isVue) {
                    // if(target.el.$vnode.data["staticClass"]) {
                    //     target.el.$vnode.data["staticClass"] = target.el.$vnode.data["staticClass"].replace(/lego-validator--error/g,'');
                    //     if(target.showValid) {
                    //         target.el.$vnode.data["staticClass"] += ' lego-validator--valid';
                    //     }
                    // } else if(target.showValid) {
                    //     target.el.$vnode.data["staticClass"] = 'lego-validator--valid';
                    // }
                }
                return rtn;
            } else {
                console.error('[LEGO-VALIDATOR] validation rules do not exist or are not a valid form.');
                return undefined;
            }
        }
        /* When target is just variable */
        else {
            let tempObject = Object.assign({},validatableObject, {
                validateTarget: target,
                rules: rules,
                el: el
            });
            return this.validate(tempObject);
        }
    };
    this.isValid = function(target, rules=[], el=undefined) {
        let rtn = this.validate(target, rules, el);
        return rtn === true;
    };
    this.clearValidation = function (target, el=undefined) {
        /* 1. Target check*/
        if(target === undefined) {
            console.error('[LEGO-VALIDATOR] clearing target does not exist.');
            return undefined;
        }
        if(target instanceof Element) { // when this.$ref mistake
            console.error('[LEGO-VALIDATOR] clearing target should be value or VueComponent.');
            return undefined;
        }
        /* 2. multiple targets */
        if (Array.isArray(target)) {
            if(target.map(item => (item?item.isValidatable:undefined)).indexOf(undefined) === -1) {
                let rtn = target.map(item => (this.clearValidation(item)));
                for(let i = 0 ; i < rtn.length ; i++) {
                    if(rtn[i] !== true) return rtn[i];
                }
                return true;
            } else {
                console.error('[LEGO-VALIDATOR] clearing target should be validatableObject or VueComponent.');
                return undefined;
            }
        }

        if(target.isValidatable!==undefined){
            /* CLEAR VALIDATION @ validatable object*/
            target.hasError = undefined;
            target.errorMessage = '';
            if(target.el instanceof Element) {
                target.el.classList.remove('lego-validator--valid');
                target.el.classList.remove('lego-validator--error');
            } else if(target.el && target.el._isVue) {
                if(target.el.$vnode.data["staticClass"]) {
                    target.el.$vnode.data["staticClass"] = target.el.$vnode.data["staticClass"].replace(/lego-validator--error/g,'');
                    target.el.$vnode.data["staticClass"] = target.el.$vnode.data["staticClass"].replace(/lego-validator--valid/g,'');
                }
            }
        } else {
            /* CLEAR VALIDATION @ non-validatable object */
            if(el instanceof Element) {
                el.classList.remove('lego-validator--valid');
                el.classList.remove('lego-validator--error');
            } else if(el && el._isVue) {
                if(el.$vnode.data["staticClass"]) {
                    el.$vnode.data["staticClass"] = el.$vnode.data["staticClass"].replace(/lego-validator--error/g,'');
                    el.$vnode.data["staticClass"] = el.$vnode.data["staticClass"].replace(/lego-validator--valid/g,'');
                }
            }
        }
        return true;
    };
    this.searchValidatableObjs = function(target) {
        let rtn = [];
        if(target && target.isValidatable && !target.$attrs.hasOwnProperty('no-validate')) {
            rtn.push(target);
            return rtn;
        }
        if(target && target.$children) {
            for (let index = 0; index < target.$children.length; index++) {
                if(!target.$attrs.hasOwnProperty('no-validate')) {
                    rtn = rtn.concat(this.searchValidatableObjs(target.$children[index]));
                }
            }
        }
        return rtn;
    };
    this.validateChildren = function(target) {
        let targets = this.searchValidatableObjs(target);
        return this.validate(targets);
    }
}();

export default legoValidator;