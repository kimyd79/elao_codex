<script>
import legoValidator from './legoValidator.js';
export default {
    props: {
        // $ver: v0.1.0
        // validator를 사용하기 위한 rule-set입니다. Array type으로 지정되며,
        // 각각의 element는 validate 성공시 boolean true를, validate 싪패시 에러 메시지를 리턴하는 함수입니다.
        // #Rule-set for using validator. Specified by an Array type, 
        // #each element returns a boolean true on successful validation and a validate failure error message.
        rules: {
            type: Array,
            default: () => []
        },
        // $ver: v0.1.0
        // disabled가 true로 설정되어있으면 validate 대상으로 지정되지 않습니다.
        // <em>lego-validator-mixin</em>을 사용하는 컴포넌트에서 별도 설정을 통해
        // 상호작용 방지 및 모양새 변화등의 기능이 추가될 수 있습니다.
        // #If disabled is set to true, it is not targeted for validation.
        // #In components that use <em>lego-validator-mixin</em>, additional settings can be added to prevent interaction and change appearance.
        // $default: false
        disabled: {type: Boolean, default: legoValidator.validatableObject.disabled},
        // $ver: v0.1.0
        // <em>lego-validator-mixin</em>을 사용하는 컴포넌트는 컴포넌트 특성에 따라 <em>validateOnEvent()</em>를 호출합니다.
        // lazy가 true로 설정되어있는경우 <em>validateOnEvent()</em>가 호출될 때 <em>validate()</em>가 실행되지 않습니다.
        // #Components that use <em>lego-validator-mixin</em> call <em>validateOnEvent()</em> based on component properties.
        // #If lazy is set to true, <em>validate()</em> will not execute when <em>validateOnEvent()</em> is called.
        // $default: false
        lazy: {type: Boolean, default: legoValidator.validatableObject.lazy},
        // $ver: v0.1.1
        // validate실패시 해당 컴포넌트에 shake 애니메이션을 적용할지 말지 결정합니다.
        // #Determines whether shake animation should be applied to the component when it fails.
        // $default: false
        noShake: {type: Boolean, default: legoValidator.validatableObject.noShake},

        // if lazy set to true, validateOnEvent prevent to be triggered.
        // if lazy set to false, validateOnEvent execute validate().
    },
    data() { return {
        hasError: undefined,
        errorMessage: '',
        showValid: legoValidator.validatableObject.showValid,
        shake: false
    }},
    watch: {
        validateTarget() {
            // when validateTarget changes, clearValidation.
            // validate() will be triggered by validateOnEvent set in each component
            // or whenever manually called
            if(this.isValidatable) {
                if (this.hasError !== undefined) {
                    this.clearValidation();
                }
            }
        },
    },
    computed: {
        validateTarget() {
            // override this in your component.
            // eg1. return this.value @ validatable component
            // eg2. return this.$refs.targetRef.
            return undefined;
        },
        isValidatable() {return !this.disabled && this.validateTarget !== undefined && this.rules && (this.rules.length > 0);},
        el() {return this;}
    },
    methods: {
        // @vuese
        // $ver: v0.1.0
        // $(arg): target object of validate(). 'this'(=component itself) is default argument.
        // $return: true | String | undefined
        // <em>validate()</em>를 실행합니다. validate 성공시 true, 실패시 error message를 반환합니다.
        // validate실행 중 문제가 발생한 경우 undefined를 반환합니다. 이런 경우 개발자도구의 에러로그를 확인하시기 바랍니다.
        // #Run <em>validate()</em>. validate true on success, error message on failure.
        // #If there is a problem running validate, it returns undefined. In this case, please check the error log of the developer tools.
        validate: function(target = this) {
            return legoValidator.validate(target);
        },
        // @vuese
        // $ver: v0.1.0
        // $(arg): target object of isValid(). 'this'(=component itself) is default argument.
        // $return: Boolean
        // <em>validate()</em>를 실행한 후 validate 성공시 true, 그 외의 경우 false를 반환합니다.
        // #Returns true on successful validation after executing <em>validate()</em>, false otherwise.
        isValid(target = this) {
            return legoValidator.isValid(target);
        },
        // @vuese
        // $ver: v0.1.0
        // $(arg): target object of clearValidation(). 'this'(=component itself) is default argument.
        // $return: true | undefined
        // 해당 컴포넌트의 validate정보를 초기화합니다. <em>validate()</em>실행 이후 각 컴포넌트의 validateTarget(일반적으로 v-model값)에
        // 변경이 일어나는 경우 자동으로 실행됩니다. validate정보 초기화에 성공하면 true, 실행중 문제가 발생한 경우 undefined를 반환합니다.
        // 이런 경우 개발자도구의 에어로그를 확인하시기 바랍니다.
        // #Initialize the validate information of the component. After executing <em> validate () </ em>, each component's validateTarget (typically v-model value)
        // #If a change occurs, it runs automatically. Returns true if the initialization of the validate information succeeds, or undefined if there is a problem running.
        // #If this is the case, please check the Developer Tools airlog.
        clearValidation: function (target = this) {
            return legoValidator.clearValidation(target);
        },
        // @vuese
        // $ver: v0.1.0
        // <em>lego-validator-mixin</em>을 사용하는 컴포넌트 특성에 따라 특정 상황에 맞게 <em>validate()</em>를 실행합니다.
        // lazy가 true인 경우, <em>validate()</em>를 실행하지 않습니다.
        // #Depending on the component properties using <em>lego-validator-mixin</em>, execute <em>validate()</em> for your specific situation.
        // #If lazy is true, do not execute <em>validate()</em>.
        validateOnEvent() {
            if(!this.lazy) {
                this.validate();
            }
        },
    },
}
</script>